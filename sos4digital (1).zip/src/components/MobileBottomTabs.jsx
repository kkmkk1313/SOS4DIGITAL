import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Home, User, QrCode, FileText } from 'lucide-react';

export default function MobileBottomTabs() {
  const location = useLocation();
  
  const tabs = [
    { path: createPageUrl('Home'), icon: Home, label: 'Home' },
    { path: createPageUrl('MyProfiles'), icon: User, label: 'Profiles' },
    { path: createPageUrl('QRCodes'), icon: QrCode, label: 'QR Codes' },
    { path: createPageUrl('FlipbookManager'), icon: FileText, label: 'PDFs' },
  ];

  const isActive = (path) => {
    if (path === createPageUrl('Home')) {
      return location.pathname === '/' || location.pathname === createPageUrl('Home');
    }
    return location.pathname === path;
  };

  return (
    <nav 
      className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 select-none"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="grid grid-cols-4 h-16">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = isActive(tab.path);
          
          return (
            <Link
              key={tab.path}
              to={tab.path}
              className={`flex flex-col items-center justify-center gap-1 transition-colors ${
                active 
                  ? 'text-violet-600' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{tab.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}