import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Upload, Crown, Bot, Sparkles, Palette, Type, Music } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function VIPAdminPanel({ profile, onClose, onUpdate }) {
  const [formData, setFormData] = useState({
    vip_mode: profile.vip_mode || 'off',
    vip_loader_enabled: profile.vip_loader_enabled || false,
    vip_loader_logo: profile.vip_loader_logo || '',
    vip_loader_text1: profile.vip_loader_text1 || 'Initializing Digital Identity',
    vip_loader_text2: profile.vip_loader_text2 || 'Access Granted',
    vip_robots_enabled: profile.vip_robots_enabled || false,
    vip_robot_message: profile.vip_robot_message || 'Welcome to the future',
    vip_floating_assistant: profile.vip_floating_assistant || false,
    vip_assistant_greeting: profile.vip_assistant_greeting || 'How can I assist you?',
    vip_animations_enabled: profile.vip_animations_enabled || false,
    vip_name_color: profile.vip_name_color || 'gold',
    vip_name_custom_colors: profile.vip_name_custom_colors || ['#FFD700', '#FDB931', '#FFED4E'],
    vip_shiver_intensity: profile.vip_shiver_intensity || 'medium',
    vip_background_music: profile.vip_background_music || '',
    vip_music_volume: profile.vip_music_volume || 30
  });
  const [uploading, setUploading] = useState(false);

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, vip_loader_logo: file_url }));
      toast.success('Logo uploaded');
    } catch (error) {
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    try {
      await base44.entities.Profile.update(profile.id, formData);
      toast.success('VIP settings saved!');
      onUpdate();
      onClose();
    } catch (error) {
      toast.error('Failed to save');
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[9999] flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white rounded-3xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 p-6 text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-amber-400/20 to-yellow-500/20 animate-pulse" />
            <div className="relative flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Crown className="w-8 h-8" />
                <div>
                  <h2 className="text-2xl font-bold">VIP Control Panel</h2>
                  <p className="text-amber-100 text-sm">Exclusive Admin Settings</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="overflow-y-auto max-h-[calc(90vh-180px)] p-6">
            <Tabs defaultValue="mode" className="space-y-6">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="mode">
                  <Palette className="w-4 h-4 mr-2" />
                  Mode
                </TabsTrigger>
                <TabsTrigger value="loader">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Loader
                </TabsTrigger>
                <TabsTrigger value="robots">
                  <Bot className="w-4 h-4 mr-2" />
                  Robots
                </TabsTrigger>
                <TabsTrigger value="effects">
                  <Crown className="w-4 h-4 mr-2" />
                  Effects
                </TabsTrigger>
                <TabsTrigger value="name">
                  <Type className="w-4 h-4 mr-2" />
                  Name
                </TabsTrigger>
                <TabsTrigger value="music">
                  <Music className="w-4 h-4 mr-2" />
                  Music
                </TabsTrigger>
              </TabsList>

              {/* Mode Tab */}
              <TabsContent value="mode" className="space-y-4">
                <div className="space-y-4">
                  <Label className="text-lg font-semibold">VIP Experience Mode</Label>
                  <div className="grid grid-cols-3 gap-3">
                    {['off', 'luxury', 'minimal'].map((mode) => (
                      <button
                        key={mode}
                        onClick={() => setFormData(prev => ({ ...prev, vip_mode: mode }))}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          formData.vip_mode === mode
                            ? 'border-amber-500 bg-amber-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="font-semibold capitalize">{mode}</div>
                        <div className="text-xs text-gray-500 mt-1">
                          {mode === 'off' && 'Standard profile'}
                          {mode === 'luxury' && 'Full VIP experience'}
                          {mode === 'minimal' && 'Subtle elegance'}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* Loader Tab */}
              <TabsContent value="loader" className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-xl border border-amber-200">
                  <div>
                    <Label className="font-semibold">Enable VIP Loader</Label>
                    <p className="text-xs text-gray-600">Animated entrance with logo</p>
                  </div>
                  <Switch
                    checked={formData.vip_loader_enabled}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, vip_loader_enabled: checked }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Custom Logo</Label>
                  <div className="flex gap-2">
                    {formData.vip_loader_logo && (
                      <img src={formData.vip_loader_logo} alt="Logo" className="w-16 h-16 object-contain rounded-lg border" />
                    )}
                    <div className="flex-1">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleLogoUpload}
                        className="hidden"
                        id="logo-upload"
                      />
                      <label htmlFor="logo-upload">
                        <Button variant="outline" className="w-full" disabled={uploading} asChild>
                          <span>
                            <Upload className="w-4 h-4 mr-2" />
                            {uploading ? 'Uploading...' : 'Upload Logo'}
                          </span>
                        </Button>
                      </label>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>First Message</Label>
                  <Input
                    value={formData.vip_loader_text1}
                    onChange={(e) => setFormData(prev => ({ ...prev, vip_loader_text1: e.target.value }))}
                    placeholder="Initializing Digital Identity"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Second Message</Label>
                  <Input
                    value={formData.vip_loader_text2}
                    onChange={(e) => setFormData(prev => ({ ...prev, vip_loader_text2: e.target.value }))}
                    placeholder="Access Granted"
                  />
                </div>
              </TabsContent>

              {/* Robots Tab */}
              <TabsContent value="robots" className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl border border-cyan-200">
                  <div>
                    <Label className="font-semibold">Enable Robot Animations</Label>
                    <p className="text-xs text-gray-600">Animated robots during loading</p>
                  </div>
                  <Switch
                    checked={formData.vip_robots_enabled}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, vip_robots_enabled: checked }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Robot Message</Label>
                  <Textarea
                    value={formData.vip_robot_message}
                    onChange={(e) => setFormData(prev => ({ ...prev, vip_robot_message: e.target.value }))}
                    placeholder="Welcome to the future"
                    rows={2}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200">
                  <div>
                    <Label className="font-semibold">Floating Assistant</Label>
                    <p className="text-xs text-gray-600">Interactive robot on page</p>
                  </div>
                  <Switch
                    checked={formData.vip_floating_assistant}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, vip_floating_assistant: checked }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Assistant Greeting</Label>
                  <Input
                    value={formData.vip_assistant_greeting}
                    onChange={(e) => setFormData(prev => ({ ...prev, vip_assistant_greeting: e.target.value }))}
                    placeholder="How can I assist you?"
                  />
                </div>
              </TabsContent>

              {/* Effects Tab */}
              <TabsContent value="effects" className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl border border-amber-200">
                  <div>
                    <Label className="font-semibold">Luxury Animations</Label>
                    <p className="text-xs text-gray-600">Premium hover effects & micro-interactions</p>
                  </div>
                  <Switch
                    checked={formData.vip_animations_enabled}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, vip_animations_enabled: checked }))}
                  />
                </div>

                <div className="p-4 bg-gray-50 rounded-xl border border-gray-200">
                  <p className="text-sm text-gray-700 mb-2 font-medium">Includes:</p>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• One-time gold shimmer on name</li>
                    <li>• Soft glow hover effects</li>
                    <li>• Smooth lift on buttons</li>
                    <li>• Cinematic micro-interactions</li>
                  </ul>
                </div>
                </TabsContent>

                <TabsContent value="name" className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label>Name Color Effect</Label>
                    <Select value={formData.vip_name_color} onValueChange={(value) => setFormData({...formData, vip_name_color: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gold">Gold Shimmer</SelectItem>
                        <SelectItem value="diamond">Diamond Ice</SelectItem>
                        <SelectItem value="rainbow">Rainbow Spectrum</SelectItem>
                        <SelectItem value="fire">Fire Blaze</SelectItem>
                        <SelectItem value="ocean">Ocean Wave</SelectItem>
                        <SelectItem value="custom">Custom Gradient</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {formData.vip_name_color === 'custom' && (
                    <div>
                      <Label>Custom Colors (Add up to 5)</Label>
                      <div className="space-y-2">
                        {[0, 1, 2, 3, 4].map((idx) => (
                          <div key={idx} className="flex gap-2">
                            <Input
                              type="color"
                              value={formData.vip_name_custom_colors[idx] || '#FFD700'}
                              onChange={(e) => {
                                const colors = [...(formData.vip_name_custom_colors || [])];
                                colors[idx] = e.target.value;
                                setFormData({...formData, vip_name_custom_colors: colors});
                              }}
                              className="w-20"
                            />
                            <Input
                              value={formData.vip_name_custom_colors[idx] || ''}
                              onChange={(e) => {
                                const colors = [...(formData.vip_name_custom_colors || [])];
                                colors[idx] = e.target.value;
                                setFormData({...formData, vip_name_custom_colors: colors});
                              }}
                              placeholder={`Color ${idx + 1}`}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <Label>Shiver Intensity</Label>
                    <Select value={formData.vip_shiver_intensity} onValueChange={(value) => setFormData({...formData, vip_shiver_intensity: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        <SelectItem value="subtle">Subtle</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="intense">Intense</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                </TabsContent>

                <TabsContent value="music" className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label>Background Music URL</Label>
                    <Input
                      value={formData.vip_background_music}
                      onChange={(e) => setFormData({...formData, vip_background_music: e.target.value})}
                      placeholder="https://example.com/music.mp3"
                    />
                    <p className="text-xs text-gray-500 mt-1">Upload your music file and paste the URL here</p>
                  </div>

                  <div>
                    <Label>Volume: {formData.vip_music_volume}%</Label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={formData.vip_music_volume}
                      onChange={(e) => setFormData({...formData, vip_music_volume: parseInt(e.target.value)})}
                      className="w-full"
                    />
                  </div>

                  <Button
                    onClick={async () => {
                      const input = document.createElement('input');
                      input.type = 'file';
                      input.accept = 'audio/*';
                      input.onchange = async (e) => {
                        const file = e.target.files[0];
                        if (file) {
                          const { file_url } = await base44.integrations.Core.UploadFile({ file });
                          setFormData({...formData, vip_background_music: file_url});
                        }
                      };
                      input.click();
                    }}
                    variant="outline"
                  >
                    Upload Music File
                  </Button>
                </div>
                </TabsContent>
                </Tabs>
                </div>

          {/* Footer */}
          <div className="border-t p-6 flex gap-3">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handleSave}
              className="flex-1 bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-600 hover:via-yellow-600 hover:to-amber-700 text-white"
            >
              Save VIP Settings
            </Button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}