import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function VIPLoader({ profile, onComplete }) {
  const [stage, setStage] = useState('logo'); // logo -> text1 -> robots -> text2 -> fade
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (stage === 'logo') setStage('text1');
      else if (stage === 'text1') setStage(profile.vip_robots_enabled ? 'robots' : 'text2');
      else if (stage === 'robots') setStage('text2');
      else if (stage === 'text2') setStage('fade');
      else if (stage === 'fade') onComplete();
    }, stage === 'logo' ? 2500 : stage === 'robots' ? 5000 : stage === 'text1' ? 3000 : 2500);

    return () => clearTimeout(timer);
  }, [stage, profile.vip_robots_enabled, onComplete]);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => Math.min(prev + 1, 100));
    }, 30);
    return () => clearInterval(interval);
  }, []);

  return (
    <AnimatePresence>
      {stage !== 'complete' && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="fixed inset-0 z-[9999] bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center"
        >
          {/* Animated Background Grid */}
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0" style={{
              backgroundImage: 'linear-gradient(rgba(212, 175, 55, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(212, 175, 55, 0.1) 1px, transparent 1px)',
              backgroundSize: '50px 50px',
              animation: 'grid-move 20s linear infinite'
            }} />
          </div>

          {/* Floating Particles */}
          <div className="absolute inset-0 overflow-hidden">
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 bg-amber-400 rounded-full"
                initial={{ 
                  x: Math.random() * window.innerWidth,
                  y: window.innerHeight + 50,
                  opacity: 0
                }}
                animate={{
                  y: -50,
                  opacity: [0, 1, 1, 0],
                }}
                transition={{
                  duration: 4 + Math.random() * 3,
                  repeat: Infinity,
                  delay: Math.random() * 3,
                  ease: "easeInOut"
                }}
              />
            ))}
          </div>

          <div className="relative z-10 text-center px-6">
            {/* Logo Stage */}
            {stage === 'logo' && (
              <motion.div
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 1.2, opacity: 0 }}
                transition={{ duration: 0.8 }}
              >
                {profile.vip_loader_logo ? (
                  <img 
                    src={profile.vip_loader_logo} 
                    alt="Logo" 
                    className="w-32 h-32 mx-auto object-contain filter drop-shadow-2xl"
                  />
                ) : (
                  <div className="w-32 h-32 mx-auto bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 rounded-full flex items-center justify-center shadow-2xl shadow-amber-500/50">
                    <span className="text-5xl font-bold text-white">
                      {(profile.full_name || profile.username)[0].toUpperCase()}
                    </span>
                  </div>
                )}
              </motion.div>
            )}

            {/* Text Stage 1 */}
            {stage === 'text1' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                <h1 className="text-4xl md:text-5xl font-bold luxury-loader-text">
                  {profile.vip_loader_text1 || 'Initializing Digital Identity'}
                </h1>
                <div className="w-64 h-1 mx-auto bg-gray-800 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              </motion.div>
            )}

            {/* Robots Stage */}
            {stage === 'robots' && profile.vip_robots_enabled && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="relative h-96"
              >
                {/* Robot 1 - Left */}
                <motion.div
                  initial={{ x: -300, y: 150, opacity: 0, rotate: -20 }}
                  animate={{ 
                    x: -120, 
                    y: 0, 
                    opacity: 1,
                    rotate: [0, 5, -5, 0],
                  }}
                  exit={{ x: -300, y: -150, opacity: 0, rotate: 20 }}
                  transition={{ 
                    duration: 1.5, 
                    delay: 0.3,
                    rotate: {
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }
                  }}
                  className="absolute left-1/4 top-1/2 -translate-x-1/2 -translate-y-1/2"
                >
                  <motion.div 
                    className="relative"
                    animate={{ y: [0, -15, 0] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  >
                    <div className="w-24 h-24 bg-gradient-to-br from-cyan-400 via-blue-500 to-cyan-600 rounded-2xl shadow-2xl shadow-cyan-500/50 relative overflow-hidden">
                      {/* Robot Face */}
                      <div className="absolute inset-3 bg-gradient-to-br from-cyan-300 to-blue-400 rounded-xl animate-pulse" />
                      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 flex gap-2">
                        <div className="w-3 h-3 bg-white rounded-full animate-ping" />
                        <div className="w-3 h-3 bg-white rounded-full animate-ping" style={{ animationDelay: '0.2s' }} />
                      </div>
                      <div className="absolute bottom-1/3 left-1/2 -translate-x-1/2 w-8 h-2 bg-white rounded-full" />
                      {/* Antenna */}
                      <motion.div 
                        className="absolute -top-4 left-1/2 -translate-x-1/2 w-1 h-6 bg-cyan-400"
                        animate={{ scaleY: [1, 1.3, 1] }}
                        transition={{ duration: 1, repeat: Infinity }}
                      >
                        <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-3 h-3 bg-cyan-300 rounded-full animate-pulse" />
                      </motion.div>
                    </div>
                  </motion.div>
                </motion.div>

                {/* Robot 2 - Right */}
                <motion.div
                  initial={{ x: 300, y: 150, opacity: 0, rotate: 20 }}
                  animate={{ 
                    x: 120, 
                    y: 0, 
                    opacity: 1,
                    rotate: [0, -5, 5, 0],
                  }}
                  exit={{ x: 300, y: -150, opacity: 0, rotate: -20 }}
                  transition={{ 
                    duration: 1.5, 
                    delay: 0.5,
                    rotate: {
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: 0.5
                    }
                  }}
                  className="absolute right-1/4 top-1/2 translate-x-1/2 -translate-y-1/2"
                >
                  <motion.div 
                    className="relative"
                    animate={{ y: [0, -15, 0] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  >
                    <div className="w-24 h-24 bg-gradient-to-br from-purple-400 via-pink-500 to-purple-600 rounded-2xl shadow-2xl shadow-purple-500/50 relative overflow-hidden">
                      {/* Robot Face */}
                      <div className="absolute inset-3 bg-gradient-to-br from-purple-300 to-pink-400 rounded-xl animate-pulse" />
                      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 flex gap-2">
                        <div className="w-3 h-3 bg-white rounded-full animate-ping" style={{ animationDelay: '0.1s' }} />
                        <div className="w-3 h-3 bg-white rounded-full animate-ping" style={{ animationDelay: '0.3s' }} />
                      </div>
                      <div className="absolute bottom-1/3 left-1/2 -translate-x-1/2 w-8 h-2 bg-white rounded-full" />
                      {/* Antenna */}
                      <motion.div 
                        className="absolute -top-4 left-1/2 -translate-x-1/2 w-1 h-6 bg-purple-400"
                        animate={{ scaleY: [1, 1.3, 1] }}
                        transition={{ duration: 1, repeat: Infinity, delay: 0.3 }}
                      >
                        <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-3 h-3 bg-purple-300 rounded-full animate-pulse" />
                      </motion.div>
                    </div>
                  </motion.div>
                </motion.div>

                {/* Center Hologram Message */}
                <motion.div
                  initial={{ scale: 0, opacity: 0, rotateY: 90 }}
                  animate={{ 
                    scale: 1, 
                    opacity: 1,
                    rotateY: [0, 5, -5, 0],
                  }}
                  transition={{ 
                    duration: 1, 
                    delay: 1.2,
                    rotateY: {
                      duration: 4,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }
                  }}
                  className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
                >
                  <div className="relative px-10 py-6 bg-gradient-to-r from-amber-400/30 via-yellow-500/30 to-amber-600/30 backdrop-blur-2xl border-2 border-amber-500/50 rounded-3xl shadow-2xl">
                    {/* Hologram scan lines */}
                    <motion.div 
                      className="absolute inset-0 bg-gradient-to-b from-transparent via-amber-300/20 to-transparent rounded-3xl"
                      animate={{ y: ['-100%', '200%'] }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-amber-400/20 to-yellow-500/20 animate-pulse rounded-3xl" />
                    <p className="relative text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-200 animate-shimmer whitespace-nowrap">
                      {profile.vip_robot_message || 'Welcome to the future'}
                    </p>
                    {/* Corner decorations */}
                    <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-amber-400 rounded-tl-lg" />
                    <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-amber-400 rounded-tr-lg" />
                    <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-amber-400 rounded-bl-lg" />
                    <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-amber-400 rounded-br-lg" />
                  </div>
                </motion.div>
              </motion.div>
            )}

            {/* Text Stage 2 */}
            {stage === 'text2' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.1 }}
                transition={{ duration: 0.8 }}
              >
                <h1 className="text-5xl md:text-6xl font-bold luxury-loader-text">
                  {profile.vip_loader_text2 || 'Access Granted'}
                </h1>
              </motion.div>
            )}
          </div>

          <style>{`
            @keyframes grid-move {
              0% { transform: translate(0, 0); }
              100% { transform: translate(50px, 50px); }
            }

            @keyframes float {
              0%, 100% { transform: translateY(0px) rotate(0deg); }
              50% { transform: translateY(-10px) rotate(5deg); }
            }

            .animate-float {
              animation: float 3s ease-in-out infinite;
            }

            @keyframes shimmer {
              0% { background-position: -200% center; }
              100% { background-position: 200% center; }
            }

            .animate-shimmer {
              background-size: 200% auto;
              animation: shimmer 3s linear infinite;
            }

            .luxury-loader-text {
              background: linear-gradient(135deg, #d4af37 0%, #f9e79f 25%, #ffd700 50%, #d4af37 75%, #b8860b 100%);
              background-size: 200% auto;
              -webkit-background-clip: text;
              background-clip: text;
              -webkit-text-fill-color: transparent;
              animation: shimmer 3s linear infinite;
              filter: drop-shadow(0 0 20px rgba(212, 175, 55, 0.5));
            }
          `}</style>
        </motion.div>
      )}
    </AnimatePresence>
  );
}