import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, MessageCircle, Share2, X } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function FloatingAssistant({ profile, onSaveContact, onShare }) {
  const [isOpen, setIsOpen] = useState(false);
  const [showGreeting, setShowGreeting] = useState(true);

  return (
    <>
      {/* Floating Robot Button */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <motion.button
          onClick={() => setIsOpen(!isOpen)}
          className="relative w-16 h-16 bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 rounded-full shadow-2xl shadow-amber-500/50 flex items-center justify-center overflow-hidden group"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          animate={{
            boxShadow: [
              '0 20px 60px rgba(251, 191, 36, 0.5)',
              '0 20px 80px rgba(251, 191, 36, 0.8)',
              '0 20px 60px rgba(251, 191, 36, 0.5)',
            ]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          {/* Glowing Core */}
          <motion.div
            className="absolute inset-3 bg-gradient-to-br from-yellow-200 to-amber-400 rounded-full"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
          
          {/* Robot Face */}
          <div className="relative z-10">
            <div className="flex gap-1.5 mb-1">
              <motion.div 
                className="w-2 h-2 bg-white rounded-full"
                animate={{ scale: [1, 0.8, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <motion.div 
                className="w-2 h-2 bg-white rounded-full"
                animate={{ scale: [1, 0.8, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.1 }}
              />
            </div>
            <div className="w-6 h-1 bg-white rounded-full" />
          </div>

          {/* Pulse Ring */}
          <motion.div
            className="absolute inset-0 border-4 border-amber-300 rounded-full"
            initial={{ scale: 1, opacity: 0.5 }}
            animate={{ scale: 1.5, opacity: 0 }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </motion.button>

        {/* Greeting Bubble */}
        <AnimatePresence>
          {showGreeting && !isOpen && (
            <motion.div
              initial={{ opacity: 0, x: 20, scale: 0.8 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 20, scale: 0.8 }}
              className="absolute bottom-20 right-0 w-48"
            >
              <div className="relative bg-gradient-to-br from-amber-50 to-yellow-50 border border-amber-200 rounded-2xl p-3 shadow-xl">
                <button
                  onClick={() => setShowGreeting(false)}
                  className="absolute -top-2 -right-2 w-6 h-6 bg-gray-900 text-white rounded-full flex items-center justify-center hover:bg-gray-800"
                >
                  <X className="w-3 h-3" />
                </button>
                <p className="text-sm font-medium text-gray-800">
                  {profile.vip_assistant_greeting || 'How can I assist you?'}
                </p>
                <div className="absolute bottom-0 right-6 w-0 h-0 border-l-8 border-r-8 border-t-8 border-l-transparent border-r-transparent border-t-amber-50 translate-y-full" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Action Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="fixed bottom-24 right-6 z-50"
          >
            <div className="bg-white/95 backdrop-blur-xl border border-gray-200 rounded-2xl shadow-2xl p-4 space-y-2 min-w-[200px]">
              <Button
                onClick={() => { onSaveContact(); setIsOpen(false); }}
                variant="ghost"
                className="w-full justify-start hover:bg-amber-50 hover:text-amber-700"
              >
                <Download className="w-4 h-4 mr-3" />
                Save Contact
              </Button>
              
              {profile.phone && (
                <Button
                  onClick={() => window.open(`https://wa.me/${profile.phone.replace(/\D/g, '')}`, '_blank')}
                  variant="ghost"
                  className="w-full justify-start hover:bg-green-50 hover:text-green-700"
                >
                  <MessageCircle className="w-4 h-4 mr-3" />
                  WhatsApp
                </Button>
              )}

              <Button
                onClick={() => { onShare(); setIsOpen(false); }}
                variant="ghost"
                className="w-full justify-start hover:bg-blue-50 hover:text-blue-700"
              >
                <Share2 className="w-4 h-4 mr-3" />
                Share Profile
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}