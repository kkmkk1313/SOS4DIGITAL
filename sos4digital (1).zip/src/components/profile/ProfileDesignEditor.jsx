import React from 'react';
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Check, Moon, Sun, Type, Layout, ZoomIn, MoveVertical, MoveHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";

const PRESET_COLORS = [
  "#7C3AED", // Violet
  "#EF4444", // Red
  "#F97316", // Orange
  "#F59E0B", // Amber
  "#10B981", // Emerald
  "#06B6D4", // Cyan
  "#3B82F6", // Blue
  "#EC4899", // Pink
  "#111827", // Black
];

const FONTS = [
  { value: "inter", label: "Modern (Inter)" },
  { value: "playfair", label: "Elegant (Playfair)" },
  { value: "roboto", label: "Clean (Roboto)" },
  { value: "lora", label: "Serif (Lora)" },
  { value: "montserrat", label: "Bold (Montserrat)" },
];

export default function ProfileDesignEditor({ formData, setFormData }) {
  
  const handleColorSelect = (color) => {
    setFormData({ ...formData, theme_color: color });
  };

  return (
    <div className="space-y-8 py-4">
      {/* Cover Image Style */}
      <div className="space-y-3">
        <Label className="text-base font-medium">Cover Image Style</Label>
        <div className="grid grid-cols-2 gap-3 mb-2">
          <button
            onClick={() => setFormData({ ...formData, cover_fit: 'cover' })}
            className={cn(
              "p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2",
              formData.cover_fit === 'cover' || !formData.cover_fit
                ? "border-violet-600 bg-violet-50 text-violet-900" 
                : "border-gray-200 hover:border-violet-200 text-gray-600"
            )}
          >
            <div className="w-full h-12 bg-gray-200 rounded overflow-hidden relative">
               <div className="absolute inset-0 bg-gray-400" />
            </div>
            <span className="text-xs font-medium">Zoom / Crop</span>
          </button>
          <button
            onClick={() => setFormData({ ...formData, cover_fit: 'contain' })}
            className={cn(
              "p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2",
              formData.cover_fit === 'contain'
                ? "border-violet-600 bg-violet-50 text-violet-900" 
                : "border-gray-200 hover:border-violet-200 text-gray-600"
            )}
          >
            <div className="w-full h-12 bg-gray-100 rounded flex items-center justify-center">
               <div className="w-8 h-8 bg-gray-400 rounded" />
            </div>
            <span className="text-xs font-medium">Show Full Image</span>
          </button>
        </div>
        
        {formData.cover_fit === 'contain' && (
             <div className="flex justify-end mb-2">
                 <button 
                    onClick={() => setFormData({ ...formData, cover_zoom: 0.8, cover_offset_x: 50, cover_offset_y: 50 })}
                    className="text-xs text-violet-600 font-medium hover:underline flex items-center gap-1"
                 >
                    <Layout className="w-3 h-3" /> Auto-Center Logo
                 </button>
             </div>
        )}

        {/* Header Size */}
        <div className="space-y-3 pt-2">
          <Label className="text-sm font-medium">Header Size</Label>
          <div className="grid grid-cols-3 gap-3">
             <button
               onClick={() => setFormData({ ...formData, header_size: 'standard' })}
               className={cn(
                 "p-2 rounded-lg border text-sm transition-all",
                 (!formData.header_size || formData.header_size === 'standard')
                   ? "border-violet-600 bg-violet-50 text-violet-900 ring-1 ring-violet-600" 
                   : "border-gray-200 hover:border-violet-200 text-gray-600"
               )}
             >
               Standard
             </button>
             <button
               onClick={() => setFormData({ ...formData, header_size: 'tall' })}
               className={cn(
                 "p-2 rounded-lg border text-sm transition-all",
                 formData.header_size === 'tall'
                   ? "border-violet-600 bg-violet-50 text-violet-900 ring-1 ring-violet-600" 
                   : "border-gray-200 hover:border-violet-200 text-gray-600"
               )}
             >
               Tall
             </button>
             <button
               onClick={() => setFormData({ ...formData, header_size: 'square' })}
               className={cn(
                 "p-2 rounded-lg border text-sm transition-all",
                 formData.header_size === 'square'
                   ? "border-violet-600 bg-violet-50 text-violet-900 ring-1 ring-violet-600" 
                   : "border-gray-200 hover:border-violet-200 text-gray-600"
               )}
             >
               Square
             </button>

          </div>
        </div>
        
          <div className="space-y-4 mt-4 p-4 bg-gray-50 rounded-xl border border-gray-200">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs font-medium text-gray-500 flex items-center gap-1">
                  <ZoomIn className="w-3 h-3" /> Zoom
                </Label>
                <span className="text-xs text-gray-500">{((formData.cover_zoom || 1) * 100).toFixed(0)}%</span>
              </div>
              <Slider
                value={[formData.cover_zoom === undefined ? 1 : formData.cover_zoom]}
                min={0}
                max={3}
                step={0.01}
                onValueChange={([value]) => setFormData({ ...formData, cover_zoom: value })}
              />
              </div>

              <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-xs font-medium text-gray-500 flex items-center gap-1">
                    <MoveHorizontal className="w-3 h-3" /> Horizontal
                  </Label>
                  <span className="text-xs text-gray-500">{formData.cover_offset_x === undefined ? 50 : formData.cover_offset_x}%</span>
                </div>
                <Slider
                  value={[formData.cover_offset_x === undefined ? 50 : formData.cover_offset_x]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={([value]) => setFormData({ ...formData, cover_offset_x: value })}
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-xs font-medium text-gray-500 flex items-center gap-1">
                    <MoveVertical className="w-3 h-3" /> Vertical
                  </Label>
                  <span className="text-xs text-gray-500">{formData.cover_offset_y === undefined ? 50 : formData.cover_offset_y}%</span>
                </div>
                <Slider
                  value={[formData.cover_offset_y === undefined ? 50 : formData.cover_offset_y]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={([value]) => setFormData({ ...formData, cover_offset_y: value })}
                />
              </div>
              </div>
          </div>
        </div>

      {/* Links Style */}
      <div className="space-y-3">
        <Label className="text-base font-medium">Links Style</Label>
        <div className="grid grid-cols-3 gap-4">
          <button
            onClick={() => setFormData({ ...formData, links_style: 'default' })}
            className={cn(
              "p-4 rounded-xl border-2 transition-all text-center space-y-2",
              formData.links_style === 'default' 
                ? "border-violet-600 bg-violet-50" 
                : "border-gray-200 hover:border-gray-300 bg-white"
            )}
          >
            <div className="w-12 h-12 mx-auto bg-gray-200 rounded-full mb-2" />
            <div className="space-y-1">
              <div className="h-2 w-16 mx-auto bg-gray-200 rounded" />
              <div className="h-2 w-12 mx-auto bg-gray-200 rounded" />
            </div>
            <span className="text-sm font-medium block mt-2">Default</span>
          </button>

          <button
            onClick={() => setFormData({ ...formData, links_style: 'left' })}
            className={cn(
              "p-4 rounded-xl border-2 transition-all text-center space-y-2",
              formData.links_style === 'left' 
                ? "border-violet-600 bg-violet-50" 
                : "border-gray-200 hover:border-gray-300 bg-white"
            )}
          >
            <div className="flex gap-2 items-center justify-center">
              <div className="w-8 h-8 bg-gray-200 rounded-full" />
              <div className="space-y-1">
                <div className="h-2 w-12 bg-gray-200 rounded" />
              </div>
            </div>
            <span className="text-sm font-medium block mt-2">Left Side</span>
          </button>

          <button
            onClick={() => setFormData({ ...formData, links_style: 'highlighted' })}
            className={cn(
              "p-4 rounded-xl border-2 transition-all text-center space-y-2",
              formData.links_style === 'highlighted' 
                ? "border-violet-600 bg-violet-50" 
                : "border-gray-200 hover:border-gray-300 bg-white"
            )}
          >
            <div className="w-full h-8 bg-gray-200 rounded-lg mb-2 border-2 border-gray-300" />
            <span className="text-sm font-medium block mt-2">Highlighted</span>
          </button>
        </div>
      </div>

      {/* Background Mode */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label className="text-base font-medium">Page Background</Label>
          {formData.background_color && (
            <button 
              onClick={() => setFormData({ ...formData, background_color: '' })}
              className="text-xs text-red-500 hover:text-red-600"
            >
              Reset Custom Color
            </button>
          )}
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <button
            onClick={() => setFormData({ ...formData, background_mode: 'light' })}
            className={cn(
              "flex items-center justify-center gap-2 p-3 rounded-xl border-2 transition-all",
              formData.background_mode === 'light'
                ? "border-violet-600 bg-violet-50 text-violet-700"
                : "border-gray-200 hover:border-gray-300 bg-white text-gray-600"
            )}
          >
            <Sun className="w-4 h-4" />
            Light Theme
          </button>
          <button
            onClick={() => setFormData({ ...formData, background_mode: 'dark' })}
            className={cn(
              "flex items-center justify-center gap-2 p-3 rounded-xl border-2 transition-all",
              formData.background_mode === 'dark'
                ? "border-violet-600 bg-gray-900 text-white"
                : "border-gray-200 hover:border-gray-300 bg-gray-900 text-gray-400"
            )}
          >
            <Moon className="w-4 h-4" />
            Dark Theme
          </button>
        </div>

        <div className="flex items-center gap-4 p-3 bg-white border border-gray-200 rounded-xl">
          <div className="w-10 h-10 rounded-full overflow-hidden relative border border-gray-200">
            <input 
              type="color" 
              value={formData.background_color || (formData.background_mode === 'dark' ? '#111827' : '#F3F4F6')}
              onChange={(e) => setFormData({ ...formData, background_color: e.target.value })}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <div 
              className="w-full h-full"
              style={{ backgroundColor: formData.background_color || (formData.background_mode === 'dark' ? '#111827' : '#F3F4F6') }}
            />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-900">Custom Page Color</p>
            <p className="text-xs text-gray-500">Overrides default theme background</p>
          </div>
        </div>

        {/* Header Color */}
        <div className="flex items-center gap-4 p-3 bg-white border border-gray-200 rounded-xl">
          <div className="w-10 h-10 rounded-full overflow-hidden relative border border-gray-200">
            <input 
              type="color" 
              value={formData.header_color || '#8B5CF6'}
              onChange={(e) => setFormData({ ...formData, header_color: e.target.value })}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <div 
              className="w-full h-full"
              style={{ backgroundColor: formData.header_color || 'linear-gradient(to bottom right, #8B5CF6, #7C3AED)' }}
            >
               {!formData.header_color && <div className="w-full h-full bg-gradient-to-br from-violet-500 to-purple-600" />}
               {formData.header_color && <div className="w-full h-full" style={{ backgroundColor: formData.header_color }} />}
            </div>
          </div>
          <div className="flex-1 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-900">Header Background</p>
              <p className="text-xs text-gray-500">Color behind cover image</p>
            </div>
            {formData.header_color && (
              <button 
                onClick={() => setFormData({ ...formData, header_color: '' })}
                className="text-xs text-red-500 hover:text-red-600"
              >
                Reset
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Card Style */}
      <div className="space-y-3">
        <Label className="text-base font-medium">Card Style</Label>
        
        <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-xl mb-3">
          <div>
            <p className="font-medium text-gray-900">Transparent Card</p>
            <p className="text-xs text-gray-500">Remove card background</p>
          </div>
          <Switch
            checked={formData.is_card_transparent}
            onCheckedChange={(checked) => setFormData({ ...formData, is_card_transparent: checked })}
          />
        </div>

        <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-xl mb-3">
          <div>
            <p className="font-medium text-gray-900">Background Blur</p>
            <p className="text-xs text-gray-500">Blur effect behind the card</p>
          </div>
          <Switch
            checked={formData.backdrop_blur !== false}
            onCheckedChange={(checked) => setFormData({ ...formData, backdrop_blur: checked })}
          />
        </div>

        {!formData.is_card_transparent && (
          <div className="flex items-center gap-4 p-3 bg-white border border-gray-200 rounded-xl">
            <div className="w-10 h-10 rounded-full overflow-hidden relative border border-gray-200">
              <input 
                type="color" 
                value={formData.card_background_color || (formData.background_mode === 'dark' ? '#1f2937' : '#ffffff')}
                onChange={(e) => setFormData({ ...formData, card_background_color: e.target.value })}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <div 
                className="w-full h-full"
                style={{ backgroundColor: formData.card_background_color || (formData.background_mode === 'dark' ? '#1f2937' : '#ffffff') }}
              />
            </div>
            <div className="flex-1 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-900">Card Background Color</p>
                <p className="text-xs text-gray-500">Custom color for the profile card</p>
              </div>
              {formData.card_background_color && (
                <button 
                  onClick={() => setFormData({ ...formData, card_background_color: '' })}
                  className="text-xs text-red-500 hover:text-red-600"
                >
                  Reset
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Font Family */}
      <div className="space-y-3">
        <Label className="text-base font-medium flex items-center gap-2">
          <Type className="w-4 h-4" />
          Typography
        </Label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {FONTS.map((font) => (
            <button
              key={font.value}
              onClick={() => setFormData({ ...formData, font_family: font.value })}
              className={cn(
                "p-2 rounded-lg border text-sm transition-all",
                formData.font_family === font.value
                  ? "border-violet-600 bg-violet-50 text-violet-700 ring-1 ring-violet-600"
                  : "border-gray-200 hover:border-gray-300 text-gray-600"
              )}
              style={{ fontFamily: font.value === 'inter' ? 'sans-serif' : font.value }}
            >
              {font.label}
            </button>
          ))}
        </div>
      </div>

      {/* Buttons & Links */}
      <div className="space-y-3">
        <Label className="text-base font-medium uppercase text-gray-500 text-xs tracking-wider">Buttons & Links</Label>
        
        <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-xl">
          <span className="font-medium text-gray-700">Save contact button</span>
          <Switch 
            checked={formData.show_save_contact} 
            onCheckedChange={(checked) => setFormData({ ...formData, show_save_contact: checked })}
          />
        </div>
      </div>

      {/* Color Mode */}
      <div className="space-y-3">
        <Label className="text-base font-medium">Color Mode</Label>
        <div className="flex flex-wrap gap-3">
          <div className="relative">
             <div className="w-10 h-10 rounded-full overflow-hidden relative cursor-pointer ring-2 ring-offset-2 ring-transparent hover:ring-gray-300 transition-all">
                <input 
                  type="color" 
                  value={formData.theme_color || '#7C3AED'}
                  onChange={(e) => handleColorSelect(e.target.value)}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
                <div 
                  className="w-full h-full flex items-center justify-center bg-gradient-to-br from-violet-500 via-pink-500 to-orange-500"
                >
                  <span className="text-white text-xs font-bold">+</span>
                </div>
             </div>
          </div>
          
          {PRESET_COLORS.map((color) => (
            <button
              key={color}
              onClick={() => handleColorSelect(color)}
              className={cn(
                "w-10 h-10 rounded-full transition-all ring-2 ring-offset-2",
                formData.theme_color === color 
                  ? "ring-gray-900 scale-110" 
                  : "ring-transparent hover:scale-110"
              )}
              style={{ backgroundColor: color }}
            >
              {formData.theme_color === color && (
                <Check className="w-5 h-5 text-white mx-auto" />
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}