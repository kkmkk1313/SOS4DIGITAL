import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Copy, ExternalLink, Loader2, QrCode, BarChart3 } from 'lucide-react';
import { toast } from "sonner";
import QRCodeGenerator from '@/components/profile/QRCodeGenerator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function QRCodeManager({ profileId }) {
  const queryClient = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [newQR, setNewQR] = useState({ title: '', destination_url: '' });
  const [showQRDialog, setShowQRDialog] = useState(null);

  const { data: qrCodes = [], isLoading } = useQuery({
    queryKey: ['qrCodes', profileId],
    queryFn: () => base44.entities.QRCode.filter({ profile_id: profileId }),
    enabled: !!profileId
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const shortCode = Math.random().toString(36).substring(2, 8);
      return base44.entities.QRCode.create({
        profile_id: profileId,
        title: data.title,
        destination_url: data.destination_url,
        short_code: shortCode,
        scans: 0
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['qrCodes', profileId] });
      setShowCreate(false);
      setNewQR({ title: '', destination_url: '' });
      toast.success('QR code created!');
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, destination_url }) => 
      base44.entities.QRCode.update(id, { destination_url }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['qrCodes', profileId] });
      toast.success('QR code updated!');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.QRCode.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['qrCodes', profileId] });
      toast.success('QR code deleted');
    }
  });

  const handleCreate = () => {
    if (!newQR.title.trim() || !newQR.destination_url.trim()) {
      toast.error('Please fill in all fields');
      return;
    }
    createMutation.mutate(newQR);
  };

  const getQRUrl = (shortCode) => {
    return `${window.location.origin}${createPageUrl('QRRedirect')}?c=${shortCode}`;
  };

  const copyUrl = (shortCode) => {
    navigator.clipboard.writeText(getQRUrl(shortCode));
    toast.success('Link copied!');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-violet-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Dynamic QR Codes</h3>
          <p className="text-sm text-gray-500">Create unlimited QR codes that you can edit anytime</p>
        </div>
        <Button
          onClick={() => setShowCreate(true)}
          className="bg-violet-600 hover:bg-violet-700 rounded-full"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create QR Code
        </Button>
      </div>

      {showCreate && (
        <div className="bg-white border border-gray-200 rounded-xl p-6 space-y-4">
          <h4 className="font-semibold text-gray-900">New QR Code</h4>
          <div className="space-y-2">
            <Label>Title</Label>
            <Input
              placeholder="e.g., My Website, Instagram, Portfolio..."
              value={newQR.title}
              onChange={(e) => setNewQR({ ...newQR, title: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label>Destination URL</Label>
            <Input
              placeholder="https://example.com"
              value={newQR.destination_url}
              onChange={(e) => setNewQR({ ...newQR, destination_url: e.target.value })}
            />
          </div>
          <div className="flex gap-2">
            <Button onClick={handleCreate} disabled={createMutation.isPending}>
              {createMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
              Create
            </Button>
            <Button variant="outline" onClick={() => setShowCreate(false)}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {qrCodes.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-xl border border-gray-200">
          <QrCode className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-500">No QR codes yet</p>
          <p className="text-sm text-gray-400 mt-1">Create your first dynamic QR code</p>
        </div>
      ) : (
        <div className="space-y-4">
          {qrCodes.map((qr) => (
            <div key={qr.id} className="bg-white border border-gray-200 rounded-xl p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900">{qr.title}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <BarChart3 className="w-3 h-3 text-gray-400" />
                    <span className="text-xs text-gray-500">{qr.scans || 0} scans</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Dialog open={showQRDialog === qr.id} onOpenChange={(open) => setShowQRDialog(open ? qr.id : null)}>
                    <DialogTrigger asChild>
                      <Button size="sm" variant="outline">
                        <QrCode className="w-4 h-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>{qr.title}</DialogTitle>
                      </DialogHeader>
                      <div className="flex flex-col items-center py-4">
                        <QRCodeGenerator url={getQRUrl(qr.short_code)} size={250} />
                        <p className="text-xs text-gray-500 mt-4">Scan to visit: {qr.destination_url}</p>
                      </div>
                    </DialogContent>
                  </Dialog>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => deleteMutation.mutate(qr.id)}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <div className="space-y-2">
                  <Label className="text-xs text-gray-500">QR Code Link (Short URL)</Label>
                  <div className="flex gap-2">
                    <Input value={getQRUrl(qr.short_code)} readOnly className="bg-gray-50 text-sm" />
                    <Button size="sm" variant="outline" onClick={() => copyUrl(qr.short_code)}>
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-gray-500">Redirects To (Editable)</Label>
                  <div className="flex gap-2">
                    <Input
                      value={qr.destination_url}
                      onChange={(e) => updateMutation.mutate({ id: qr.id, destination_url: e.target.value })}
                      className="text-sm"
                      placeholder="https://example.com"
                    />
                    <Button size="sm" variant="outline" asChild>
                      <a href={qr.destination_url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}