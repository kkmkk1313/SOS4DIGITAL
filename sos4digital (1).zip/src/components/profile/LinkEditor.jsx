import React, { useState } from 'react';
import { Plus, Trash2, Link as LinkIcon, ChevronDown, Image, FileText, Music, Video, Search, Pencil, GripVertical } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { socialPlatforms, platformCategories, getAllPlatforms } from './SocialPlatforms';
import { countryCodes } from './CountryCodes';
import { PDFUploader, ImageGalleryUploader } from './MediaUploader';

export default function LinkEditor({ links = [], onLinksChange }) {
  const [newLink, setNewLink] = useState({
    platform: '',
    value: '',
    label: '',
    country_code: '+966',
    images: [],
    pdf: null
  });
  const [editingIndex, setEditingIndex] = useState(null);
  const [countrySearch, setCountrySearch] = useState('');
  const [countryOpen, setCountryOpen] = useState(false);
  const [linkSearch, setLinkSearch] = useState('');

  const allPlatforms = getAllPlatforms();
  
  const filteredCountries = countryCodes.filter(c => 
    !c.disabled && (
      c.country.toLowerCase().includes(countrySearch.toLowerCase()) ||
      c.code.includes(countrySearch)
    )
  );

  const handleAddLink = () => {
    const platform = socialPlatforms[newLink.platform];
    if (!platform) return;
    
    // Validate based on input type
    if (platform.inputType === 'image_gallery') {
      if (!newLink.images || newLink.images.length === 0) return;
    } else if (platform.inputType === 'pdf') {
      if (!newLink.pdf) return;
    } else {
      if (!newLink.value) return;
    }
    
    let finalValue = newLink.value;
    
    if (platform.inputType === 'phone') {
      const cleanNumber = newLink.value.replace(/[^\d]/g, '');
      finalValue = cleanNumber;
    }
    
    const linkToAdd = {
      platform: newLink.platform,
      value: finalValue || '',
      label: newLink.label || platform.name,
      category: platform.category,
      enabled: true
    };
    
    // Add type-specific properties
    if (platform.inputType === 'phone') {
      linkToAdd.country_code = newLink.country_code;
    }
    if (platform.inputType === 'image_gallery' && newLink.images) {
      linkToAdd.images = newLink.images;
    }
    if (platform.inputType === 'pdf' && newLink.pdf) {
      linkToAdd.pdf = newLink.pdf;
    }
    
    if (editingIndex !== null) {
      // Update existing link - completely replace it to ensure all properties are updated
      const updatedLinks = [...links];
      updatedLinks[editingIndex] = linkToAdd;
      onLinksChange(updatedLinks);
      setEditingIndex(null);
    } else {
      // Add new link
      onLinksChange([...links, linkToAdd]);
    }
    
    setNewLink({ platform: '', value: '', label: '', country_code: '+966', images: [], pdf: null });
  };

  const handleEditLink = (index) => {
    const link = links[index];
    setNewLink({
      platform: link.platform,
      value: link.value || '',
      label: link.label || '',
      country_code: link.country_code || '+966',
      images: link.images || [],
      pdf: link.pdf || null
    });
    setEditingIndex(index);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancelEdit = () => {
    setEditingIndex(null);
    setNewLink({ platform: '', value: '', label: '', country_code: '+966', images: [], pdf: null });
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    
    const items = Array.from(links);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    onLinksChange(items);
  };

  const handleRemoveLink = (index) => {
    const updated = links.filter((_, i) => i !== index);
    onLinksChange(updated);
  };

  const selectedPlatform = newLink.platform ? socialPlatforms[newLink.platform] : null;
  const selectedCountry = countryCodes.find(c => c.code === newLink.country_code);

  const renderInputField = () => {
    if (!selectedPlatform) return null;

    switch (selectedPlatform.inputType) {
      case 'phone':
        return (
          <div className="space-y-2">
            <Label>Phone Number</Label>
            <div className="flex gap-2">
              <Popover open={countryOpen} onOpenChange={setCountryOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-32 justify-between px-3">
                    <span className="flex items-center gap-2">
                      <span className="text-lg">{selectedCountry?.flag}</span>
                      <span className="text-sm">{selectedCountry?.code}</span>
                    </span>
                    <ChevronDown className="w-4 h-4 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-72 p-0" align="start">
                  <div className="p-2 border-b">
                    <Input
                      placeholder="Search country..."
                      value={countrySearch}
                      onChange={(e) => setCountrySearch(e.target.value)}
                      className="h-8"
                    />
                  </div>
                  <div className="max-h-60 overflow-y-auto">
                    {filteredCountries.map((country) => (
                      <button
                        key={`${country.code}-${country.iso}`}
                        type="button"
                        onClick={() => {
                          setNewLink({ ...newLink, country_code: country.code });
                          setCountrySearch('');
                          setCountryOpen(false);
                        }}
                        className={`w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-gray-100 ${
                          newLink.country_code === country.code ? 'bg-violet-50' : ''
                        }`}
                      >
                        <span className="text-xl">{country.flag}</span>
                        <span className="flex-1 text-sm">{country.country}</span>
                        <span className="text-sm text-gray-500">{country.code}</span>
                      </button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
              <Input
                placeholder="Phone number"
                value={newLink.value}
                onChange={(e) => setNewLink({ ...newLink, value: e.target.value.replace(/[^\d]/g, '') })}
                className="flex-1"
              />
            </div>
          </div>
        );

      case 'email':
        return (
          <div className="space-y-2">
            <Label>Email Address</Label>
            <Input
              type="email"
              placeholder="your@email.com"
              value={newLink.value}
              onChange={(e) => setNewLink({ ...newLink, value: e.target.value })}
            />
          </div>
        );



      case 'embed_video':
        return (
          <div className="space-y-2">
            <Label>Video URL</Label>
            <Input
              placeholder="Paste YouTube or Vimeo URL"
              value={newLink.value}
              onChange={(e) => setNewLink({ ...newLink, value: e.target.value })}
            />
            <p className="text-xs text-gray-500">Video will be embedded on your profile</p>
          </div>
        );

      case 'embed_audio':
        return (
          <div className="space-y-2">
            <Label>Audio URL</Label>
            <Input
              placeholder="Paste Spotify or SoundCloud URL"
              value={newLink.value}
              onChange={(e) => setNewLink({ ...newLink, value: e.target.value })}
            />
            <p className="text-xs text-gray-500">Audio player will be embedded on your profile</p>
          </div>
        );

      case 'username':
        return (
          <div className="space-y-2">
            <Label>Username</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">@</span>
              <Input
                placeholder={selectedPlatform.placeholder}
                value={newLink.value}
                onChange={(e) => setNewLink({ ...newLink, value: e.target.value })}
                className="pl-8"
              />
            </div>
          </div>
        );

      default:
        return (
          <div className="space-y-2">
            <Label>URL</Label>
            <Input
              placeholder={selectedPlatform.placeholder}
              value={newLink.value}
              onChange={(e) => setNewLink({ ...newLink, value: e.target.value })}
            />
          </div>
        );
    }
  };

  const canAddLink = () => {
    if (!selectedPlatform) return false;
    if (selectedPlatform.inputType === 'image_gallery') return newLink.images?.length > 0;
    if (selectedPlatform.inputType === 'pdf') return !!newLink.pdf;
    return !!newLink.value;
  };

  const getLinkIcon = (link) => {
    const platform = socialPlatforms[link.platform];
    if (link.platform === 'image_gallery') return <Image className="w-5 h-5 text-violet-600" />;
    if (link.platform === 'pdf_document') return <FileText className="w-5 h-5 text-red-600" />;
    if (platform?.inputType === 'embed_audio') return <Music className="w-5 h-5" style={{ color: platform.color }} />;
    if (platform?.inputType === 'embed_video') return <Video className="w-5 h-5" style={{ color: platform.color }} />;
    if (platform?.icon) {
      return <img src={platform.icon} alt="" className="w-5 h-5 object-contain" />;
    }
    return <LinkIcon className="w-5 h-5" style={{ color: platform?.color || '#6B7280' }} />;
  };

  // Group links by category and filter by search
  const groupedLinks = links.reduce((acc, link, index) => {
    const platform = socialPlatforms[link.platform];
    const searchLower = linkSearch.toLowerCase();
    
    // Filter by search
    const matchesSearch = !linkSearch || 
      (link.label || platform?.name || '').toLowerCase().includes(searchLower) ||
      (link.value || '').toLowerCase().includes(searchLower) ||
      (platform?.name || '').toLowerCase().includes(searchLower);
    
    if (!matchesSearch) return acc;
    
    const category = link.category || 'other';
    if (!acc[category]) acc[category] = [];
    acc[category].push({ ...link, originalIndex: index });
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      {/* Add New Link Form */}
      <div className="bg-gray-50 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">
            {editingIndex !== null ? 'Edit Link' : 'Add New Link'}
          </h3>
          {editingIndex !== null && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleCancelEdit}
              className="text-gray-500"
            >
              Cancel
            </Button>
          )}
        </div>
        
        <div className="space-y-2">
          <Label>Select Platform</Label>
          <Select
            value={newLink.platform}
            onValueChange={(value) => setNewLink({ platform: value, value: '', label: '', country_code: '+966', images: [], pdf: null })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Choose a platform..." />
            </SelectTrigger>
            <SelectContent className="max-h-80">
              {Object.entries(platformCategories).map(([catKey, catName]) => (
                <div key={catKey}>
                  <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 bg-gray-50 sticky top-0">
                    {catName}
                  </div>
                  {allPlatforms
                    .filter(p => p.category === catKey)
                    .map(platform => (
                      <SelectItem key={platform.key} value={platform.key}>
                        <div className="flex items-center gap-2">
                          {platform.icon ? (
                            <img src={platform.icon} alt="" className="w-5 h-5 object-contain" />
                          ) : platform.key === 'image_gallery' ? (
                            <Image className="w-5 h-5 text-violet-600" />
                          ) : platform.key === 'pdf_document' ? (
                            <FileText className="w-5 h-5 text-red-600" />
                          ) : (
                            <LinkIcon className="w-5 h-5" style={{ color: platform.color }} />
                          )}
                          <span>{platform.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                </div>
              ))}
            </SelectContent>
          </Select>
        </div>

        {renderInputField()}

        {selectedPlatform && (
          <div className="space-y-2">
            <Label>Custom Label (optional)</Label>
            <Input
              placeholder={`Default: ${selectedPlatform.name}`}
              value={newLink.label}
              onChange={(e) => setNewLink({ ...newLink, label: e.target.value })}
            />
          </div>
        )}

        <Button 
          type="button"
          onClick={handleAddLink}
          disabled={!canAddLink()}
          className="w-full bg-gray-900 hover:bg-gray-800"
        >
          {editingIndex !== null ? (
            <>
              <Pencil className="w-4 h-4 mr-2" />
              Update Link
            </>
          ) : (
            <>
              <Plus className="w-4 h-4 mr-2" />
              Add Link
            </>
          )}
        </Button>
      </div>

      {/* Existing Links */}
      {links.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Your Links ({links.length})</h3>
          </div>
          
          {/* Search Bar */}
          {links.length > 3 && (
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search your links..."
                value={linkSearch}
                onChange={(e) => setLinkSearch(e.target.value)}
                className="pl-9"
              />
            </div>
          )}
          
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="links">
              {(provided) => (
                <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-2">
                  {links
                    .map((link, index) => {
                      const platform = socialPlatforms[link.platform];
                      const searchLower = linkSearch.toLowerCase();
                      const matchesSearch = !linkSearch || 
                        (link.label || platform?.name || '').toLowerCase().includes(searchLower) ||
                        (link.value || '').toLowerCase().includes(searchLower) ||
                        (platform?.name || '').toLowerCase().includes(searchLower);
                      
                      if (!matchesSearch) return null;

                      return (
                        <Draggable key={index} draggableId={`link-${index}`} index={index}>
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              className={`flex items-center gap-3 p-4 bg-white border border-gray-200 rounded-xl transition-shadow ${
                                snapshot.isDragging ? 'shadow-lg' : ''
                              }`}
                            >
                              <div
                                {...provided.dragHandleProps}
                                className="flex-shrink-0 text-gray-400 hover:text-gray-600 cursor-grab active:cursor-grabbing"
                              >
                                <GripVertical className="w-5 h-5" />
                              </div>
                              
                              <div className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: (platform?.color || '#6B7280') + '15' }}>
                                {getLinkIcon(link)}
                              </div>
                              
                              <div className="flex-1 min-w-0">
                                <div className={`font-medium ${link.enabled === false ? 'text-gray-400' : 'text-gray-900'}`}>
                                  {link.label || platform?.name}
                                  {link.enabled === false && (
                                    <span className="ml-2 text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full">Hidden</span>
                                  )}
                                </div>
                                <div className={`text-sm truncate ${link.enabled === false ? 'text-gray-400' : 'text-gray-500'}`}>
                                  {link.images?.length ? `${link.images.length} images` : 
                                   link.pdf ? link.pdf.name :
                                   link.country_code ? `${link.country_code} ${link.value}` : 
                                   link.value}
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-2">
                                <Switch
                                  checked={link.enabled !== false}
                                  onCheckedChange={(checked) => {
                                    const updatedLinks = [...links];
                                    updatedLinks[index] = { 
                                      ...updatedLinks[index], 
                                      enabled: checked
                                    };
                                    onLinksChange(updatedLinks);
                                  }}
                                />
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleEditLink(index)}
                                  className="text-gray-400 hover:text-violet-600"
                                >
                                  <Pencil className="w-4 h-4" />
                                </Button>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleRemoveLink(index)}
                                  className="text-gray-400 hover:text-red-500"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          )}
                        </Draggable>
                      );
                    })}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        </div>
      )}
    </div>
  );
}