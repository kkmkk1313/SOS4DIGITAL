import React, { useEffect, useRef } from 'react';
import { Download } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function QRCodeGenerator({ url, size = 200, showDownload = true }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!url || !canvasRef.current) return;

    // QR Code generation using a simple algorithm
    generateQRCode(url, canvasRef.current, size);
  }, [url, size]);

  const generateQRCode = (text, canvas, qrSize) => {
    const ctx = canvas.getContext('2d');
    
    // Use Google Charts API for QR code
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      canvas.width = qrSize;
      canvas.height = qrSize;
      ctx.fillStyle = 'white';
      ctx.fillRect(0, 0, qrSize, qrSize);
      ctx.drawImage(img, 0, 0, qrSize, qrSize);
    };
    img.src = `https://api.qrserver.com/v1/create-qr-code/?size=${qrSize}x${qrSize}&data=${encodeURIComponent(text)}&margin=10`;
  };

  const downloadQR = () => {
    if (!canvasRef.current) return;
    
    const link = document.createElement('a');
    link.download = 'qr-code.png';
    link.href = canvasRef.current.toDataURL('image/png');
    link.click();
  };

  if (!url) {
    return (
      <div 
        className="flex items-center justify-center bg-gray-100 rounded-xl"
        style={{ width: size, height: size }}
      >
        <span className="text-gray-400 text-sm text-center px-4">
          Save your profile to generate QR code
        </span>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-200">
        <canvas ref={canvasRef} width={size} height={size} />
      </div>
      {showDownload && (
        <Button 
          variant="outline" 
          onClick={downloadQR}
          className="rounded-full"
        >
          <Download className="w-4 h-4 mr-2" />
          Download QR Code
        </Button>
      )}
    </div>
  );
}