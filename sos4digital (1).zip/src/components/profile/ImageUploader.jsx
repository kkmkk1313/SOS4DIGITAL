import React, { useRef, useState, useEffect } from 'react';
import { Camera, Upload, X, Loader2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";

export default function ImageUploader({ 
  currentImage, 
  onImageChange, 
  type = "avatar",
  className = "",
  previewStyles = {}
}) {
  const fileInputRef = useRef(null);
  const [isUploading, setIsUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState(currentImage || null);

  // Sync with parent's currentImage
  useEffect(() => {
    setPreviewUrl(currentImage || null);
  }, [currentImage]);

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) {
      console.log('No file selected');
      return;
    }

    // Reset input value to allow selecting the same file again
    e.target.value = '';

    console.log('File selected:', file.name, file.type, file.size);

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }

    // Validate file size (max 20MB)
    if (file.size > 20 * 1024 * 1024) {
      toast.error('Image size should be less than 20MB');
      return;
    }

    setIsUploading(true);
    
    // Create local preview immediately
    const localPreview = URL.createObjectURL(file);
    setPreviewUrl(localPreview);
    console.log('Local preview created');

    // Upload to server
    try {
      console.log('Starting upload...');
      const result = await base44.integrations.Core.UploadFile({ file });
      console.log('Upload result:', result);
      
      // Check for file_url or url in the response
      const uploadedUrl = result?.file_url || result?.url;

      if (uploadedUrl) {
        console.log('Upload successful, URL:', uploadedUrl);
        // Update local state immediately to ensure UI feedback
        setPreviewUrl(uploadedUrl);
        // Propagate to parent
        onImageChange(uploadedUrl);
        toast.success('Image uploaded successfully!');
      } else {
        console.error('No file_url or url in result:', result);
        toast.error('Upload failed. Please try again.');
        // Revert to previous image if upload failed
        setPreviewUrl(currentImage || null);
      }
    } catch (error) {
      console.error('Upload failed:', error);
      toast.error('Failed to upload image. Please try again.');
      setPreviewUrl(currentImage || null);
    } finally {
      setIsUploading(false);
      // Clean up the local preview URL
      URL.revokeObjectURL(localPreview);
    }
  };

  const handleRemove = () => {
    setPreviewUrl(null);
    onImageChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const triggerFileInput = () => {
    console.log('Triggering file input');
    fileInputRef.current?.click();
  };

  if (type === "avatar") {
    return (
      <div className={`relative inline-block w-full h-full ${className}`}>
        <div className="w-full h-full rounded-full overflow-hidden bg-gray-100 border-4 border-white shadow-lg relative">
          {previewUrl ? (
            <img 
              src={previewUrl} 
              alt="Avatar" 
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-violet-100 to-purple-100">
              <Camera className="w-10 h-10 text-violet-400" />
            </div>
          )}
          {isUploading && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <Loader2 className="w-8 h-8 text-white animate-spin" />
            </div>
          )}
        </div>
        
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png, image/jpeg, image/jpg, image/gif, image/webp"
          onChange={handleFileSelect}
          className="hidden"
          id={`avatar-upload-${type}`}
        />
        
        <button
          type="button"
          onClick={triggerFileInput}
          disabled={isUploading}
          className="absolute bottom-0 right-0 w-9 h-9 bg-violet-600 hover:bg-violet-700 rounded-full flex items-center justify-center text-white shadow-lg transition-colors disabled:opacity-50"
        >
          {isUploading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Camera className="w-4 h-4" />
          )}
        </button>
        
        {previewUrl && !isUploading && (
          <button
            type="button"
            onClick={handleRemove}
            className="absolute top-0 right-0 w-6 h-6 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center text-white shadow-lg transition-colors"
          >
            <X className="w-3 h-3" />
          </button>
        )}
      </div>
    );
  }

  // Cover image
  if (type === "cover") {
    const { 
      header_size = 'standard',
      header_color,
      cover_fit = 'cover',
      cover_zoom = 1,
      cover_offset_x = 50,
      cover_offset_y = 50
    } = previewStyles;

    return (
      <div className={`relative ${className}`}>
        <div 
          className={`w-full rounded-xl overflow-hidden relative transition-all duration-300 ${
            !header_color && !previewUrl ? 'bg-gradient-to-br from-violet-50 to-purple-100' : ''
          } ${
             header_size === 'full' ? 'h-auto min-h-[160px]' : 
             header_size === 'square' ? 'aspect-square' :
             header_size === 'tall' ? 'h-64 md:h-80' : 
             'h-40 md:h-52'
          }`}
          style={header_color ? { backgroundColor: header_color } : undefined}
        >
          {previewUrl ? (
             <img 
               src={previewUrl} 
               alt="Cover" 
               className={`w-full transition-all duration-300 ${
                 header_size === 'full' ? 'h-auto block' : 'h-full'
               } ${
                 header_size !== 'full' ? (cover_fit === 'contain' ? 'object-contain' : 'object-cover') : ''
               }`}
               style={{ 
                 objectPosition: header_size !== 'full' ? `${cover_offset_x}% ${cover_offset_y}%` : undefined,
                 transform: header_size !== 'full' ? `scale(${cover_zoom})` : undefined,
                 transformOrigin: header_size !== 'full' ? `${cover_offset_x}% ${cover_offset_y}%` : undefined
               }}
             />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center cursor-pointer min-h-[160px]" onClick={triggerFileInput}>
              <Upload className="w-10 h-10 text-violet-400 mb-2" />
              <span className="text-sm text-violet-500">Click to upload cover image</span>
            </div>
          )}
          {isUploading && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-10">
              <Loader2 className="w-10 h-10 text-white animate-spin" />
            </div>
          )}
        </div>
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/png, image/jpeg, image/jpg, image/gif, image/webp"
        onChange={handleFileSelect}
        className="hidden"
        id={`cover-upload-${type}`}
      />
      
      <div className="absolute bottom-3 right-3 flex gap-2">
        {previewUrl && !isUploading && (
          <Button
            type="button"
            size="sm"
            variant="destructive"
            onClick={handleRemove}
            className="rounded-full"
          >
            <X className="w-4 h-4" />
          </Button>
        )}
        <Button
          type="button"
          size="sm"
          onClick={triggerFileInput}
          disabled={isUploading}
          className="bg-white/90 hover:bg-white text-gray-900 rounded-full"
        >
          {isUploading ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Camera className="w-4 h-4 mr-2" />
          )}
          {previewUrl ? 'Change' : 'Upload'}
        </Button>
      </div>
    </div>
  );
  }
  
  return null;
}