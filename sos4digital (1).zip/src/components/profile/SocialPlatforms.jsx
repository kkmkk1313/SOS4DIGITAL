// Social Media Platforms with logos and configurations
export const socialPlatforms = {
  // ===== SOCIAL MEDIA =====
  instagram: {
    name: "Instagram",
    icon: "https://cdn.simpleicons.org/instagram",
    color: "#E4405F",
    category: "social",
    placeholder: "username",
    urlPrefix: "https://instagram.com/",
    inputType: "username"
  },
  tiktok: {
    name: "TikTok",
    icon: "https://cdn.simpleicons.org/tiktok",
    color: "#000000",
    category: "social",
    placeholder: "username",
    urlPrefix: "https://tiktok.com/@",
    inputType: "username"
  },
  snapchat: {
    name: "Snapchat",
    icon: "https://cdn.simpleicons.org/snapchat",
    color: "#FFFC00",
    category: "social",
    placeholder: "username",
    urlPrefix: "https://snapchat.com/add/",
    inputType: "username"
  },
  twitter: {
    name: "X (Twitter)",
    icon: "https://cdn.simpleicons.org/x",
    color: "#000000",
    category: "social",
    placeholder: "username",
    urlPrefix: "https://x.com/",
    inputType: "username"
  },
  facebook: {
    name: "Facebook",
    icon: "https://cdn.simpleicons.org/facebook",
    color: "#1877F2",
    category: "social",
    placeholder: "username",
    urlPrefix: "https://facebook.com/",
    inputType: "username"
  },
  youtube: {
    name: "YouTube",
    icon: "https://cdn.simpleicons.org/youtube",
    color: "#FF0000",
    category: "social",
    placeholder: "channel name",
    urlPrefix: "https://youtube.com/@",
    inputType: "username"
  },
  pinterest: {
    name: "Pinterest",
    icon: "https://cdn.simpleicons.org/pinterest",
    color: "#E60023",
    category: "social",
    placeholder: "username",
    urlPrefix: "https://pinterest.com/",
    inputType: "username"
  },
  threads: {
    name: "Threads",
    icon: "https://cdn.simpleicons.org/threads",
    color: "#000000",
    category: "social",
    placeholder: "username",
    urlPrefix: "https://threads.net/@",
    inputType: "username"
  },
  reddit: {
    name: "Reddit",
    icon: "https://cdn.simpleicons.org/reddit",
    color: "#FF4500",
    category: "social",
    placeholder: "username",
    urlPrefix: "https://reddit.com/user/",
    inputType: "username"
  },
  tumblr: {
    name: "Tumblr",
    icon: "https://cdn.simpleicons.org/tumblr",
    color: "#36465D",
    category: "social",
    placeholder: "username",
    urlPrefix: "https://tumblr.com/",
    inputType: "username"
  },
  vimeo: {
    name: "Vimeo",
    icon: "https://cdn.simpleicons.org/vimeo",
    color: "#1AB7EA",
    category: "social",
    placeholder: "username",
    urlPrefix: "https://vimeo.com/",
    inputType: "username"
  },

  // ===== PROFESSIONAL =====
  linkedin: {
    name: "LinkedIn",
    icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/b7ba97ef5_linkedin-logo-linkedin-logo-transparent-linkedin-icon-transparent-free-free-png.png",
    color: "#0A66C2",
    category: "professional",
    placeholder: "username",
    urlPrefix: "https://linkedin.com/in/",
    inputType: "username"
  },
  github: {
    name: "GitHub",
    icon: "https://cdn.simpleicons.org/github",
    color: "#181717",
    category: "professional",
    placeholder: "username",
    urlPrefix: "https://github.com/",
    inputType: "username"
  },
  gitlab: {
    name: "GitLab",
    icon: "https://cdn.simpleicons.org/gitlab",
    color: "#FC6D26",
    category: "professional",
    placeholder: "username",
    urlPrefix: "https://gitlab.com/",
    inputType: "username"
  },
  behance: {
    name: "Behance",
    icon: "https://cdn.simpleicons.org/behance",
    color: "#1769FF",
    category: "professional",
    placeholder: "username",
    urlPrefix: "https://behance.net/",
    inputType: "username"
  },
  dribbble: {
    name: "Dribbble",
    icon: "https://cdn.simpleicons.org/dribbble",
    color: "#EA4C89",
    category: "professional",
    placeholder: "username",
    urlPrefix: "https://dribbble.com/",
    inputType: "username"
  },
  medium: {
    name: "Medium",
    icon: "https://cdn.simpleicons.org/medium",
    color: "#000000",
    category: "professional",
    placeholder: "username",
    urlPrefix: "https://medium.com/@",
    inputType: "username"
  },
  stackoverflow: {
    name: "Stack Overflow",
    icon: "https://cdn.simpleicons.org/stackoverflow",
    color: "#F58025",
    category: "professional",
    placeholder: "user ID",
    urlPrefix: "https://stackoverflow.com/users/",
    inputType: "username"
  },
  figma: {
    name: "Figma",
    icon: "https://cdn.simpleicons.org/figma",
    color: "#F24E1E",
    category: "professional",
    placeholder: "profile URL",
    urlPrefix: "",
    inputType: "url"
  },
  notion: {
    name: "Notion",
    icon: "https://cdn.simpleicons.org/notion",
    color: "#000000",
    category: "professional",
    placeholder: "page URL",
    urlPrefix: "",
    inputType: "url"
  },

  // ===== MESSAGING =====
  whatsapp: {
    name: "WhatsApp",
    icon: "https://cdn.simpleicons.org/whatsapp",
    color: "#25D366",
    category: "messaging",
    placeholder: "phone number",
    urlPrefix: "https://wa.me/",
    inputType: "phone"
  },
  whatsapp_business: {
    name: "WhatsApp Business",
    icon: "https://cdn.simpleicons.org/whatsapp",
    color: "#128C7E",
    category: "business",
    placeholder: "phone number",
    urlPrefix: "https://wa.me/",
    inputType: "phone"
  },
  telegram: {
    name: "Telegram",
    icon: "https://cdn.simpleicons.org/telegram",
    color: "#26A5E4",
    category: "messaging",
    placeholder: "username",
    urlPrefix: "https://t.me/",
    inputType: "username"
  },
  signal: {
    name: "Signal",
    icon: "https://cdn.simpleicons.org/signal",
    color: "#3A76F0",
    category: "messaging",
    placeholder: "phone number",
    urlPrefix: "",
    inputType: "phone"
  },
  discord: {
    name: "Discord",
    icon: "https://cdn.simpleicons.org/discord",
    color: "#5865F2",
    category: "messaging",
    placeholder: "username",
    urlPrefix: "",
    inputType: "username"
  },
  viber: {
    name: "Viber",
    icon: "https://cdn.simpleicons.org/viber",
    color: "#7360F2",
    category: "messaging",
    placeholder: "phone number",
    urlPrefix: "",
    inputType: "phone"
  },
  wechat: {
    name: "WeChat",
    icon: "https://cdn.simpleicons.org/wechat",
    color: "#07C160",
    category: "messaging",
    placeholder: "WeChat ID",
    urlPrefix: "",
    inputType: "username"
  },
  line: {
    name: "LINE",
    icon: "https://cdn.simpleicons.org/line",
    color: "#00C300",
    category: "messaging",
    placeholder: "LINE ID",
    urlPrefix: "",
    inputType: "username"
  },
  // ===== BUSINESS & MEETINGS =====
  calendly: {
    name: "Calendly",
    icon: "https://cdn.simpleicons.org/calendly",
    color: "#006BFF",
    category: "business",
    placeholder: "username",
    urlPrefix: "https://calendly.com/",
    inputType: "username"
  },
  zoom: {
    name: "Zoom",
    icon: "https://cdn.simpleicons.org/zoom",
    color: "#2D8CFF",
    category: "business",
    placeholder: "meeting link or personal link",
    urlPrefix: "",
    inputType: "url"
  },
  google_meet: {
    name: "Google Meet",
    icon: "https://cdn.simpleicons.org/googlemeet",
    color: "#00897B",
    category: "business",
    placeholder: "meeting link",
    urlPrefix: "",
    inputType: "url"
  },
  microsoft_teams: {
    name: "Microsoft Teams",
    icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/d392b3ace_Microsoft_Teams.png",
    color: "#6264A7",
    category: "business",
    placeholder: "meeting link",
    urlPrefix: "",
    inputType: "url"
  },
  // ===== EMAIL =====
  gmail: {
    name: "Gmail",
    icon: "https://cdn.simpleicons.org/gmail",
    color: "#EA4335",
    category: "business",
    placeholder: "email address",
    urlPrefix: "mailto:",
    inputType: "email"
  },
  outlook: {
    name: "Outlook",
    icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/e8c91db69_Microsoft_Outlook-Logowine.png",
    color: "#0078D4",
    category: "business",
    placeholder: "email address",
    urlPrefix: "mailto:",
    inputType: "email"
  },
  email: {
    name: "Email",
    icon: "https://cdn.simpleicons.org/maildotru",
    color: "#005FF9",
    category: "business",
    placeholder: "email address",
    urlPrefix: "mailto:",
    inputType: "email"
  },

  // ===== GOOGLE SERVICES =====
  google_maps: {
    name: "Google Maps Location",
    icon: "https://cdn.simpleicons.org/googlemaps",
    color: "#4285F4",
    category: "business",
    placeholder: "Google Maps link or Place ID",
    urlPrefix: "",
    inputType: "url"
  },
  google_reviews: {
    name: "Google Reviews",
    icon: "https://cdn.simpleicons.org/google",
    color: "#4285F4",
    category: "business",
    placeholder: "Google Reviews link",
    urlPrefix: "",
    inputType: "url"
  },
  google_business: {
    name: "Google Business Profile",
    icon: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/c3d0764f7_Google-Business-Profile-logo.jpg",
    color: "#4285F4",
    category: "business",
    placeholder: "Google Business link",
    urlPrefix: "",
    inputType: "url"
  },
  google_drive: {
    name: "Google Drive",
    icon: "https://cdn.simpleicons.org/googledrive",
    color: "#4285F4",
    category: "business",
    placeholder: "shared link",
    urlPrefix: "",
    inputType: "url"
  },

  // ===== MORE BUSINESS =====
  hubspot: {
    name: "HubSpot",
    icon: "https://cdn.simpleicons.org/hubspot",
    color: "#FF7A59",
    category: "business",
    placeholder: "meeting link",
    urlPrefix: "",
    inputType: "url"
  },

  asana: {
    name: "Asana",
    icon: "https://cdn.simpleicons.org/asana",
    color: "#F06A6A",
    category: "business",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },
  trello: {
    name: "Trello",
    icon: "https://cdn.simpleicons.org/trello",
    color: "#0052CC",
    category: "business",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },

  clickup: {
    name: "ClickUp",
    icon: "https://cdn.simpleicons.org/clickup",
    color: "#7B68EE",
    category: "business",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },
  jira: {
    name: "Jira",
    icon: "https://cdn.simpleicons.org/jira",
    color: "#0052CC",
    category: "business",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },
  intercom: {
    name: "Intercom",
    icon: "https://cdn.simpleicons.org/intercom",
    color: "#6AFDEF",
    category: "business",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },
  zendesk: {
    name: "Zendesk",
    icon: "https://cdn.simpleicons.org/zendesk",
    color: "#03363D",
    category: "business",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },

  // ===== PAYMENT =====
  paypal: {
    name: "PayPal",
    icon: "https://cdn.simpleicons.org/paypal",
    color: "#00457C",
    category: "payment",
    placeholder: "username",
    urlPrefix: "https://paypal.me/",
    inputType: "username"
  },
  venmo: {
    name: "Venmo",
    icon: "https://cdn.simpleicons.org/venmo",
    color: "#3D95CE",
    category: "payment",
    placeholder: "username",
    urlPrefix: "https://venmo.com/",
    inputType: "username"
  },
  cashapp: {
    name: "Cash App",
    icon: "https://cdn.simpleicons.org/cashapp",
    color: "#00D632",
    category: "payment",
    placeholder: "$cashtag",
    urlPrefix: "https://cash.app/",
    inputType: "username"
  },
  stripe: {
    name: "Stripe",
    icon: "https://cdn.simpleicons.org/stripe",
    color: "#008CDD",
    category: "payment",
    placeholder: "payment link",
    urlPrefix: "",
    inputType: "url"
  },
  wise: {
    name: "Wise",
    icon: "https://cdn.simpleicons.org/wise",
    color: "#9FE870",
    category: "payment",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },
  revolut: {
    name: "Revolut",
    icon: "https://cdn.simpleicons.org/revolut",
    color: "#0075EB",
    category: "payment",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },
  patreon: {
    name: "Patreon",
    icon: "https://cdn.simpleicons.org/patreon",
    color: "#FF424D",
    category: "payment",
    placeholder: "username",
    urlPrefix: "https://patreon.com/",
    inputType: "username"
  },
  kofi: {
    name: "Ko-fi",
    icon: "https://cdn.simpleicons.org/kofi",
    color: "#FF5E5B",
    category: "payment",
    placeholder: "username",
    urlPrefix: "https://ko-fi.com/",
    inputType: "username"
  },
  buymeacoffee: {
    name: "Buy Me a Coffee",
    icon: "https://cdn.simpleicons.org/buymeacoffee",
    color: "#FFDD00",
    category: "payment",
    placeholder: "username",
    urlPrefix: "https://buymeacoffee.com/",
    inputType: "username"
  },

  // ===== E-COMMERCE =====
  shopify: {
    name: "Shopify Store",
    icon: "https://cdn.simpleicons.org/shopify",
    color: "#7AB55C",
    category: "business",
    placeholder: "store URL",
    urlPrefix: "",
    inputType: "url"
  },
  etsy: {
    name: "Etsy",
    icon: "https://cdn.simpleicons.org/etsy",
    color: "#F16521",
    category: "business",
    placeholder: "shop name",
    urlPrefix: "https://etsy.com/shop/",
    inputType: "username"
  },

  ebay: {
    name: "eBay",
    icon: "https://cdn.simpleicons.org/ebay",
    color: "#E53238",
    category: "business",
    placeholder: "seller profile",
    urlPrefix: "",
    inputType: "url"
  },
  gumroad: {
    name: "Gumroad",
    icon: "https://cdn.simpleicons.org/gumroad",
    color: "#36A9AE",
    category: "business",
    placeholder: "username",
    urlPrefix: "https://gumroad.com/",
    inputType: "username"
  },

  // ===== MUSIC & ENTERTAINMENT =====
  spotify: {
    name: "Spotify",
    icon: "https://cdn.simpleicons.org/spotify",
    color: "#1DB954",
    category: "media",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },
  apple_music: {
    name: "Apple Music",
    icon: "https://cdn.simpleicons.org/applemusic",
    color: "#FA243C",
    category: "media",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },
  soundcloud: {
    name: "SoundCloud",
    icon: "https://cdn.simpleicons.org/soundcloud",
    color: "#FF5500",
    category: "media",
    placeholder: "username",
    urlPrefix: "https://soundcloud.com/",
    inputType: "username"
  },
  twitch: {
    name: "Twitch",
    icon: "https://cdn.simpleicons.org/twitch",
    color: "#9146FF",
    category: "media",
    placeholder: "username",
    urlPrefix: "https://twitch.tv/",
    inputType: "username"
  },
  bandcamp: {
    name: "Bandcamp",
    icon: "https://cdn.simpleicons.org/bandcamp",
    color: "#629AA9",
    category: "media",
    placeholder: "artist name",
    urlPrefix: "https://",
    inputType: "username"
  },

  tidal: {
    name: "Tidal",
    icon: "https://cdn.simpleicons.org/tidal",
    color: "#000000",
    category: "media",
    placeholder: "profile link",
    urlPrefix: "",
    inputType: "url"
  },

  // ===== MEDIA EMBEDS =====
  youtube_video: {
    name: "YouTube Video (Embed)",
    icon: "https://cdn.simpleicons.org/youtube",
    color: "#FF0000",
    category: "media",
    placeholder: "YouTube video URL",
    urlPrefix: "",
    inputType: "embed_video"
  },
  vimeo_video: {
    name: "Vimeo Video (Embed)",
    icon: "https://cdn.simpleicons.org/vimeo",
    color: "#1AB7EA",
    category: "media",
    placeholder: "Vimeo video URL",
    urlPrefix: "",
    inputType: "embed_video"
  },
  spotify_embed: {
    name: "Spotify (Embed Audio)",
    icon: "https://cdn.simpleicons.org/spotify",
    color: "#1DB954",
    category: "media",
    placeholder: "Spotify track/album/playlist URL",
    urlPrefix: "",
    inputType: "embed_audio"
  },
  soundcloud_embed: {
    name: "SoundCloud (Embed Audio)",
    icon: "https://cdn.simpleicons.org/soundcloud",
    color: "#FF5500",
    category: "media",
    placeholder: "SoundCloud track URL",
    urlPrefix: "",
    inputType: "embed_audio"
  },

  // ===== OTHER =====
  linktree: {
    name: "Linktree",
    icon: "https://cdn.simpleicons.org/linktree",
    color: "#43E55E",
    category: "other",
    placeholder: "username",
    urlPrefix: "https://linktr.ee/",
    inputType: "username"
  },
  website: {
    name: "Website",
    icon: null,
    color: "#6B7280",
    category: "other",
    placeholder: "https://yourwebsite.com",
    urlPrefix: "",
    inputType: "url"
  },
  custom: {
    name: "Custom Link",
    icon: null,
    color: "#6B7280",
    category: "other",
    placeholder: "full URL",
    urlPrefix: "",
    inputType: "url"
  }
};

export const platformCategories = {
  social: "Social Media",
  professional: "Professional",
  messaging: "Messaging",
  business: "Business",
  payment: "Payment",
  media: "Media & Content",
  other: "Other"
};

export const getPlatformsByCategory = (category) => {
  return Object.entries(socialPlatforms)
    .filter(([_, platform]) => platform.category === category)
    .map(([key, platform]) => ({ key, ...platform }));
};

export const getAllPlatforms = () => {
  return Object.entries(socialPlatforms).map(([key, platform]) => ({ key, ...platform }));
};