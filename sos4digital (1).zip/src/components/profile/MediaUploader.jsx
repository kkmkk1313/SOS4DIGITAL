import React, { useRef, useState } from 'react';
import { Upload, X, Loader2, FileText, Image, Plus } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";

export function PDFUploader({ currentPdf, onPdfChange }) {
  const fileInputRef = useRef(null);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast.error('Please select a PDF file');
      return;
    }

    if (file.size > 100 * 1024 * 1024) {
      toast.error('PDF size should be less than 100MB');
      return;
    }

    setIsUploading(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      if (result?.file_url) {
        onPdfChange({ url: result.file_url, name: file.name });
        toast.success('PDF uploaded!');
      }
    } catch (error) {
      console.error('Upload failed:', error);
      toast.error('Failed to upload PDF');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-3">
      <input
        ref={fileInputRef}
        type="file"
        accept="application/pdf"
        onChange={handleFileSelect}
        className="hidden"
      />
      
      {currentPdf ? (
        <div className="flex items-center gap-3 p-3 bg-red-50 border border-red-200 rounded-lg">
          <FileText className="w-8 h-8 text-red-600" />
          <div className="flex-1 min-w-0">
            <p className="font-medium text-gray-900 truncate">{currentPdf.name || 'Document.pdf'}</p>
            <a href={currentPdf.url} target="_blank" rel="noopener noreferrer" className="text-sm text-red-600 hover:underline">
              View PDF
            </a>
          </div>
          <Button size="sm" variant="ghost" onClick={() => onPdfChange(null)}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      ) : (
        <Button
          type="button"
          variant="outline"
          onClick={() => fileInputRef.current?.click()}
          disabled={isUploading}
          className="w-full h-20 border-dashed"
        >
          {isUploading ? (
            <Loader2 className="w-5 h-5 animate-spin mr-2" />
          ) : (
            <FileText className="w-5 h-5 mr-2" />
          )}
          {isUploading ? 'Uploading...' : 'Upload PDF (CV, Brochure, Menu)'}
        </Button>
      )}
    </div>
  );
}

export function ImageGalleryUploader({ images = [], onImagesChange, maxImages = 10 }) {
  const fileInputRef = useRef(null);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    const remainingSlots = maxImages - images.length;
    if (files.length > remainingSlots) {
      toast.error(`You can only add ${remainingSlots} more images`);
      return;
    }

    setIsUploading(true);
    const newImages = [];

    for (const file of files) {
      if (!file.type.startsWith('image/')) continue;
      if (file.size > 100 * 1024 * 1024) {
        toast.error(`${file.name} is too large (max 100MB)`);
        continue;
      }

      try {
        const result = await base44.integrations.Core.UploadFile({ file });
        if (result?.file_url) {
          newImages.push(result.file_url);
        }
      } catch (error) {
        console.error('Upload failed:', error);
      }
    }

    if (newImages.length > 0) {
      onImagesChange([...images, ...newImages]);
      toast.success(`${newImages.length} image(s) uploaded!`);
    }
    setIsUploading(false);
  };

  const removeImage = (index) => {
    const updated = images.filter((_, i) => i !== index);
    onImagesChange(updated);
  };

  return (
    <div className="space-y-3">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileSelect}
        className="hidden"
      />
      
      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
        {images.map((url, index) => (
          <div key={index} className="relative aspect-square rounded-lg overflow-hidden bg-gray-100">
            <img src={url} alt="" className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => removeImage(index)}
              className="absolute top-1 right-1 w-6 h-6 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center text-white"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
        
        {images.length < maxImages && (
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="aspect-square rounded-lg border-2 border-dashed border-gray-300 hover:border-violet-400 flex flex-col items-center justify-center text-gray-400 hover:text-violet-500 transition-colors"
          >
            {isUploading ? (
              <Loader2 className="w-6 h-6 animate-spin" />
            ) : (
              <>
                <Plus className="w-6 h-6" />
                <span className="text-xs mt-1">Add</span>
              </>
            )}
          </button>
        )}
      </div>
      <p className="text-xs text-gray-500">{images.length}/{maxImages} images</p>
    </div>
  );
}