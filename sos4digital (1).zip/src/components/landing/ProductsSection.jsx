import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Star, ShoppingCart } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const products = [
  {
    id: 1,
    name: "Tap NFC Prestige Card",
    subtitle: "Custom Embossed Names",
    price: 36,
    rating: 4.8,
    reviews: 11,
    colors: ["black", "pink", "purple", "white"],
    image: "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=500&h=500&fit=crop",
    isNew: true
  },
  {
    id: 2,
    name: "Tap NFC Leather Keychain",
    subtitle: "Premium Collection",
    price: 24,
    rating: 4.9,
    reviews: 28,
    colors: ["burgundy", "black", "brown"],
    image: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=500&h=500&fit=crop"
  },
  {
    id: 3,
    name: "Tap NFC Phone Tag",
    subtitle: "Stick & Share",
    price: 15,
    rating: 4.7,
    reviews: 45,
    colors: ["black", "white"],
    image: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=500&h=500&fit=crop"
  },
  {
    id: 4,
    name: "Tap NFC Wristband",
    subtitle: "Active Edition",
    price: 29,
    rating: 4.6,
    reviews: 19,
    colors: ["black", "navy", "gray"],
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=500&fit=crop"
  }
];

export default function ProductsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState({});

  const colorMap = {
    black: "bg-gray-900",
    white: "bg-white border border-gray-200",
    pink: "bg-pink-400",
    purple: "bg-violet-500",
    burgundy: "bg-red-900",
    brown: "bg-amber-800",
    navy: "bg-blue-900",
    gray: "bg-gray-500"
  };

  return (
    <section className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center justify-between mb-12"
        >
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
              Featured collection
            </h2>
            <p className="mt-3 text-gray-600">
              Explore our premium NFC products
            </p>
          </div>
          <Button variant="outline" className="hidden md:flex rounded-full">
            View all
          </Button>
        </motion.div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="bg-white rounded-3xl overflow-hidden border border-gray-100 hover:border-violet-200 hover:shadow-2xl hover:shadow-violet-100/50 transition-all duration-500">
                {/* Image */}
                <div className="relative aspect-square bg-gray-50 overflow-hidden">
                  {product.isNew && (
                    <Badge className="absolute top-4 left-4 z-10 bg-violet-600 hover:bg-violet-600">
                      New
                    </Badge>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                    <div className="w-32 h-20 bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl shadow-xl transform group-hover:scale-110 group-hover:rotate-3 transition-transform duration-500" />
                  </div>
                  
                  {/* Quick add button */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileHover={{ opacity: 1, y: 0 }}
                    className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  >
                    <Button className="w-full bg-gray-900 hover:bg-gray-800 rounded-full">
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Add to cart
                    </Button>
                  </motion.div>
                </div>
                
                {/* Content */}
                <div className="p-5">
                  <h3 className="font-semibold text-gray-900 group-hover:text-violet-600 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-sm text-gray-500 mt-1">{product.subtitle}</p>
                  
                  {/* Rating */}
                  <div className="flex items-center gap-1 mt-3">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span className="text-sm font-medium text-gray-900">{product.rating}</span>
                    <span className="text-sm text-gray-400">({product.reviews})</span>
                  </div>
                  
                  {/* Colors */}
                  <div className="flex items-center gap-2 mt-4">
                    {product.colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => setSelectedColor({ ...selectedColor, [product.id]: color })}
                        className={`w-5 h-5 rounded-full ${colorMap[color]} ${
                          selectedColor[product.id] === color 
                            ? 'ring-2 ring-offset-2 ring-violet-500' 
                            : ''
                        } transition-all`}
                      />
                    ))}
                  </div>
                  
                  {/* Price */}
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-xl font-bold text-gray-900">
                      ${product.price}
                    </span>
                    <span className="text-sm text-gray-400">USD</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* Mobile view all button */}
        <div className="mt-8 text-center md:hidden">
          <Button variant="outline" className="rounded-full">
            View all products
          </Button>
        </div>
      </div>
    </section>
  );
}