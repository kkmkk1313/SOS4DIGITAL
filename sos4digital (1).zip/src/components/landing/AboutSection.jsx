import React from 'react';
import { motion } from 'framer-motion';
import { Wifi, QrCode, Zap } from 'lucide-react';

export default function AboutSection() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image/Visual */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-square bg-gradient-to-br from-violet-100 to-purple-50 rounded-3xl overflow-hidden">
              <div className="absolute inset-0 flex items-center justify-center">
                {/* Animated card representation */}
                <motion.div 
                  animate={{ 
                    rotateY: [0, 10, 0, -10, 0],
                    rotateX: [0, 5, 0, -5, 0]
                  }}
                  transition={{ 
                    duration: 6, 
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="w-72 h-44 bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl shadow-2xl p-6 relative"
                  style={{ transformStyle: 'preserve-3d' }}
                >
                  {/* NFC icon */}
                  <div className="absolute top-4 right-4">
                    <Wifi className="w-8 h-8 text-white/30 rotate-90" />
                  </div>
                  
                  {/* Card content */}
                  <div className="absolute bottom-6 left-6">
                    <div className="text-white/50 text-xs mb-1">tap.</div>
                    <div className="text-white font-medium">John Smith</div>
                    <div className="text-white/70 text-sm">CEO & Founder</div>
                  </div>
                  
                  {/* Shine effect */}
                  <motion.div 
                    animate={{ x: [-200, 400] }}
                    transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent skew-x-12"
                  />
                </motion.div>
              </div>
              
              {/* Floating elements */}
              <motion.div
                animate={{ y: [-10, 10, -10] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="absolute top-20 right-20 w-16 h-16 bg-white rounded-2xl shadow-lg flex items-center justify-center"
              >
                <QrCode className="w-8 h-8 text-violet-600" />
              </motion.div>
              
              <motion.div
                animate={{ y: [10, -10, 10] }}
                transition={{ duration: 5, repeat: Infinity }}
                className="absolute bottom-20 left-20 w-14 h-14 bg-violet-600 rounded-xl shadow-lg flex items-center justify-center"
              >
                <Zap className="w-7 h-7 text-white" />
              </motion.div>
            </div>
          </motion.div>
          
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight">
              What is a digital
              <span className="block text-violet-600">business card?</span>
            </h2>
            
            <p className="mt-8 text-lg text-gray-600 leading-relaxed">
              In today's fast-paced business world, our Digital Business Card represents the cutting edge of networking. It's an eco-friendly, tech-savvy solution, enabling you to share your contact information instantly and effortlessly.
            </p>
            
            <p className="mt-6 text-lg text-gray-600 leading-relaxed">
              Powered by Near Field Communication (NFC) and QR code technology, our digital card transforms the traditional business card into a dynamic, interactive experience.
            </p>
            
            <div className="mt-10 flex flex-wrap gap-4">
              <div className="flex items-center gap-3 bg-gray-50 px-5 py-3 rounded-full">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-sm font-medium text-gray-700">Eco-Friendly</span>
              </div>
              <div className="flex items-center gap-3 bg-gray-50 px-5 py-3 rounded-full">
                <div className="w-2 h-2 bg-violet-500 rounded-full" />
                <span className="text-sm font-medium text-gray-700">NFC Enabled</span>
              </div>
              <div className="flex items-center gap-3 bg-gray-50 px-5 py-3 rounded-full">
                <div className="w-2 h-2 bg-blue-500 rounded-full" />
                <span className="text-sm font-medium text-gray-700">QR Code Ready</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}