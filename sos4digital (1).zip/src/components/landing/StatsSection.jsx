import React from 'react';
import { motion } from 'framer-motion';
import { Building2, Zap, Globe } from 'lucide-react';

const stats = [
  {
    icon: Building2,
    value: "1000+",
    label: "Organizations",
    description: "Many companies trust our technology in digitalizing their business cards."
  },
  {
    icon: Zap,
    value: "1,000,000+",
    label: "Interactions Made",
    description: "Connections made everyday on our app, makes it easy for people to share their info."
  },
  {
    icon: Globe,
    value: "65+",
    label: "Countries",
    description: "People around the world trust our technology."
  }
];

export default function StatsSection() {
  return (
    <section className="py-24 bg-gray-900 relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, white 1px, transparent 0)`,
          backgroundSize: '40px 40px'
        }} />
      </div>
      
      {/* Gradient orbs */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-violet-600/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-6 relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white">
            Be a part of the largest community
            <span className="block text-violet-400">in MENA region.</span>
          </h2>
        </motion.div>
        
        <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15 }}
              className="text-center"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-violet-500/20 mb-6">
                <stat.icon className="w-8 h-8 text-violet-400" />
              </div>
              <div className="text-5xl md:text-6xl font-bold text-white mb-2">
                {stat.value}
              </div>
              <div className="text-xl font-semibold text-violet-400 mb-3">
                {stat.label}
              </div>
              <p className="text-gray-400 max-w-xs mx-auto">
                {stat.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}