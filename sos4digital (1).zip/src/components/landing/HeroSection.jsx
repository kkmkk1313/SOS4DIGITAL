import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen bg-white overflow-hidden">
      {/* Subtle gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-violet-50/50 to-white pointer-events-none" />
      
      {/* Content */}
      <div className="relative max-w-7xl mx-auto px-6 pt-32 pb-20">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-4xl mx-auto"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 bg-violet-100 text-violet-700 px-4 py-2 rounded-full text-sm font-medium mb-8"
          >
            <Sparkles className="w-4 h-4" />
            The Future of Networking
          </motion.div>
          
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 leading-tight tracking-tight">
            Tap Into Advanced
            <span className="block bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
              Networking
            </span>
          </h1>
          
          <p className="mt-8 text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
            The Future of Digital Business Cards. Share your contact information instantly with a single tap.
          </p>
          
          <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-gray-900 hover:bg-gray-800 text-white px-8 py-6 text-lg rounded-full group"
            >
              Start For Free Now
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="px-8 py-6 text-lg rounded-full border-2 border-gray-200 hover:bg-gray-50"
            >
              For Teams
            </Button>
          </div>
        </motion.div>
        
        {/* Phone mockups */}
        <motion.div 
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="mt-20 relative"
        >
          <div className="flex justify-center items-end gap-4 md:gap-8">
            {/* Left phone */}
            <motion.div 
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="hidden md:block w-48 lg:w-64"
            >
              <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/60 border border-gray-100 p-3">
                <div className="bg-gray-50 rounded-2xl p-4">
                  <div className="text-xs text-gray-400 mb-3">Contacts (5)</div>
                  <div className="space-y-3">
                    {['Sarah Ahmed', 'Mike Johnson', 'Lisa Chen'].map((name, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-400 to-purple-500" />
                        <div>
                          <div className="text-sm font-medium text-gray-800">{name}</div>
                          <div className="text-xs text-gray-400">Marketing</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Center phone - main */}
            <motion.div 
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="w-64 md:w-72 lg:w-80 z-10"
            >
              <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-gray-300/50 border border-gray-100 p-3">
                {/* Phone notch */}
                <div className="flex justify-center mb-2">
                  <div className="w-24 h-6 bg-black rounded-full" />
                </div>
                <div className="bg-gradient-to-b from-violet-50 to-white rounded-3xl p-6 text-center">
                  <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-orange-400 via-pink-500 to-violet-600 mb-4" />
                  <h3 className="font-semibold text-gray-900">Sarah Sami</h3>
                  <p className="text-sm text-gray-500">Marketing Manager</p>
                  <div className="flex justify-center gap-4 mt-6">
                    <div className="w-12 h-12 rounded-full bg-violet-100 flex items-center justify-center">
                      <svg className="w-5 h-5 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                      </svg>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-violet-100 flex items-center justify-center">
                      <svg className="w-5 h-5 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-violet-100 flex items-center justify-center">
                      <svg className="w-5 h-5 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Right phone */}
            <motion.div 
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="hidden md:block w-48 lg:w-64"
            >
              <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/60 border border-gray-100 p-3">
                <div className="bg-gray-50 rounded-2xl p-4">
                  <div className="text-xs text-gray-400 mb-3">Analytics</div>
                  <div className="text-3xl font-bold text-gray-900 mb-1">1.6K</div>
                  <div className="text-sm text-gray-500 mb-4">Total Taps</div>
                  <div className="h-16 flex items-end gap-1">
                    {[40, 65, 45, 80, 60, 90, 75].map((h, i) => (
                      <div 
                        key={i} 
                        className="flex-1 bg-gradient-to-t from-violet-500 to-violet-400 rounded-t"
                        style={{ height: `${h}%` }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}