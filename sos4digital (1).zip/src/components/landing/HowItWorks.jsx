import React from 'react';
import { motion } from 'framer-motion';
import { Package, Download, Smartphone, Users } from 'lucide-react';
import { Button } from "@/components/ui/button";

const steps = [
  {
    icon: Package,
    title: "Get a tap product that suits you",
    description: "Select from variety of different products.",
    cta: "View Collections",
    color: "bg-violet-600"
  },
  {
    icon: Download,
    title: "Create Your Free Profile Now",
    description: "Download our free app and create your profile, add your info and your social media accounts for free!",
    cta: "Download App",
    color: "bg-blue-600"
  },
  {
    icon: Smartphone,
    title: "Activate Your Product",
    description: "Whenever you receive your product, activate it from the app.",
    color: "bg-purple-600"
  },
  {
    icon: Users,
    title: "Start Networking",
    description: "You can now share your info to others with ease!",
    color: "bg-pink-600"
  }
];

export default function HowItWorks() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
            How it works
          </h2>
        </motion.div>
        
        {/* Steps */}
        <div className="relative">
          {/* Connection line */}
          <div className="hidden lg:block absolute top-24 left-0 right-0 h-0.5 bg-gradient-to-r from-violet-200 via-purple-200 to-pink-200" />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6">
            {steps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15 }}
                className="relative"
              >
                {/* Step number */}
                <div className="flex items-center justify-center mb-8">
                  <div className={`w-16 h-16 rounded-2xl ${step.color} flex items-center justify-center relative z-10 shadow-lg`}>
                    <step.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-3">
                    <span className="text-xs font-bold text-gray-400 bg-white px-2">
                      STEP {index + 1}
                    </span>
                  </div>
                </div>
                
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">
                    {step.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed mb-4">
                    {step.description}
                  </p>
                  {step.cta && (
                    <Button 
                      variant="link" 
                      className="text-violet-600 hover:text-violet-700 p-0 h-auto font-semibold"
                    >
                      {step.cta} →
                    </Button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}