import React from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  BarChart3, 
  Share2, 
  Palette, 
  Globe, 
  Shield 
} from 'lucide-react';
import { Button } from "@/components/ui/button";

const features = [
  {
    icon: Users,
    title: "Contacts Management",
    description: "Organize and manage all your connections in one place with smart categorization.",
    color: "from-blue-500 to-blue-600"
  },
  {
    icon: BarChart3,
    title: "Track Performance",
    description: "Get detailed analytics on who's viewing your profile and how they interact.",
    color: "from-violet-500 to-purple-600"
  },
  {
    icon: Share2,
    title: "Customized Sharing",
    description: "Share different information with different contacts based on context.",
    color: "from-pink-500 to-rose-600"
  },
  {
    icon: Palette,
    title: "Personalized Profiles",
    description: "Create stunning profiles that reflect your personal brand and style.",
    color: "from-orange-500 to-amber-600"
  },
  {
    icon: Globe,
    title: "Multi-Language",
    description: "Support for multiple languages to connect with a global audience.",
    color: "from-green-500 to-emerald-600"
  },
  {
    icon: Shield,
    title: "Privacy Control",
    description: "Full control over what information you share and with whom.",
    color: "from-cyan-500 to-teal-600"
  }
];

export default function FeaturesSection() {
  return (
    <section className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
            Features
          </h2>
          <p className="mt-6 text-xl text-gray-600">
            Get to know more about our solution
          </p>
          <Button className="mt-8 bg-violet-600 hover:bg-violet-700 rounded-full px-8">
            Download The App Now
          </Button>
        </motion.div>
        
        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="bg-white rounded-3xl p-8 h-full border border-gray-100 hover:border-violet-200 hover:shadow-xl hover:shadow-violet-100/50 transition-all duration-300">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}