import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2 } from 'lucide-react';

export default function QRRedirect() {
  const [error, setError] = useState(null);

  useEffect(() => {
    const redirect = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const code = urlParams.get('c');

      if (!code) {
        setError('Invalid QR code');
        return;
      }

      try {
        const qrCodes = await base44.entities.QRCode.filter({ short_code: code });
        const qrCode = qrCodes[0];

        if (!qrCode) {
          setError('QR code not found');
          return;
        }

        // Increment scan count
        await base44.entities.QRCode.update(qrCode.id, { 
          scans: (qrCode.scans || 0) + 1 
        });

        // Redirect
        window.location.href = qrCode.destination_url;
      } catch (err) {
        console.error(err);
        setError('Failed to load QR code');
      }
    };

    redirect();
  }, []);

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Error</h2>
          <p className="text-gray-500">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <Loader2 className="w-10 h-10 animate-spin text-violet-600 mx-auto mb-4" />
        <p className="text-gray-500">Redirecting...</p>
      </div>
    </div>
  );
}