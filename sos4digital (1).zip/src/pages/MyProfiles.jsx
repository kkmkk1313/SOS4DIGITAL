import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { 
  Plus, 
  Loader2, 
  LogOut, 
  QrCode, 
  Copy, 
  ExternalLink, 
  Pencil, 
  Trash2,
  User,
  Search,
  BarChart3,
  Crown,
  Shield,
  Sparkles,
  Import,
  Link as LinkIcon,
  Image as ImageIcon,
  Upload,
  FileText
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import QRCodeGenerator from '@/components/profile/QRCodeGenerator';

export default function MyProfiles() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewDialog, setShowNewDialog] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [newProfileName, setNewProfileName] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [showQR, setShowQR] = useState(null);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importUrl, setImportUrl] = useState('');
  const [importFile, setImportFile] = useState(null);
  const [isImporting, setIsImporting] = useState(false);
  const [importUsername, setImportUsername] = useState('');

  // Fetch current user
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  // Fetch all user's profiles
  const { data: profiles = [], isLoading: profilesLoading } = useQuery({
    queryKey: ['allProfiles', user?.email],
    queryFn: () => base44.entities.Profile.filter({ created_by: user?.email }),
    enabled: !!user?.email
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Profile.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allProfiles'] });
      toast.success('Profile deleted');
    }
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Profile.create(data),
    onSuccess: (newProfile) => {
      queryClient.invalidateQueries({ queryKey: ['allProfiles'] });
      setShowNewDialog(false);
      setNewUsername('');
      setNewProfileName('');
      toast.success('Profile created!');
      navigate(`${createPageUrl('EditProfile')}?id=${newProfile.id}`);
    },
    onError: (error) => {
      toast.error('Failed to create profile');
      console.error(error);
    }
  });

  const handleCreateProfile = async () => {
    if (!newUsername.trim()) {
      toast.error('Please enter a username');
      return;
    }

    const usernameRegex = /^[a-zA-Z0-9_-]+$/;
    if (!usernameRegex.test(newUsername)) {
      toast.error('Username can only contain letters, numbers, underscores and hyphens');
      return;
    }

    // Check if username is globally unique
    try {
      const existingProfiles = await base44.entities.Profile.filter({ username: newUsername.toLowerCase() });
      if (existingProfiles && existingProfiles.length > 0) {
        toast.error('This username is already taken. Please choose another one.');
        return;
      }
    } catch (error) {
      console.error("Error checking username uniqueness:", error);
      toast.error('Error verifying username availability');
      return;
    }

    // Check Limits
    if (!checkProfileLimit()) return;

    setIsCreating(true);
    await createMutation.mutateAsync({
      username: newUsername.toLowerCase(),
      full_name: newProfileName || '',
      email: user?.email || '',
      links: []
    });
    setIsCreating(false);
  };

  const checkProfileLimit = () => {
    const isAdmin = user?.role === 'admin';
    let profileLimit = 2; // Default free limit
    const now = new Date();

    if (isAdmin) {
      profileLimit = Infinity;
    } else if (user?.subscription_tier === 'pro' || user?.subscription_tier === 'enterprise') {
       const expiry = user.subscription_expires_at ? new Date(user.subscription_expires_at) : null;
       if (expiry && expiry > now) {
          profileLimit = user.custom_profile_limit || Infinity;
       } else {
          profileLimit = 2;
       }
    } else if (user?.custom_profile_limit && user.custom_profile_limit > 2) {
       profileLimit = user.custom_profile_limit;
    }

    if (profiles.length >= profileLimit) {
      setShowNewDialog(false);
      setShowImportDialog(false);
      setShowUpgradeDialog(true);
      return false;
    }
    return true;
  };

  const handleImportProfile = async () => {
    if (!importUsername.trim()) {
      toast.error('Please enter a target username');
      return;
    }
    if (!importUrl && !importFile) {
      toast.error('Please provide a URL or upload a file');
      return;
    }

    setIsImporting(true);

    try {
      // 1. Check Limit
      if (!checkProfileLimit()) {
        setIsImporting(false);
        return;
      }

      // 2. Check Uniqueness
      const cleanUsername = importUsername.toLowerCase().replace(/[^a-z0-9_-]/g, '');
      const existingProfiles = await base44.entities.Profile.filter({ username: cleanUsername });
      if (existingProfiles && existingProfiles.length > 0) {
        toast.error('Username taken. Please choose another.');
        setIsImporting(false);
        return;
      }

      // 3. Upload File if needed
      let fileUrl = null;
      if (importFile) {
        toast.info('Uploading file...');
        try {
           const uploadRes = await base44.integrations.Core.UploadFile({ file: importFile });
           fileUrl = uploadRes.file_url || uploadRes.url;
        } catch (uploadErr) {
           console.error("Upload failed", uploadErr);
           throw new Error("Failed to upload image.");
        }
      }

      // 4. Call Import Function
      toast.info('Analyzing profile... this takes about 10 seconds.');
      let profileData = {};
      
      try {
        const response = await base44.functions.invoke('importProfile', {
          url: importUrl,
          file_url: fileUrl
        });

        if (response.data && response.data.error) {
           console.warn("Import function error:", response.data.error);
           // Don't throw, just warn and try to proceed with minimal data
           toast.warning("AI extraction had issues, creating basic profile.");
        } else {
           const extractedData = response.data;
           profileData = extractedData?.data || extractedData || {};
        }
      } catch (fnErr) {
        console.warn("Function invoke failed", fnErr);
        toast.warning("Could not auto-fill details. Creating basic profile.");
      }

      // 5. Create Profile
      console.log("Creating profile with data:", profileData);
      
      await createMutation.mutateAsync({
        username: cleanUsername,
        full_name: profileData.full_name || cleanUsername, // Fallback to username if name is missing
        title: profileData.title || '',
        company: profileData.company || '',
        bio: profileData.bio || '',
        email: profileData.email || user?.email || '',
        phone: profileData.phone || '',
        location: profileData.location || '',
        website: profileData.website || '',
        links: Array.isArray(profileData.links) ? profileData.links : [],
      });

      // 6. Cleanup
      setShowImportDialog(false);
      setImportUrl('');
      setImportFile(null);
      setImportUsername('');
      // toast.success is handled by mutation onSuccess

    } catch (error) {
      console.error('Import flow failed:', error);
      toast.error('Import failed: ' + (error.message || 'Unknown error'));
    } finally {
      setIsImporting(false);
    }
  };

  const handleDelete = (profile) => {
    if (window.confirm(`Delete profile "${profile.full_name || profile.username}"? This cannot be undone.`)) {
      deleteMutation.mutate(profile.id);
    }
  };

  const getProfileUrl = (username) => {
    return `${window.location.origin}${createPageUrl('PublicProfile')}?u=${username}`;
  };

  const copyUrl = (username) => {
    navigator.clipboard.writeText(getProfileUrl(username));
    toast.success('Link copied!');
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  const filteredProfiles = profiles.filter(p => 
    !searchQuery || 
    p.username?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.company?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (userLoading || profilesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40 select-none" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to={createPageUrl('Home')} className="flex items-center gap-2">
            <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/f80600f2a_WhatsApp_Image_2025-11-25_at_114437_AM-removebg-preview.png" alt="SOS4DIGITAL" className="h-8 w-8" />
            <span className="text-xl font-bold text-gray-900">SOS4DIGITAL</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link to={createPageUrl('FlipbookManager')}>
              <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-full select-none min-w-[44px] min-h-[44px]">
                <FileText className="w-4 h-4 sm:mr-2" />
                <span className="hidden sm:inline">PDF to Link</span>
              </Button>
            </Link>
            <Link to={createPageUrl('QRCodes')}>
              <Button variant="ghost" className="text-violet-600 hover:text-violet-700 hover:bg-violet-50 rounded-full select-none min-w-[44px] min-h-[44px]">
                <QrCode className="w-4 h-4 sm:mr-2" />
                <span className="hidden sm:inline">QR Codes</span>
              </Button>
            </Link>
            {user?.role === 'admin' && (
              <Link to={createPageUrl('Admin')}>
                <Button variant="ghost" className="text-violet-600 hover:text-violet-700 hover:bg-violet-50 rounded-full select-none min-w-[44px] min-h-[44px]">
                  <Shield className="w-4 h-4 sm:mr-2" />
                  <span className="hidden sm:inline">Admin</span>
                </Button>
              </Link>
            )}
            <Link to={createPageUrl('Settings')}>
              <Button variant="ghost" className="text-gray-600 hover:text-gray-700 hover:bg-gray-50 rounded-full select-none min-w-[44px] min-h-[44px]">
                <User className="w-4 h-4" />
              </Button>
            </Link>
            <span className="text-sm text-gray-500 hidden sm:block">{user?.email}</span>
            <Button variant="outline" onClick={handleLogout} className="rounded-full select-none min-w-[44px] min-h-[44px]">
              <LogOut className="w-4 h-4 sm:mr-2" />
              <span className="hidden sm:inline">Sign Out</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">My Profiles</h1>
            <p className="text-gray-500 mt-1">{profiles.length} profile{profiles.length !== 1 ? 's' : ''} created</p>
          </div>
          
          <div className="flex gap-2">
            <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" className="rounded-full border-violet-200 text-violet-700 hover:bg-violet-50 select-none">
                  <Import className="w-4 h-4 mr-2" />
                  Import
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Import Profile with AI</DialogTitle>
                </DialogHeader>
                <div className="py-4">
                  <p className="text-sm text-gray-500 mb-4">
                    Paste a link to your LinkedIn, Instagram, or other profile, or upload a screenshot. Our AI will build your profile automatically.
                  </p>

                  <div className="space-y-4 mb-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Target Username *</label>
                      <Input
                        placeholder="newusername"
                        value={importUsername}
                        onChange={(e) => setImportUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                      />
                    </div>
                  </div>

                  <Tabs defaultValue="url" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 mb-4">
                      <TabsTrigger value="url">
                        <LinkIcon className="w-4 h-4 mr-2" /> From URL
                      </TabsTrigger>
                      <TabsTrigger value="image">
                        <ImageIcon className="w-4 h-4 mr-2" /> From Image
                      </TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="url" className="space-y-4">
                      <div className="space-y-2">
                        <Input
                          placeholder="https://linkedin.com/in/..."
                          value={importUrl}
                          onChange={(e) => setImportUrl(e.target.value)}
                        />
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="image" className="space-y-4">
                      <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center hover:bg-gray-50 transition-colors relative">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => setImportFile(e.target.files?.[0])}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                        <div className="flex flex-col items-center gap-2">
                          <Upload className="w-8 h-8 text-gray-400" />
                          <span className="text-sm font-medium text-gray-600">
                            {importFile ? importFile.name : "Click to upload screenshot"}
                          </span>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>

                  <Button 
                    onClick={handleImportProfile}
                    disabled={isImporting || !importUsername || (!importUrl && !importFile)}
                    className="w-full mt-6 bg-violet-600 hover:bg-violet-700"
                  >
                    {isImporting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Analyzing with AI...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Generate Profile
                      </>
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={showNewDialog} onOpenChange={setShowNewDialog}>
              <DialogTrigger asChild>
                <Button className="bg-violet-600 hover:bg-violet-700 rounded-full select-none">
                  <Plus className="w-4 h-4 mr-2" />
                  Create New Profile
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Profile</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Username *</label>
                    <Input
                      placeholder="myprofile"
                      value={newUsername}
                      onChange={(e) => setNewUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                    />
                    <p className="text-xs text-gray-500">This will be your profile URL</p>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Profile Name (optional)</label>
                    <Input
                      placeholder="e.g., Personal, Business, Company..."
                      value={newProfileName}
                      onChange={(e) => setNewProfileName(e.target.value)}
                    />
                  </div>
                  <Button 
                    onClick={handleCreateProfile}
                    disabled={isCreating || !newUsername}
                    className="w-full bg-violet-600 hover:bg-violet-700"
                  >
                    {isCreating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                    Create Profile
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Search */}
        {/* Upgrade Dialog */}
        <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
          <DialogContent className="sm:max-w-md text-center">
            <div className="mx-auto w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center mb-4 shadow-lg shadow-orange-200">
              <Crown className="w-8 h-8 text-white" />
            </div>
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold text-center">Upgrade to Pro</DialogTitle>
            </DialogHeader>
            <div className="py-4 text-center space-y-4">
              <p className="text-gray-600">
                You've reached the limit of 2 free profiles. Upgrade to Pro to create unlimited profiles and unlock premium features.
              </p>
              <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
                <div className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <Sparkles className="w-4 h-4 text-violet-600" />
                  Pro Features Include:
                </div>
                <ul className="text-sm text-gray-600 text-left space-y-2 pl-2">
                  <li>• Unlimited Profiles</li>
                  <li>• Custom Domain Support</li>
                  <li>• Advanced Analytics</li>
                  <li>• Priority Support</li>
                </ul>
              </div>
              <div className="pt-2">
                <Button 
                  className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 text-white rounded-full h-12 text-lg shadow-lg" 
                  asChild
                >
                  <a href="mailto:coretap.bz@gmail.com?subject=Upgrade%20to%20Pro%20-%20SOS4DIGITAL">
                    Contact to Upgrade
                  </a>
                </Button>
                <p className="text-xs text-gray-400 mt-3">Email coretap.bz@gmail.com to activate your Pro account.</p>
                </div>
            </div>
          </DialogContent>
        </Dialog>

        {profiles.length > 5 && (
        <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search profiles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        )}

        {/* Profiles Grid */}
        {filteredProfiles.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {profiles.length === 0 ? 'No profiles yet' : 'No matching profiles'}
            </h3>
            <p className="text-gray-500 mb-6">
              {profiles.length === 0 ? 'Create your first digital business card' : 'Try a different search'}
            </p>
            {profiles.length === 0 && (
              <Button onClick={() => setShowNewDialog(true)} className="bg-violet-600 hover:bg-violet-700 rounded-full">
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Profile
              </Button>
            )}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredProfiles.map((profile) => (
              <div key={profile.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
                {/* Cover */}
                <div className="h-24 bg-gradient-to-br from-violet-500 to-purple-600 relative">
                  {profile.cover_url && (
                    <img src={profile.cover_url} alt="" className="w-full h-full object-cover" />
                  )}
                </div>
                
                {/* Avatar & Info */}
                <div className="px-4 pb-4">
                  <div className="flex items-end gap-3 -mt-8 mb-3">
                    <div className="w-16 h-16 rounded-full border-4 border-white overflow-hidden bg-white shadow">
                      {profile.avatar_url ? (
                        <img src={profile.avatar_url} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-violet-400 to-purple-500 text-white text-xl font-bold">
                          {(profile.full_name || profile.username || '?')[0].toUpperCase()}
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0 pb-1">
                      <h3 className="font-semibold text-gray-900 truncate">
                        {profile.full_name || profile.username}
                      </h3>
                      <p className="text-sm text-gray-500 truncate">@{profile.username}</p>
                    </div>
                  </div>

                  {profile.title && (
                    <p className="text-sm text-violet-600 mb-1 truncate">{profile.title}</p>
                  )}
                  {profile.company && (
                    <p className="text-sm text-gray-500 mb-3 truncate">at {profile.company}</p>
                  )}

                  <div className="flex items-center gap-4 mb-3">
                    <div className="text-xs text-gray-400">
                      {profile.links?.length || 0} links
                    </div>
                    <div className="flex items-center gap-1 text-xs text-violet-600 bg-violet-50 px-2 py-1 rounded-full">
                      <BarChart3 className="w-3 h-3" />
                      {profile.views || 0} views
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1 select-none min-h-[44px]"
                      onClick={() => navigate(`${createPageUrl('EditProfile')}?id=${profile.id}`)}
                    >
                      <Pencil className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyUrl(profile.username)}
                      className="select-none min-w-[44px] min-h-[44px]"
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                    <Dialog open={showQR === profile.id} onOpenChange={(open) => setShowQR(open ? profile.id : null)}>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="outline" className="select-none min-w-[44px] min-h-[44px]">
                          <QrCode className="w-3 h-3" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>QR Code - {profile.username}</DialogTitle>
                        </DialogHeader>
                        <div className="flex flex-col items-center py-4">
                          <QRCodeGenerator url={getProfileUrl(profile.username)} size={250} />
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button
                      size="sm"
                      variant="outline"
                      asChild
                      className="select-none min-w-[44px] min-h-[44px]"
                    >
                      <a href={getProfileUrl(profile.username)} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(profile)}
                      className="text-red-500 hover:text-red-600 hover:bg-red-50 select-none min-w-[44px] min-h-[44px]"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}