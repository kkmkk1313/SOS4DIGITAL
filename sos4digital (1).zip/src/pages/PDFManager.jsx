import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  FileText,
  Upload,
  Eye,
  Copy,
  Trash2,
  Lock,
  Globe,
  ExternalLink,
  Loader2,
  Search
} from 'lucide-react';
import { toast } from "sonner";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function PDFManager() {
  const queryClient = useQueryClient();
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [uploadData, setUploadData] = useState({
    title: '',
    description: '',
    access_type: 'public',
    password: '',
    file: null
  });
  const [uploading, setUploading] = useState(false);

  const { data: documents = [], isLoading } = useQuery({
    queryKey: ['pdfDocuments'],
    queryFn: () => base44.entities.PDFDocument.list('-created_date')
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.PDFDocument.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pdfDocuments'] });
      toast.success('PDF deleted');
    }
  });

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        toast.error('Please select a PDF file');
        return;
      }
      if (file.size > 50 * 1024 * 1024) {
        toast.error('File size must be less than 50MB');
        return;
      }
      setUploadData(prev => ({ ...prev, file, title: prev.title || file.name.replace('.pdf', '') }));
    }
  };

  const handleUpload = async () => {
    if (!uploadData.file || !uploadData.title) {
      toast.error('Please select a file and enter a title');
      return;
    }

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: uploadData.file });
      
      const shortCode = Math.random().toString(36).substring(2, 8);
      
      await base44.entities.PDFDocument.create({
        title: uploadData.title,
        description: uploadData.description,
        file_url,
        short_code: shortCode,
        access_type: uploadData.access_type,
        password: uploadData.password || null,
        file_size: uploadData.file.size,
        views: 0
      });

      queryClient.invalidateQueries({ queryKey: ['pdfDocuments'] });
      setShowUploadDialog(false);
      setUploadData({ title: '', description: '', access_type: 'public', password: '', file: null });
      toast.success('PDF uploaded successfully!');
    } catch (error) {
      console.error(error);
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const copyLink = (shortCode) => {
    const url = `${window.location.origin}${createPageUrl('PDFViewer')}?code=${shortCode}`;
    navigator.clipboard.writeText(url);
    toast.success('Link copied!');
  };

  const filteredDocs = documents.filter(doc => 
    doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-orange-500 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">PDF Library</h1>
                <p className="text-sm text-gray-500">Upload and share interactive PDFs</p>
              </div>
            </div>
            <Button 
              onClick={() => setShowUploadDialog(true)}
              className="bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600"
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload PDF
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search PDFs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-red-500" />
          </div>
        ) : filteredDocs.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No PDFs yet</h3>
              <p className="text-gray-500 mb-4">Upload your first PDF to get started</p>
              <Button onClick={() => setShowUploadDialog(true)}>
                <Upload className="w-4 h-4 mr-2" />
                Upload PDF
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDocs.map((doc) => (
              <Card key={doc.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg line-clamp-1">{doc.title}</CardTitle>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant={doc.access_type === 'public' ? 'default' : 'secondary'}>
                          {doc.access_type === 'public' ? <Globe className="w-3 h-3 mr-1" /> : <Lock className="w-3 h-3 mr-1" />}
                          {doc.access_type}
                        </Badge>
                        <span className="text-xs text-gray-500">{doc.views || 0} views</span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteMutation.mutate(doc.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {doc.description && (
                    <p className="text-sm text-gray-600 mb-4 line-clamp-2">{doc.description}</p>
                  )}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyLink(doc.short_code)}
                      className="flex-1"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Link
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      asChild
                      className="flex-1"
                    >
                      <Link to={`${createPageUrl('PDFViewer')}?code=${doc.short_code}`} target="_blank">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        View
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Upload PDF</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-red-400 transition-colors cursor-pointer">
              <input
                type="file"
                accept="application/pdf"
                onChange={handleFileSelect}
                className="hidden"
                id="pdf-upload"
              />
              <label htmlFor="pdf-upload" className="cursor-pointer">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-gray-700">
                  {uploadData.file ? uploadData.file.name : 'Click to upload PDF'}
                </p>
                <p className="text-xs text-gray-500 mt-1">Max 50MB</p>
              </label>
            </div>

            <div className="space-y-2">
              <Label>Title *</Label>
              <Input
                placeholder="My Document"
                value={uploadData.title}
                onChange={(e) => setUploadData(prev => ({ ...prev, title: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                placeholder="Optional description..."
                value={uploadData.description}
                onChange={(e) => setUploadData(prev => ({ ...prev, description: e.target.value }))}
                rows={2}
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <Label>Public Access</Label>
                <p className="text-xs text-gray-500">Anyone with link can view</p>
              </div>
              <Switch
                checked={uploadData.access_type === 'public'}
                onCheckedChange={(checked) => 
                  setUploadData(prev => ({ ...prev, access_type: checked ? 'public' : 'private' }))
                }
              />
            </div>

            {uploadData.access_type === 'private' && (
              <div className="space-y-2">
                <Label>Password (Optional)</Label>
                <Input
                  type="password"
                  placeholder="Enter password..."
                  value={uploadData.password}
                  onChange={(e) => setUploadData(prev => ({ ...prev, password: e.target.value }))}
                />
              </div>
            )}

            <Button 
              onClick={handleUpload}
              disabled={uploading || !uploadData.file}
              className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600"
            >
              {uploading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
              {uploading ? 'Uploading...' : 'Upload PDF'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}