import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Maximize,
  Minimize,
  Lock,
  Loader2
} from 'lucide-react';
import { toast } from "sonner";

export default function PDFViewer() {
  const urlParams = new URLSearchParams(window.location.search);
  const code = urlParams.get('code');
  
  const [authenticated, setAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [numPages, setNumPages] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const { data: documents, isLoading } = useQuery({
    queryKey: ['pdfDocument', code],
    queryFn: async () => {
      const docs = await base44.entities.PDFDocument.filter({ short_code: code });
      return docs;
    },
    enabled: !!code
  });

  const document = documents?.[0];

  useEffect(() => {
    if (document && document.access_type === 'public') {
      setAuthenticated(true);
      trackView();
    }
  }, [document]);

  const trackView = async () => {
    if (document) {
      try {
        await base44.entities.PDFDocument.update(document.id, {
          views: (document.views || 0) + 1
        });
      } catch (error) {
        console.error('Failed to track view:', error);
      }
    }
  };

  const handlePasswordSubmit = () => {
    if (document.password === password) {
      setAuthenticated(true);
      trackView();
      toast.success('Access granted');
    } else {
      toast.error('Incorrect password');
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <Loader2 className="w-12 h-12 animate-spin text-white" />
      </div>
    );
  }

  if (!document) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900 text-white p-4">
        <Lock className="w-16 h-16 mb-4 text-gray-500" />
        <h1 className="text-2xl font-bold mb-2">Document Not Found</h1>
        <p className="text-gray-400">This PDF does not exist or has been removed</p>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900 p-4">
        <div className="bg-white rounded-xl p-8 max-w-md w-full shadow-2xl">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-orange-500 rounded-full flex items-center justify-center">
              <Lock className="w-8 h-8 text-white" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-center mb-2">{document.title}</h2>
          <p className="text-center text-gray-600 mb-6">This document is password protected</p>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Enter Password</Label>
              <Input
                type="password"
                placeholder="Password..."
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handlePasswordSubmit()}
              />
            </div>
            <Button 
              onClick={handlePasswordSubmit}
              className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600"
            >
              Unlock Document
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex-1">
            <h1 className="text-lg font-semibold truncate">{document.title}</h1>
            {document.description && (
              <p className="text-sm text-gray-400 truncate">{document.description}</p>
            )}
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}
                className="text-white hover:bg-gray-700"
              >
                <ZoomOut className="w-5 h-5" />
              </Button>
              <span className="text-sm font-medium min-w-[4rem] text-center">
                {Math.round(zoom * 100)}%
              </span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setZoom(Math.min(2, zoom + 0.1))}
                className="text-white hover:bg-gray-700"
              >
                <ZoomIn className="w-5 h-5" />
              </Button>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleFullscreen}
              className="text-white hover:bg-gray-700"
            >
              {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </div>

      {/* PDF Viewer */}
      <div className="flex-1 overflow-auto flex items-center justify-center p-4 min-h-[calc(100vh-140px)]">
        <div 
          className="bg-white shadow-2xl"
          style={{ transform: `scale(${zoom})`, transformOrigin: 'center top' }}
        >
          <iframe
            src={`${document.file_url}#toolbar=0&navpanes=0`}
            className="w-[210mm] h-[297mm]"
            style={{ border: 'none' }}
            title={document.title}
          />
        </div>
      </div>

      {/* Footer Controls */}
      <div className="bg-gray-800 border-t border-gray-700 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            className="text-white hover:bg-gray-700"
            disabled={currentPage === 1}
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <span className="text-sm font-medium">
            Page {currentPage} of {numPages || '?'}
          </span>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCurrentPage(currentPage + 1)}
            className="text-white hover:bg-gray-700"
            disabled={numPages && currentPage === numPages}
          >
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}