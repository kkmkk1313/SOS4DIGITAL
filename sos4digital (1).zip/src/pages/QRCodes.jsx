import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Copy, ExternalLink, Loader2, QrCode, BarChart3, LogOut, ArrowLeft } from 'lucide-react';
import { toast } from "sonner";
import QRCodeGenerator from '@/components/profile/QRCodeGenerator';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function QRCodesPage() {
  const queryClient = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [newQR, setNewQR] = useState({ title: '', destination_url: '', profile_id: '' });
  const [showQRDialog, setShowQRDialog] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: profiles = [] } = useQuery({
    queryKey: ['userProfiles', user?.email],
    queryFn: () => base44.entities.Profile.filter({ created_by: user?.email }),
    enabled: !!user?.email
  });

  const { data: qrCodes = [], isLoading } = useQuery({
    queryKey: ['allQRCodes', user?.email],
    queryFn: async () => {
      const profileIds = profiles.map(p => p.id);
      if (profileIds.length === 0) return [];
      const allCodes = await base44.entities.QRCode.list();
      return allCodes.filter(qr => profileIds.includes(qr.profile_id));
    },
    enabled: !!user?.email && profiles.length > 0
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const shortCode = Math.random().toString(36).substring(2, 8);
      return base44.entities.QRCode.create({
        profile_id: data.profile_id,
        title: data.title,
        destination_url: data.destination_url,
        short_code: shortCode,
        scans: 0
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allQRCodes'] });
      setShowCreate(false);
      setNewQR({ title: '', destination_url: '', profile_id: '' });
      toast.success('QR code created!');
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, destination_url }) => 
      base44.entities.QRCode.update(id, { destination_url }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allQRCodes'] });
      toast.success('QR code updated!');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.QRCode.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allQRCodes'] });
      toast.success('QR code deleted');
    }
  });

  const handleCreate = () => {
    if (!newQR.title.trim() || !newQR.destination_url.trim() || !newQR.profile_id) {
      toast.error('Please fill in all fields');
      return;
    }
    createMutation.mutate(newQR);
  };

  const getQRUrl = (shortCode) => {
    return `${window.location.origin}${createPageUrl('QRRedirect')}?c=${shortCode}`;
  };

  const copyUrl = (shortCode) => {
    navigator.clipboard.writeText(getQRUrl(shortCode));
    toast.success('Link copied!');
  };

  const getProfileName = (profileId) => {
    const profile = profiles.find(p => p.id === profileId);
    return profile?.full_name || profile?.username || 'Unknown';
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40 select-none" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to={createPageUrl('MyProfiles')} className="flex items-center gap-2">
            <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/f80600f2a_WhatsApp_Image_2025-11-25_at_114437_AM-removebg-preview.png" alt="SOS4DIGITAL" className="h-8 w-8" />
            <span className="text-xl font-bold text-gray-900">SOS4DIGITAL</span>
          </Link>
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-500 hidden sm:block">{user?.email}</span>
            <Button variant="outline" onClick={() => base44.auth.logout()} className="rounded-full select-none min-w-[44px] min-h-[44px]">
              <LogOut className="w-4 h-4 sm:mr-2" />
              <span className="hidden sm:inline">Sign Out</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dynamic QR Codes</h1>
            <p className="text-gray-500 mt-1">Create unlimited QR codes • 100% Free</p>
          </div>
          <Button
            onClick={() => setShowCreate(true)}
            className="bg-violet-600 hover:bg-violet-700 rounded-full select-none"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create QR Code
          </Button>
        </div>

        {showCreate && (
          <div className="bg-white border border-gray-200 rounded-xl p-6 space-y-4 mb-6">
            <h4 className="font-semibold text-gray-900">New QR Code</h4>
            <div className="space-y-2">
              <Label>Profile</Label>
              <Select value={newQR.profile_id} onValueChange={(value) => setNewQR({ ...newQR, profile_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a profile" />
                </SelectTrigger>
                <SelectContent>
                  {profiles.map((profile) => (
                    <SelectItem key={profile.id} value={profile.id}>
                      {profile.full_name || profile.username}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Title</Label>
              <Input
                placeholder="e.g., My Website, Instagram, Portfolio..."
                value={newQR.title}
                onChange={(e) => setNewQR({ ...newQR, title: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Destination URL</Label>
              <Input
                placeholder="https://example.com"
                value={newQR.destination_url}
                onChange={(e) => setNewQR({ ...newQR, destination_url: e.target.value })}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleCreate} disabled={createMutation.isPending}>
                {createMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                Create
              </Button>
              <Button variant="outline" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </div>
        )}

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-violet-600" />
          </div>
        ) : qrCodes.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-gray-200">
            <QrCode className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-900 font-medium mb-1">No QR codes yet</p>
            <p className="text-sm text-gray-500">Create your first dynamic QR code - completely free!</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {qrCodes.map((qr) => (
              <div key={qr.id} className="bg-white border border-gray-200 rounded-xl p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">{qr.title}</h4>
                    <p className="text-xs text-gray-500 mt-1">From: {getProfileName(qr.profile_id)}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <BarChart3 className="w-3 h-3 text-violet-600" />
                      <span className="text-sm font-medium text-violet-600">{qr.scans || 0} scans</span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => deleteMutation.mutate(qr.id)}
                    className="text-red-500 hover:bg-red-50 select-none min-w-[44px] min-h-[44px]"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>

                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label className="text-xs text-gray-500">QR Link</Label>
                    <div className="flex gap-2">
                      <Input value={getQRUrl(qr.short_code)} readOnly className="bg-gray-50 text-xs" />
                      <Button size="sm" variant="outline" onClick={() => copyUrl(qr.short_code)} className="select-none min-w-[44px] min-h-[44px]">
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs text-gray-500">Redirects To</Label>
                    <div className="flex gap-2">
                      <Input
                        value={qr.destination_url}
                        onChange={(e) => updateMutation.mutate({ id: qr.id, destination_url: e.target.value })}
                        className="text-xs"
                      />
                      <Button size="sm" variant="outline" asChild className="select-none min-w-[44px] min-h-[44px]">
                        <a href={qr.destination_url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      </Button>
                    </div>
                  </div>

                  <Dialog open={showQRDialog === qr.id} onOpenChange={(open) => setShowQRDialog(open ? qr.id : null)}>
                    <DialogTrigger asChild>
                      <Button size="sm" variant="outline" className="w-full">
                        <QrCode className="w-4 h-4 mr-2" />
                        View QR Code
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>{qr.title}</DialogTitle>
                      </DialogHeader>
                      <div className="flex flex-col items-center py-4">
                        <QRCodeGenerator url={getQRUrl(qr.short_code)} size={250} />
                        <p className="text-xs text-gray-500 mt-4 text-center">Redirects to: {qr.destination_url}</p>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}