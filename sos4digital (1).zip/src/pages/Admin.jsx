import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  Loader2, 
  Trash2, 
  Search, 
  ExternalLink, 
  Shield, 
  User,
  Pencil,
  CreditCard,
  UserCog,
  QrCode,
  Download,
  Code,
  Database,
  FileCode,
  Crown,
  Bot,
  Sparkles
} from 'lucide-react';
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function Admin() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('profiles');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUserEmail, setSelectedUserEmail] = useState(null);
  const [isManagingUser, setIsManagingUser] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [isManagingVIP, setIsManagingVIP] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [vipForm, setVipForm] = useState({
    vip_mode: 'off',
    vip_loader_enabled: false,
    vip_loader_logo: '',
    vip_loader_text1: 'Initializing Digital Identity',
    vip_loader_text2: 'Access Granted',
    vip_robots_enabled: false,
    vip_robot_message: 'Welcome to the future',
    vip_floating_assistant: false,
    vip_assistant_greeting: 'How can I assist you?',
    vip_animations_enabled: false,
  });
  const [subscriptionForm, setSubscriptionForm] = useState({
    tier: 'free',
    duration: '1', // months
    customLimit: 2
  });

  // Fetch current user to verify admin status
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  // Fetch ALL profiles (Admin only capability usually)
  const { data: allProfiles = [], isLoading: profilesLoading, error } = useQuery({
    queryKey: ['adminAllProfiles'],
    queryFn: async () => {
       // Only admins can list all profiles without filter
       // Fetch top 1000 most recent profiles
       return await base44.entities.Profile.list('-created_date', 1000);
    },
    enabled: !!user && user.role === 'admin'
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Profile.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminAllProfiles'] });
      toast.success('Profile deleted by admin');
    }
  });

  const updateUserMutation = useMutation({
    mutationFn: async ({ email, data }) => {
       // Find user by email first
       const users = await base44.entities.User.filter({ email });
       if (!users || users.length === 0) {
           throw new Error("User record not found. They may need to login again.");
       }
       const user = users[0];
       return base44.entities.User.update(user.id, data);
    },
    onSuccess: () => {
      setIsManagingUser(false);
      setSelectedUserEmail(null);
      toast.success('User subscription updated successfully');
    },
    onError: (err) => {
      toast.error('Failed to update user: ' + err.message);
    }
  });

  const updateVIPMutation = useMutation({
    mutationFn: async ({ profileId, data }) => {
      return base44.entities.Profile.update(profileId, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminAllProfiles'] });
      setIsManagingVIP(false);
      setSelectedProfile(null);
      toast.success('VIP settings updated successfully');
    },
    onError: (err) => {
      toast.error('Failed to update VIP settings: ' + err.message);
    }
  });

  const handleManageUser = async (email) => {
    setSelectedUserEmail(email);
    setIsManagingUser(true);
    
    // Load current user settings
    try {
      const users = await base44.entities.User.filter({ email });
      if (users && users.length > 0) {
        const userData = users[0];
        setSubscriptionForm({
          tier: userData.subscription_tier || 'free',
          duration: '12',
          customLimit: userData.custom_profile_limit || 2
        });
      } else {
        // Default for new users
        setSubscriptionForm({
          tier: 'pro',
          duration: '12',
          customLimit: 100
        });
      }
    } catch (err) {
      console.error('Failed to load user data:', err);
      setSubscriptionForm({
        tier: 'pro',
        duration: '12',
        customLimit: 100
      });
    }
  };

  const handleSaveSubscription = () => {
    if (!selectedUserEmail) return;

    let expiresAt = new Date();
    const duration = parseInt(subscriptionForm.duration);
    expiresAt.setMonth(expiresAt.getMonth() + duration);

    updateUserMutation.mutate({
      email: selectedUserEmail,
      data: {
        subscription_tier: subscriptionForm.tier,
        subscription_expires_at: expiresAt.toISOString(),
        custom_profile_limit: parseInt(subscriptionForm.customLimit)
      }
    });
  };

  const handleDelete = (profile) => {
    if (window.confirm(`ADMIN ACTION: Delete profile "${profile.full_name || profile.username}"?`)) {
      deleteMutation.mutate(profile.id);
    }
  };

  const handleManageVIP = (profile) => {
    setSelectedProfile(profile);
    setVipForm({
      vip_mode: profile.vip_mode || 'off',
      vip_loader_enabled: profile.vip_loader_enabled || false,
      vip_loader_logo: profile.vip_loader_logo || '',
      vip_loader_text1: profile.vip_loader_text1 || 'Initializing Digital Identity',
      vip_loader_text2: profile.vip_loader_text2 || 'Access Granted',
      vip_robots_enabled: profile.vip_robots_enabled || false,
      vip_robot_message: profile.vip_robot_message || 'Welcome to the future',
      vip_floating_assistant: profile.vip_floating_assistant || false,
      vip_assistant_greeting: profile.vip_assistant_greeting || 'How can I assist you?',
      vip_animations_enabled: profile.vip_animations_enabled || false,
    });
    setIsManagingVIP(true);
  };

  const handleSaveVIP = () => {
    if (!selectedProfile) return;
    updateVIPMutation.mutate({
      profileId: selectedProfile.id,
      data: vipForm
    });
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setVipForm(prev => ({ ...prev, vip_loader_logo: file_url }));
      toast.success('Logo uploaded');
    } catch (error) {
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleExportCode = async () => {
    setIsExporting(true);
    toast.info('🔄 Generating complete website export...');
    
    try {
      const response = await base44.functions.invoke('exportWebsiteCode', {});
      
      // Response data is a string (base64 or raw zip data)
      let blob;
      
      if (typeof response.data === 'string') {
        // Convert string to bytes - the response is likely binary data as string
        const binaryString = response.data;
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        blob = new Blob([bytes], { type: 'application/zip' });
      } else if (response.data instanceof Uint8Array || response.data instanceof ArrayBuffer) {
        blob = new Blob([response.data], { type: 'application/zip' });
      } else if (response.data instanceof Blob) {
        blob = response.data;
      } else {
        throw new Error('Invalid response format from export function');
      }
      
      if (blob.size === 0) {
        throw new Error('Export generated empty file');
      }
      
      // Trigger download
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `sos4digital-complete-${new Date().toISOString().split('T')[0]}.zip`;
      document.body.appendChild(a);
      a.click();
      
      // Cleanup
      setTimeout(() => {
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }, 100);
      
      toast.success('✅ Website exported successfully! Check your downloads.');
    } catch (error) {
      console.error('Export failed:', error);
      toast.error('❌ Export failed: ' + error.message);
    } finally {
      setIsExporting(false);
    }
  };

  const filteredProfiles = allProfiles.filter(p => 
    !searchQuery || 
    p.username?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (userLoading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>;
  }

  // Simple protection
  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center">
        <Shield className="w-16 h-16 text-red-500 mb-4" />
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h1>
        <p className="text-gray-500 mb-6">You need administrator privileges to view this page.</p>
        <Link to={createPageUrl('Home')}>
          <Button>Return Home</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gray-900 text-white border-b border-gray-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-violet-400" />
            <span className="text-xl font-bold">Admin Dashboard</span>
          </div>
          <div className="flex items-center gap-4">
             <span className="text-sm text-gray-400">Logged in as {user.email}</span>
             <Link to={createPageUrl('QRCodes')}>
               <Button variant="secondary" size="sm">
                 <QrCode className="w-4 h-4 mr-2" />
                 QR Codes
               </Button>
             </Link>
             <Link to={createPageUrl('MyProfiles')}>
               <Button variant="secondary" size="sm">
                 <User className="w-4 h-4 mr-2" />
                 My Profiles
               </Button>
             </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Tabs */}
        <div className="flex items-center gap-4 mb-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('profiles')}
            className={`px-4 py-3 font-medium transition-colors border-b-2 ${
              activeTab === 'profiles'
                ? 'border-violet-600 text-violet-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <User className="w-4 h-4 inline mr-2" />
            Profiles
          </button>
          <button
            onClick={() => setActiveTab('export')}
            className={`px-4 py-3 font-medium transition-colors border-b-2 ${
              activeTab === 'export'
                ? 'border-violet-600 text-violet-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Code className="w-4 h-4 inline mr-2" />
            Export Code
          </button>
          <button
            onClick={() => setActiveTab('vip')}
            className={`px-4 py-3 font-medium transition-colors border-b-2 ${
              activeTab === 'vip'
                ? 'border-violet-600 text-violet-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Crown className="w-4 h-4 inline mr-2" />
            VIP Controls
          </button>
        </div>

        {activeTab === 'profiles' && (
          <>
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">All System Profiles</h1>
                <p className="text-gray-500 mt-1">Total Profiles: {allProfiles.length}</p>
              </div>
              <div className="relative w-full sm:w-72">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by username, name, email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-white"
                />
              </div>
            </div>

            {profilesLoading ? (
              <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-violet-600" /></div>
            ) : (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                <thead className="bg-gray-50 text-gray-600 border-b border-gray-200 font-medium">
                  <tr>
                    <th className="px-6 py-4">Profile</th>
                    <th className="px-6 py-4">Username</th>
                    <th className="px-6 py-4">Info</th>
                    <th className="px-6 py-4">Contact</th>
                    <th className="px-6 py-4">Created By</th>
                    <th className="px-6 py-4">Views</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredProfiles.map((profile) => (
                    <tr key={profile.id} className="hover:bg-gray-50/50">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-violet-100 flex items-center justify-center text-violet-600 font-bold text-xs">
                            {(profile.full_name || profile.username || '?')[0].toUpperCase()}
                          </div>
                          <span className="font-medium text-gray-900">{profile.full_name || '-'}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-gray-600">@{profile.username}</td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className="text-gray-900 font-medium">{profile.title || '-'}</span>
                          <span className="text-gray-500 text-xs">{profile.company}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col gap-1">
                          {profile.email && <span className="text-xs text-gray-600 flex items-center gap-1">📧 {profile.email}</span>}
                          {profile.phone && <span className="text-xs text-gray-600 flex items-center gap-1">📱 {profile.phone}</span>}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-gray-500 text-xs">
                        <div className="flex items-center gap-2 justify-between">
                          <span>{profile.created_by}</span>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-6 w-6"
                            onClick={() => handleManageUser(profile.created_by)}
                            title="Manage User Subscription"
                          >
                            <CreditCard className="w-3 h-3 text-violet-600" />
                          </Button>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-gray-500">{profile.views || 0}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <a 
                            href={`${window.location.origin}${createPageUrl('PublicProfile')}?u=${profile.username}`}
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="p-2 text-gray-400 hover:text-violet-600 transition-colors"
                            title="View Public Profile"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                          <button
                           onClick={() => handleManageVIP(profile)}
                           className="p-2 text-gray-400 hover:text-amber-600 transition-colors"
                           title="VIP Settings"
                          >
                           <Crown className="w-4 h-4" />
                          </button>
                          <Link
                           to={`${createPageUrl('EditProfile')}?id=${profile.id}`}
                           className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                           title="Edit Profile"
                          >
                           <Pencil className="w-4 h-4" />
                          </Link>
                          <button 
                           onClick={() => handleDelete(profile)}
                           className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                           title="Delete Profile"
                          >
                           <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {filteredProfiles.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                        No profiles found matching your search.
                      </td>
                    </tr>
                  )}
                </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}

        {activeTab === 'vip' && (
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center">
                  <Crown className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">VIP Experience Controls</h2>
                  <p className="text-sm text-gray-500">Manage luxury digital identity features</p>
                </div>
              </div>

              <div className="space-y-6">
                {/* Profile Selection */}
                <div className="p-6 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-xl border-2 border-amber-200">
                  <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-amber-600" />
                    Select a Profile to Manage
                  </h3>
                  <div className="grid grid-cols-1 gap-2 max-h-96 overflow-y-auto">
                    {allProfiles.map(profile => (
                      <button
                        key={profile.id}
                        onClick={() => handleManageVIP(profile)}
                        className="flex items-center gap-3 p-4 bg-white hover:bg-amber-50 rounded-lg border border-gray-200 hover:border-amber-300 transition-all text-left"
                      >
                        <div className="w-10 h-10 rounded-full bg-violet-100 flex items-center justify-center text-violet-600 font-bold flex-shrink-0">
                          {(profile.full_name || profile.username)[0].toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-gray-900 truncate">
                            {profile.full_name || profile.username}
                          </div>
                          <div className="text-sm text-gray-500">@{profile.username}</div>
                        </div>
                        {profile.vip_mode !== 'off' && (
                          <Crown className="w-5 h-5 text-amber-500 flex-shrink-0" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* VIP Stats */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 bg-gradient-to-br from-violet-50 to-purple-50 rounded-xl border border-violet-200">
                    <div className="text-3xl font-bold text-violet-600">
                      {allProfiles.filter(p => p.vip_mode !== 'off').length}
                    </div>
                    <div className="text-sm text-gray-600 mt-1">VIP Enabled</div>
                  </div>
                  <div className="p-4 bg-gradient-to-br from-amber-50 to-yellow-50 rounded-xl border border-amber-200">
                    <div className="text-3xl font-bold text-amber-600">
                      {allProfiles.filter(p => p.vip_loader_enabled).length}
                    </div>
                    <div className="text-sm text-gray-600 mt-1">Loaders Active</div>
                  </div>
                  <div className="p-4 bg-gradient-to-br from-cyan-50 to-blue-50 rounded-xl border border-cyan-200">
                    <div className="text-3xl font-bold text-cyan-600">
                      {allProfiles.filter(p => p.vip_floating_assistant).length}
                    </div>
                    <div className="text-sm text-gray-600 mt-1">Assistants Active</div>
                  </div>
                </div>

                {/* Feature Overview */}
                <div className="space-y-3">
                  <h3 className="font-semibold text-gray-900">Available VIP Features</h3>
                  <div className="grid gap-3">
                    <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                      <Sparkles className="w-5 h-5 text-violet-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-gray-900">Page Loader</h4>
                        <p className="text-sm text-gray-600">Cinematic full-screen animated entrance with custom logo and text</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                      <Bot className="w-5 h-5 text-cyan-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-gray-900">Robot Animations</h4>
                        <p className="text-sm text-gray-600">Animated mini robots displaying custom holographic messages</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                      <Bot className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-gray-900">Floating Assistant</h4>
                        <p className="text-sm text-gray-600">Interactive robot providing quick actions (save contact, WhatsApp, share)</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                      <Crown className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-gray-900">Luxury Animations</h4>
                        <p className="text-sm text-gray-600">Premium hover effects and micro-interactions on all UI elements</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'export' && (
          <div className="max-w-3xl mx-auto">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-violet-100 flex items-center justify-center">
                  <FileCode className="w-6 h-6 text-violet-600" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Export Website Code</h2>
                  <p className="text-sm text-gray-500">Download all frontend, backend, and assets</p>
                </div>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-lg">
                  <Code className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-blue-900">Frontend Code</h4>
                    <p className="text-sm text-blue-700">All pages, components, and layout files</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-green-50 rounded-lg">
                  <Database className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-green-900">Backend Code</h4>
                    <p className="text-sm text-green-700">All functions, entities, and API integrations</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-purple-50 rounded-lg">
                  <Download className="w-5 h-5 text-purple-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-purple-900">Assets & Media</h4>
                    <p className="text-sm text-purple-700">All uploaded images and files metadata</p>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleExportCode}
                disabled={isExporting}
                className="w-full bg-violet-600 hover:bg-violet-700 h-12 text-lg"
              >
                {isExporting ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Exporting...
                  </>
                ) : (
                  <>
                    <Download className="w-5 h-5 mr-2" />
                    Export All Website Code
                  </>
                )}
              </Button>

              <p className="text-xs text-gray-500 text-center mt-4">
                This will download a complete ZIP file with all pages, components, functions, entities, and assets
              </p>
              
              <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
                <h4 className="text-sm font-semibold text-gray-900 mb-2">What's included:</h4>
                <ul className="text-xs text-gray-600 space-y-1">
                  <li>✓ All React pages (Home, MyProfiles, EditProfile, etc.)</li>
                  <li>✓ All components (profile, landing, UI components)</li>
                  <li>✓ Backend functions (importProfile, exportWebsiteCode)</li>
                  <li>✓ Entity schemas (Profile, QRCode)</li>
                  <li>✓ Layout.js and package.json</li>
                  <li>✓ Assets metadata and image URLs</li>
                  <li>✓ README with setup instructions</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* VIP Management Dialog */}
      <Dialog open={isManagingVIP} onOpenChange={setIsManagingVIP}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-500" />
              VIP Experience Settings
            </DialogTitle>
          </DialogHeader>
          
          {selectedProfile && (
            <div className="space-y-6 py-4">
              <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-violet-50 to-purple-50 rounded-lg border border-violet-200">
                <div className="w-12 h-12 rounded-full bg-violet-100 flex items-center justify-center text-violet-600 font-bold text-lg">
                  {(selectedProfile.full_name || selectedProfile.username)[0].toUpperCase()}
                </div>
                <div>
                  <div className="font-semibold text-gray-900">{selectedProfile.full_name || selectedProfile.username}</div>
                  <div className="text-sm text-gray-500">@{selectedProfile.username}</div>
                </div>
              </div>

              {/* VIP Mode */}
              <div className="space-y-3">
                <Label className="text-base font-semibold">VIP Experience Mode</Label>
                <div className="grid grid-cols-3 gap-3">
                  {['off', 'luxury', 'minimal'].map((mode) => (
                    <button
                      key={mode}
                      onClick={() => setVipForm(prev => ({ ...prev, vip_mode: mode }))}
                      className={`p-4 rounded-xl border-2 transition-all ${
                        vipForm.vip_mode === mode
                          ? 'border-amber-500 bg-amber-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="font-semibold capitalize">{mode}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {mode === 'off' && 'Standard'}
                        {mode === 'luxury' && 'Full VIP'}
                        {mode === 'minimal' && 'Subtle'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Loader Settings */}
              <div className="space-y-4 p-4 bg-gradient-to-r from-violet-50 to-purple-50 rounded-xl border border-violet-200">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="font-semibold">Page Loader</Label>
                    <p className="text-xs text-gray-600">Animated entrance screen</p>
                  </div>
                  <Switch
                    checked={vipForm.vip_loader_enabled}
                    onCheckedChange={(checked) => setVipForm(prev => ({ ...prev, vip_loader_enabled: checked }))}
                  />
                </div>
                {vipForm.vip_loader_enabled && (
                  <div className="space-y-3 pl-4 border-l-2 border-violet-300">
                    <div>
                      <Label className="text-sm">Custom Logo</Label>
                      <div className="flex gap-2 mt-1">
                        {vipForm.vip_loader_logo && (
                          <img src={vipForm.vip_loader_logo} alt="Logo" className="w-12 h-12 object-contain rounded border" />
                        )}
                        <div className="flex-1">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleLogoUpload}
                            className="hidden"
                            id="vip-logo"
                          />
                          <label htmlFor="vip-logo">
                            <Button variant="outline" size="sm" disabled={uploading} asChild>
                              <span>{uploading ? 'Uploading...' : 'Upload Logo'}</span>
                            </Button>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm">Text Line 1</Label>
                      <Input
                        value={vipForm.vip_loader_text1}
                        onChange={(e) => setVipForm(prev => ({ ...prev, vip_loader_text1: e.target.value }))}
                        placeholder="Initializing Digital Identity"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-sm">Text Line 2</Label>
                      <Input
                        value={vipForm.vip_loader_text2}
                        onChange={(e) => setVipForm(prev => ({ ...prev, vip_loader_text2: e.target.value }))}
                        placeholder="Access Granted"
                        className="mt-1"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Robot Settings */}
              <div className="space-y-4 p-4 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl border border-cyan-200">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="font-semibold">Robot Animations</Label>
                    <p className="text-xs text-gray-600">Mini robots during loading</p>
                  </div>
                  <Switch
                    checked={vipForm.vip_robots_enabled}
                    onCheckedChange={(checked) => setVipForm(prev => ({ ...prev, vip_robots_enabled: checked }))}
                  />
                </div>
                {vipForm.vip_robots_enabled && (
                  <div className="pl-4 border-l-2 border-cyan-300">
                    <Label className="text-sm">Robot Message</Label>
                    <Input
                      value={vipForm.vip_robot_message}
                      onChange={(e) => setVipForm(prev => ({ ...prev, vip_robot_message: e.target.value }))}
                      placeholder="Welcome to the future"
                      className="mt-1"
                    />
                  </div>
                )}
              </div>

              {/* Assistant Settings */}
              <div className="space-y-4 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="font-semibold">Floating Assistant</Label>
                    <p className="text-xs text-gray-600">Interactive robot helper</p>
                  </div>
                  <Switch
                    checked={vipForm.vip_floating_assistant}
                    onCheckedChange={(checked) => setVipForm(prev => ({ ...prev, vip_floating_assistant: checked }))}
                  />
                </div>
                {vipForm.vip_floating_assistant && (
                  <div className="pl-4 border-l-2 border-purple-300">
                    <Label className="text-sm">Greeting Message</Label>
                    <Input
                      value={vipForm.vip_assistant_greeting}
                      onChange={(e) => setVipForm(prev => ({ ...prev, vip_assistant_greeting: e.target.value }))}
                      placeholder="How can I assist you?"
                      className="mt-1"
                    />
                  </div>
                )}
              </div>

              {/* Animations */}
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl border border-amber-200">
                <div>
                  <Label className="font-semibold">Luxury Animations</Label>
                  <p className="text-xs text-gray-600">Premium hover & micro-interactions</p>
                </div>
                <Switch
                  checked={vipForm.vip_animations_enabled}
                  onCheckedChange={(checked) => setVipForm(prev => ({ ...prev, vip_animations_enabled: checked }))}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsManagingVIP(false)}>Cancel</Button>
            <Button 
              onClick={handleSaveVIP}
              className="bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-600 hover:via-yellow-600 hover:to-amber-700"
              disabled={updateVIPMutation.isPending}
            >
              {updateVIPMutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Crown className="w-4 h-4 mr-2" />
              )}
              Save VIP Settings
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* User Management Dialog */}
      <Dialog open={isManagingUser} onOpenChange={setIsManagingUser}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Manage Subscription</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="text-sm text-gray-500 mb-2">
              Managing user: <span className="font-medium text-gray-900">{selectedUserEmail}</span>
            </div>
            
            <div className="grid gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Plan Tier</label>
                <select 
                  className="w-full p-2 border border-gray-200 rounded-md"
                  value={subscriptionForm.tier} 
                  onChange={(e) => setSubscriptionForm({...subscriptionForm, tier: e.target.value})}
                >
                  <option value="free">Free</option>
                  <option value="pro">Pro</option>
                  <option value="enterprise">Enterprise</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Duration</label>
                <select 
                  className="w-full p-2 border border-gray-200 rounded-md"
                  value={subscriptionForm.duration} 
                  onChange={(e) => setSubscriptionForm({...subscriptionForm, duration: e.target.value})}
                >
                  <option value="1">1 Month</option>
                  <option value="3">3 Months</option>
                  <option value="6">6 Months</option>
                  <option value="12">1 Year</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Profile Limit</label>
                <Input
                  type="number"
                  value={subscriptionForm.customLimit}
                  onChange={(e) => setSubscriptionForm({...subscriptionForm, customLimit: parseInt(e.target.value) || 1})}
                  min="1"
                />
                <p className="text-xs text-gray-500">
                  Set to 100+ for "unlimited"
                </p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsManagingUser(false)}>Cancel</Button>
            <Button 
              onClick={handleSaveSubscription}
              className="bg-violet-600 hover:bg-violet-700"
            >
              {updateUserMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <UserCog className="w-4 h-4 mr-2" />}
              Update Subscription
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}