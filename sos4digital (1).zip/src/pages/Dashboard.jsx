import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { 
  Link as LinkIcon, 
  User, 
  Copy, 
  ExternalLink, 
  Save,
  Loader2,
  LogOut,
  QrCode,
  Share2,
  CheckCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ImageUploader from '@/components/profile/ImageUploader';
import LinkEditor from '@/components/profile/LinkEditor';
import QRCodeGenerator from '@/components/profile/QRCodeGenerator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function Dashboard() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('profile');
  const [formData, setFormData] = useState({
    username: '',
    full_name: '',
    title: '',
    company: '',
    bio: '',
    email: '',
    phone: '',
    website: '',
    location: '',
    avatar_url: '',
    cover_url: '',
    links: []
  });
  const [isSaving, setIsSaving] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  // Fetch current user
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ['currentUser'],
    queryFn: async () => {
      console.log('Fetching current user...');
      const userData = await base44.auth.me();
      console.log('User data:', userData);
      return userData;
    }
  });

  // Fetch user's profile
  const { data: profiles, isLoading: profileLoading, error: profileError } = useQuery({
    queryKey: ['myProfile', user?.email],
    queryFn: async () => {
      console.log('Fetching profile for:', user?.email);
      const profileData = await base44.entities.Profile.filter({ created_by: user?.email });
      console.log('Profile data:', profileData);
      return profileData;
    },
    enabled: !!user?.email
  });

  const profile = profiles?.[0];

  // Initialize form data when profile loads
  useEffect(() => {
    if (profile) {
      console.log('Setting form data from profile:', profile);
      setFormData({
        username: profile.username || '',
        full_name: profile.full_name || user?.full_name || '',
        title: profile.title || '',
        company: profile.company || '',
        bio: profile.bio || '',
        email: profile.email || user?.email || '',
        phone: profile.phone || '',
        website: profile.website || '',
        location: profile.location || '',
        avatar_url: profile.avatar_url || '',
        cover_url: profile.cover_url || '',
        links: profile.links || []
      });
      setHasChanges(false);
    } else if (user && !profile) {
      console.log('No profile found, setting defaults from user');
      setFormData(prev => ({
        ...prev,
        full_name: user.full_name || '',
        email: user.email || ''
      }));
    }
  }, [profile, user]);

  // Track changes
  const updateFormData = (updates) => {
    setFormData(prev => ({ ...prev, ...updates }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    console.log('Save clicked, form data:', formData);
    
    if (!formData.username) {
      toast.error('Please enter a username');
      return;
    }
    
    // Check if username is unique (basic validation)
    const usernameRegex = /^[a-zA-Z0-9_-]+$/;
    if (!usernameRegex.test(formData.username)) {
      toast.error('Username can only contain letters, numbers, underscores and hyphens');
      return;
    }

    setIsSaving(true);
    
    try {
      let result;
      if (profile) {
        console.log('Updating existing profile:', profile.id);
        result = await base44.entities.Profile.update(profile.id, formData);
        console.log('Update result:', result);
      } else {
        console.log('Creating new profile');
        result = await base44.entities.Profile.create(formData);
        console.log('Create result:', result);
      }
      
      // Invalidate and refetch
      await queryClient.invalidateQueries({ queryKey: ['myProfile'] });
      setHasChanges(false);
      toast.success('Profile saved successfully!');
    } catch (error) {
      console.error('Save failed:', error);
      toast.error('Failed to save profile: ' + (error.message || 'Unknown error'));
    } finally {
      setIsSaving(false);
    }
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  const profileUrl = formData.username 
    ? `${window.location.origin}${createPageUrl('PublicProfile')}?u=${formData.username}`
    : '';

  const copyProfileUrl = () => {
    navigator.clipboard.writeText(profileUrl);
    toast.success('Link copied to clipboard!');
  };

  const shareProfile = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${formData.full_name || formData.username}'s Profile`,
          text: 'Check out my digital business card!',
          url: profileUrl,
        });
      } catch (err) {
        copyProfileUrl();
      }
    } else {
      copyProfileUrl();
    }
  };

  // Log errors
  useEffect(() => {
    if (userError) console.error('User error:', userError);
    if (profileError) console.error('Profile error:', profileError);
  }, [userError, profileError]);

  if (userLoading || profileLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4">
        <Loader2 className="w-8 h-8 animate-spin text-violet-600" />
        <p className="text-gray-500">Loading your profile...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to={createPageUrl('Home')} className="flex items-center gap-2">
                        <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/f80600f2a_WhatsApp_Image_2025-11-25_at_114437_AM-removebg-preview.png" alt="SOS4DIGITAL" className="h-8 w-8" />
                        <span className="text-xl font-bold text-gray-900">SOS4DIGITAL</span>
                      </Link>
          <div className="flex items-center gap-3">
            <Link to={createPageUrl('Home')} className="text-gray-600 hover:text-gray-900 hidden sm:block">
              Home
            </Link>
            <Button 
              variant="outline" 
              onClick={handleLogout}
              className="rounded-full"
            >
              <LogOut className="w-4 h-4 sm:mr-2" />
              <span className="hidden sm:inline">Sign Out</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">My Profile</h1>
            {hasChanges && (
              <p className="text-sm text-amber-600 mt-1">You have unsaved changes</p>
            )}
          </div>
          <Button 
            onClick={handleSave}
            disabled={isSaving}
            className="bg-violet-600 hover:bg-violet-700 rounded-full w-full sm:w-auto"
          >
            {isSaving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : hasChanges ? (
              <Save className="w-4 h-4 mr-2" />
            ) : (
              <CheckCircle className="w-4 h-4 mr-2" />
            )}
            {isSaving ? 'Saving...' : hasChanges ? 'Save Changes' : 'Saved'}
          </Button>
        </div>

        {/* Profile URL & Share */}
        {profile && formData.username && (
          <div className="bg-white rounded-xl p-4 mb-6 border border-gray-200 shadow-sm">
            <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
              <LinkIcon className="w-4 h-4" />
              Your Profile Link (Live & Shareable)
            </div>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <Input 
                value={profileUrl}
                readOnly
                className="flex-1 bg-gray-50 text-sm"
              />
              <div className="flex gap-2">
                <Button variant="outline" onClick={copyProfileUrl} className="flex-1 sm:flex-none">
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
                <Button variant="outline" onClick={shareProfile} className="flex-1 sm:flex-none">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
                <Dialog open={showQR} onOpenChange={setShowQR}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <QrCode className="w-4 h-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Your QR Code</DialogTitle>
                    </DialogHeader>
                    <div className="flex flex-col items-center py-6">
                      <QRCodeGenerator url={profileUrl} size={250} />
                      <p className="text-sm text-gray-500 mt-4 text-center">
                        Scan this code to open your profile
                      </p>
                    </div>
                  </DialogContent>
                </Dialog>
                <Button variant="outline" asChild>
                  <a href={profileUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </Button>
              </div>
            </div>
          </div>
        )}

        {!profile && formData.username && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
            <p className="text-amber-800 text-sm">
              <strong>Note:</strong> Click "Save Changes" to create your profile and get your shareable link.
            </p>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full mb-6 grid grid-cols-2">
            <TabsTrigger value="profile">
              <User className="w-4 h-4 mr-2" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="links">
              <LinkIcon className="w-4 h-4 mr-2" />
              Links
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            <div className="bg-white rounded-xl p-6 border border-gray-200 space-y-6">
              {/* Cover Image */}
              <div>
                <Label className="text-sm font-medium mb-2 block">Cover Image</Label>
                <ImageUploader
                  type="cover"
                  currentImage={formData.cover_url}
                  onImageChange={(url) => {
                    console.log('Cover image changed:', url);
                    updateFormData({ cover_url: url });
                  }}
                />
              </div>

              {/* Avatar */}
              <div className="flex items-end gap-6 -mt-16 ml-6 relative z-10">
                <ImageUploader
                  type="avatar"
                  currentImage={formData.avatar_url}
                  onImageChange={(url) => {
                    console.log('Avatar changed:', url);
                    updateFormData({ avatar_url: url });
                  }}
                />
                <div className="pb-2">
                  <p className="text-sm text-gray-500">Click the camera icon to upload your photo</p>
                </div>
              </div>

              {/* Form Fields */}
              <div className="grid md:grid-cols-2 gap-4 pt-4">
                <div className="space-y-2">
                  <Label>Username *</Label>
                  <Input
                    placeholder="yourname"
                    value={formData.username}
                    onChange={(e) => updateFormData({ username: e.target.value.toLowerCase().replace(/\s/g, '').replace(/[^a-z0-9_-]/g, '') })}
                  />
                  <p className="text-xs text-gray-500">This will be your profile URL</p>
                </div>

                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <Input
                    placeholder="John Doe"
                    value={formData.full_name}
                    onChange={(e) => updateFormData({ full_name: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Title / Position</Label>
                  <Input
                    placeholder="Software Engineer"
                    value={formData.title}
                    onChange={(e) => updateFormData({ title: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Company</Label>
                  <Input
                    placeholder="Company Name"
                    value={formData.company}
                    onChange={(e) => updateFormData({ company: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Bio</Label>
                <Textarea
                  placeholder="Tell people about yourself..."
                  value={formData.bio}
                  onChange={(e) => updateFormData({ bio: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={(e) => updateFormData({ email: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Phone</Label>
                  <Input
                    placeholder="+1 234 567 890"
                    value={formData.phone}
                    onChange={(e) => updateFormData({ phone: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Website</Label>
                  <Input
                    placeholder="https://yourwebsite.com"
                    value={formData.website}
                    onChange={(e) => updateFormData({ website: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Location</Label>
                  <Input
                    placeholder="City, Country"
                    value={formData.location}
                    onChange={(e) => updateFormData({ location: e.target.value })}
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="links">
            <div className="bg-white rounded-xl p-6 border border-gray-200">
              <LinkEditor
                links={formData.links}
                onLinksChange={(links) => {
                  console.log('Links changed:', links);
                  updateFormData({ links });
                }}
              />
              
              {formData.links.length > 0 && hasChanges && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <Button 
                    onClick={handleSave}
                    disabled={isSaving}
                    className="w-full bg-violet-600 hover:bg-violet-700"
                  >
                    {isSaving ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4 mr-2" />
                    )}
                    Save All Changes
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}