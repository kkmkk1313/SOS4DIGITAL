import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { 
  Link as LinkIcon, 
  User, 
  Copy, 
  ExternalLink, 
  Save,
  Loader2,
  ArrowLeft,
  QrCode,
  Share2,
  CheckCircle,
  BadgeCheck,
  Palette,
  Phone,
  Layout,
  Sparkles,
  Crown,
  Bot,
  Upload,
  Type,
  Music
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ImageUploader from '@/components/profile/ImageUploader';
import LinkEditor from '@/components/profile/LinkEditor';
import ProfileDesignEditor from '@/components/profile/ProfileDesignEditor';
import QRCodeGenerator from '@/components/profile/QRCodeGenerator';
import QRCodeManager from '@/components/profile/QRCodeManager';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function EditProfile() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const profileId = urlParams.get('id');

  const [activeTab, setActiveTab] = useState('personal');
  const [formData, setFormData] = useState({
    username: '',
    full_name: '',
    title: '',
    company: '',
    bio: '',
    email: '',
    phone: '',
    website: '',
    location: '',
    avatar_url: '',
    cover_url: '',
    links: [],
    theme_color: '#7C3AED',
    background_color: '',
    header_color: '',
    header_size: 'standard',
    card_background_color: '',
    is_card_transparent: false,
    backdrop_blur: true,
    background_mode: 'light',
    links_style: 'default',
    font_family: 'inter',
    show_save_contact: true
  });
  const [isSaving, setIsSaving] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [showVerifiedDialog, setShowVerifiedDialog] = useState(false);
  const [verifiedPassword, setVerifiedPassword] = useState('');
  const [verifiedError, setVerifiedError] = useState('');
  const [showPremiumDialog, setShowPremiumDialog] = useState(false);
  const [premiumPassword, setPremiumPassword] = useState('');
  const [premiumError, setPremiumError] = useState('');
  const [showLuxuryNameDialog, setShowLuxuryNameDialog] = useState(false);
  const [luxuryNamePassword, setLuxuryNamePassword] = useState('');
  const [luxuryNameError, setLuxuryNameError] = useState('');
  const [uploading, setUploading] = useState(false);

  // Fetch current user
  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  // Fetch profile by ID
  const { data: profile, isLoading } = useQuery({
    queryKey: ['profile', profileId],
    queryFn: async () => {
      const profiles = await base44.entities.Profile.filter({ id: profileId });
      return profiles[0];
    },
    enabled: !!profileId
  });

  const isAdmin = currentUser?.role === 'admin';

  useEffect(() => {
    if (profile) {
      setFormData({
        username: profile.username || '',
        full_name: profile.full_name || '',
        title: profile.title || '',
        company: profile.company || '',
        bio: profile.bio || '',
        email: profile.email || '',
        phone: profile.phone || '',
        website: profile.website || '',
        location: profile.location || '',
        avatar_url: profile.avatar_url || '',
        cover_url: profile.cover_url || '',
        links: profile.links || [],
        theme_color: profile.theme_color || '#7C3AED',
        background_color: profile.background_color || '',
        header_color: profile.header_color || '',
        header_size: profile.header_size || 'standard',
        card_background_color: profile.card_background_color || '',
        is_card_transparent: profile.is_card_transparent || false,
        backdrop_blur: profile.backdrop_blur !== false,
        background_mode: profile.background_mode || 'light',
        links_style: profile.links_style || 'default',
        font_family: profile.font_family || 'inter',
        show_save_contact: profile.show_save_contact !== false,
        vip_mode: profile.vip_mode || 'off',
        vip_loader_enabled: profile.vip_loader_enabled || false,
        vip_loader_logo: profile.vip_loader_logo || '',
        vip_loader_text1: profile.vip_loader_text1 || 'Initializing Digital Identity',
        vip_loader_text2: profile.vip_loader_text2 || 'Access Granted',
        vip_robots_enabled: profile.vip_robots_enabled || false,
        vip_robot_message: profile.vip_robot_message || 'Welcome to the future',
        vip_floating_assistant: profile.vip_floating_assistant || false,
        vip_assistant_greeting: profile.vip_assistant_greeting || 'How can I assist you?',
        vip_animations_enabled: profile.vip_animations_enabled || false,
        vip_name_color: profile.vip_name_color || 'gold',
        vip_name_custom_colors: profile.vip_name_custom_colors || ['#FFD700', '#FDB931', '#FFED4E'],
        vip_shiver_intensity: profile.vip_shiver_intensity || 'medium',
        vip_background_music: profile.vip_background_music || '',
        vip_music_volume: profile.vip_music_volume || 30,
        luxury_name_style: profile.luxury_name_style || 'filled',
      });
      setHasChanges(false);
    }
  }, [profile]);

  const updateFormData = (updates) => {
    setFormData(prev => {
      const updated = { ...prev, ...updates };
      console.log('Updated form data:', updated);
      return updated;
    });
    setHasChanges(true);
  };

  const handleVerifiedToggle = (checked) => {
    // Anyone can toggle the normal verified badge
    updateFormData({ is_verified: checked });
  };

  const handleVerifiedPasswordSubmit = () => {
    const ADMIN_PASSWORD = 'sos4digital2026premium';
    if (verifiedPassword === ADMIN_PASSWORD) {
      updateFormData({ is_verified: true });
      setShowVerifiedDialog(false);
      setVerifiedPassword('');
      setVerifiedError('');
      toast.success('✨ Verified Badge Unlocked!');
    } else {
      setVerifiedError('Incorrect password');
    }
  };

  const handlePremiumToggle = (checked) => {
    if (checked) {
      // Trying to enable premium verified badge
      if (isAdmin) {
        // Admin can enable directly
        updateFormData({ is_premium_verified: true });
      } else {
        // Non-admin needs password
        setShowPremiumDialog(true);
      }
    } else {
      // Disabling is always allowed
      updateFormData({ is_premium_verified: false });
    }
  };

  const handlePremiumPasswordSubmit = () => {
    const SUPER_ADMIN_PASSWORD = 'Adminkkmkk137';
    if (premiumPassword === SUPER_ADMIN_PASSWORD) {
      updateFormData({ is_premium_verified: true });
      setShowPremiumDialog(false);
      setPremiumPassword('');
      setPremiumError('');
      toast.success('💎 Premium Diamond Badge Unlocked!');
    } else {
      setPremiumError('Incorrect password');
    }
  };

  const handleLuxuryNameToggle = (checked) => {
    if (checked) {
      if (isAdmin) {
        updateFormData({ luxury_name_effect: true });
      } else {
        setShowLuxuryNameDialog(true);
      }
    } else {
      updateFormData({ luxury_name_effect: false });
    }
  };

  const handleLuxuryNamePasswordSubmit = () => {
    const LUXURY_PASSWORD = 'Adminkkmkk137';
    if (luxuryNamePassword === LUXURY_PASSWORD) {
      updateFormData({ luxury_name_effect: true });
      setShowLuxuryNameDialog(false);
      setLuxuryNamePassword('');
      setLuxuryNameError('');
      toast.success('✨ Luxury Name Effect Unlocked!');
    } else {
      setLuxuryNameError('Incorrect password');
    }
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      updateFormData({ vip_loader_logo: file_url });
      toast.success('Logo uploaded');
    } catch (error) {
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleMusicUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      updateFormData({ vip_background_music: file_url });
      toast.success('Music uploaded');
    } catch (error) {
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    if (!formData.username) {
      toast.error('Please enter a username');
      return;
    }

    const usernameRegex = /^[a-zA-Z0-9_-]+$/;
    if (!usernameRegex.test(formData.username)) {
      toast.error('Username can only contain letters, numbers, underscores and hyphens');
      return;
    }

    // Check for uniqueness if username changed
    if (profile && profile.username !== formData.username) {
      try {
        const existingProfiles = await base44.entities.Profile.filter({ username: formData.username });
        // Check if any found profile is NOT the current one
        const isTaken = existingProfiles && existingProfiles.some(p => p.id !== profileId);
        
        if (isTaken) {
          toast.error('This username is already taken. Please choose another one.');
          return;
        }
      } catch (error) {
        console.error("Error checking username:", error);
        toast.error('Could not verify username availability');
        return;
      }
    }

    setIsSaving(true);
    try {
      // Clean up the data before saving - ensure links have all their properties
      const dataToSave = {
        ...formData,
        links: formData.links.map(link => {
          const cleanLink = { ...link };
          // Remove null/undefined properties except for enabled flag
          Object.keys(cleanLink).forEach(key => {
            if (cleanLink[key] === null || cleanLink[key] === undefined) {
              if (key !== 'enabled') {
                delete cleanLink[key];
              }
            }
          });
          return cleanLink;
        })
      };
      
      console.log('Saving profile with data:', dataToSave);
      const result = await base44.entities.Profile.update(profileId, dataToSave);
      console.log('Profile saved:', result);
      
      // Invalidate all profile queries to refresh data
      await queryClient.invalidateQueries({ queryKey: ['profile'] });
      await queryClient.invalidateQueries({ queryKey: ['publicProfile'] });
      await queryClient.invalidateQueries({ queryKey: ['allProfiles'] });
      
      // Force refetch
      setTimeout(() => {
        queryClient.refetchQueries({ queryKey: ['publicProfile', formData.username] });
      }, 100);
      
      setHasChanges(false);
      toast.success('Profile saved! Refresh the profile page to see changes.');
    } catch (error) {
      toast.error('Failed to save');
      console.error('Save error:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const profileUrl = formData.username 
    ? `${window.location.origin}${createPageUrl('PublicProfile')}?u=${formData.username}`
    : '';

  const copyProfileUrl = () => {
    navigator.clipboard.writeText(profileUrl);
    toast.success('Link copied!');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-600" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <p className="text-gray-500 mb-4">Profile not found</p>
        <Link to={createPageUrl('MyProfiles')}>
          <Button>Go to My Profiles</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('MyProfiles')} className="flex items-center gap-2">
              <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/f80600f2a_WhatsApp_Image_2025-11-25_at_114437_AM-removebg-preview.png" alt="SOS4DIGITAL" className="h-8 w-8" />
              <span className="text-xl font-bold text-gray-900">SOS4DIGITAL</span>
            </Link>
            <span className="text-lg font-semibold ml-4">Edit Profile</span>
          </div>
          <Button 
            onClick={handleSave}
            disabled={isSaving || !hasChanges}
            className={`rounded-full ${hasChanges ? 'bg-violet-600 hover:bg-violet-700 animate-pulse' : 'bg-gray-400'}`}
          >
            {isSaving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : hasChanges ? (
              <Save className="w-4 h-4 mr-2" />
            ) : (
              <CheckCircle className="w-4 h-4 mr-2" />
            )}
            {isSaving ? 'Saving...' : hasChanges ? 'Save Changes' : 'All Saved'}
          </Button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Profile URL */}
        {formData.username && (
          <div className="bg-white rounded-xl p-4 mb-6 border border-gray-200">
            <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
              <LinkIcon className="w-4 h-4" />
              Profile Link
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Input value={profileUrl} readOnly className="flex-1 bg-gray-50 text-sm" />
              <div className="flex gap-2">
                <Button variant="outline" onClick={copyProfileUrl}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
                <Dialog open={showQR} onOpenChange={setShowQR}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <QrCode className="w-4 h-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>QR Code</DialogTitle>
                    </DialogHeader>
                    <div className="flex flex-col items-center py-4">
                      <QRCodeGenerator url={profileUrl} size={250} />
                    </div>
                  </DialogContent>
                </Dialog>
                <Button variant="outline" asChild>
                  <a href={profileUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </Button>
              </div>
            </div>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full mb-6 grid grid-cols-4">
            <TabsTrigger value="personal">
              <User className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Personal</span>
            </TabsTrigger>
            <TabsTrigger value="contact">
              <Phone className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Contact</span>
            </TabsTrigger>
            <TabsTrigger value="qrcodes">
              <QrCode className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">QR Codes</span>
            </TabsTrigger>
            <TabsTrigger value="design">
              <Palette className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Design</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="personal">
            <div className="bg-white rounded-xl p-6 border border-gray-200 space-y-6">
              <div className="flex flex-col items-center justify-center mb-6">
                 <div className="w-32 h-32 relative">
                   <ImageUploader
                    type="avatar"
                    currentImage={formData.avatar_url}
                    onImageChange={(url) => updateFormData({ avatar_url: url })}
                  />
                 </div>
                 <p className="text-sm text-gray-500 mt-2">Profile Picture</p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <Input
                    placeholder="John Doe"
                    value={formData.full_name}
                    onChange={(e) => updateFormData({ full_name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Title / Position</Label>
                  <Input
                    placeholder="Software Engineer"
                    value={formData.title}
                    onChange={(e) => updateFormData({ title: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Company</Label>
                  <Input
                    placeholder="Company Name"
                    value={formData.company}
                    onChange={(e) => updateFormData({ company: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Bio</Label>
                  <Textarea
                    placeholder="Tell people about yourself..."
                    value={formData.bio}
                    onChange={(e) => updateFormData({ bio: e.target.value })}
                    rows={3}
                  />
                </div>

                {/* Golden Verified Badge */}
                <div className="relative overflow-hidden p-5 bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 rounded-xl border border-amber-200/50 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg flex items-center justify-center shadow">
                        <BadgeCheck className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">Verified Badge</p>
                        <p className="text-xs text-gray-600">
                          Toggle freely - Available for everyone
                        </p>
                      </div>
                    </div>
                    <Switch
                      checked={formData.is_verified}
                      onCheckedChange={handleVerifiedToggle}
                    />
                  </div>
                </div>

                {/* Diamond Premium Badge */}
                <div className="relative overflow-hidden p-5 bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-50 rounded-xl border border-cyan-200/50 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 flex items-center justify-center">
                        <img 
                          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/c36c846e1_image-removebg-preview.png" 
                          alt="Diamond Badge" 
                          className="w-12 h-12 object-contain"
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-semibold text-gray-900">Diamond Badge</p>
                          {isAdmin && (
                            <span className="px-2 py-0.5 bg-violet-100 text-violet-700 text-xs font-semibold rounded-full">
                              ADMIN
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-gray-600">
                          {isAdmin ? 'Super admin exclusive' : 'Ultra premium access'}
                        </p>
                      </div>
                    </div>
                    <Switch
                      checked={formData.is_premium_verified}
                      onCheckedChange={handlePremiumToggle}
                    />
                  </div>
                </div>



                {/* VIP Experience Controls - Admin or Password */}
                <div className="relative overflow-hidden p-6 bg-gradient-to-br from-violet-50 via-purple-50 to-indigo-50 rounded-xl border-2 border-violet-300/50 shadow-lg space-y-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 rounded-xl flex items-center justify-center shadow-lg">
                      <Crown className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <p className="text-lg font-bold text-gray-900">VIP Experience Controls</p>
                      <p className="text-xs text-gray-600">Exclusive luxury digital identity features</p>
                    </div>
                  </div>
                  
                  {!isAdmin ? (
                    <div className="space-y-3">
                      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                        <p className="text-sm text-gray-700 mb-3">
                          🔐 Enter the VIP password to access exclusive features
                        </p>
                        <div className="space-y-2">
                          <Input
                            type="password"
                            placeholder="Enter VIP password..."
                            value={luxuryNamePassword}
                            onChange={(e) => {
                              setLuxuryNamePassword(e.target.value);
                              setLuxuryNameError('');
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && luxuryNamePassword === 'Adminkkmkk137') {
                                setLuxuryNameError('');
                                toast.success('✨ VIP Access Granted!');
                              } else if (e.key === 'Enter') {
                                setLuxuryNameError('Incorrect password');
                              }
                            }}
                          />
                          {luxuryNameError && (
                            <p className="text-sm text-red-600">{luxuryNameError}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ) : null}
                  
                  {(isAdmin || luxuryNamePassword === 'Adminkkmkk137') && (
                    <>
                      {!isAdmin && (
                        <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                          <p className="text-sm text-green-700 font-medium">✅ VIP Access Granted</p>
                        </div>
                      )}

                    {/* VIP Mode */}
                    <div className="space-y-2">
                      <Label className="font-semibold">VIP Mode</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {['off', 'luxury', 'minimal'].map((mode) => (
                          <button
                            key={mode}
                            onClick={() => updateFormData({ vip_mode: mode })}
                            className={`p-3 rounded-lg border-2 transition-all ${
                              formData.vip_mode === mode
                                ? 'border-amber-500 bg-amber-50'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <div className="font-semibold capitalize text-sm">{mode}</div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Page Loader */}
                    <div className="space-y-3 p-4 bg-white/50 rounded-lg border border-violet-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-violet-600" />
                          <Label className="font-semibold">Page Loader</Label>
                        </div>
                        <Switch
                          checked={formData.vip_loader_enabled}
                          onCheckedChange={(checked) => updateFormData({ vip_loader_enabled: checked })}
                        />
                      </div>
                      {formData.vip_loader_enabled && (
                        <div className="space-y-2 pl-6 border-l-2 border-violet-300">
                          <div>
                            <Label className="text-xs">Logo</Label>
                            <div className="flex gap-2 mt-1">
                              {formData.vip_loader_logo && (
                                <img src={formData.vip_loader_logo} alt="Logo" className="w-10 h-10 object-contain rounded border" />
                              )}
                              <input
                                type="file"
                                accept="image/*"
                                onChange={handleLogoUpload}
                                className="hidden"
                                id="vip-logo-upload"
                              />
                              <label htmlFor="vip-logo-upload">
                                <Button variant="outline" size="sm" disabled={uploading} asChild>
                                  <span>
                                    <Upload className="w-3 h-3 mr-1" />
                                    {uploading ? 'Uploading...' : 'Upload'}
                                  </span>
                                </Button>
                              </label>
                            </div>
                          </div>
                          <div>
                            <Label className="text-xs">Text Line 1</Label>
                            <Input
                              size="sm"
                              value={formData.vip_loader_text1}
                              onChange={(e) => updateFormData({ vip_loader_text1: e.target.value })}
                              placeholder="Initializing Digital Identity"
                            />
                          </div>
                          <div>
                            <Label className="text-xs">Text Line 2</Label>
                            <Input
                              size="sm"
                              value={formData.vip_loader_text2}
                              onChange={(e) => updateFormData({ vip_loader_text2: e.target.value })}
                              placeholder="Access Granted"
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Robot Animations */}
                    <div className="space-y-3 p-4 bg-white/50 rounded-lg border border-cyan-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Bot className="w-4 h-4 text-cyan-600" />
                          <Label className="font-semibold">Robot Animations</Label>
                        </div>
                        <Switch
                          checked={formData.vip_robots_enabled}
                          onCheckedChange={(checked) => updateFormData({ vip_robots_enabled: checked })}
                        />
                      </div>
                      {formData.vip_robots_enabled && (
                        <div className="pl-6 border-l-2 border-cyan-300">
                          <Label className="text-xs">Robot Message</Label>
                          <Input
                            size="sm"
                            value={formData.vip_robot_message}
                            onChange={(e) => updateFormData({ vip_robot_message: e.target.value })}
                            placeholder="Welcome to the future"
                          />
                        </div>
                      )}
                    </div>

                    {/* Floating Assistant */}
                    <div className="space-y-3 p-4 bg-white/50 rounded-lg border border-purple-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Bot className="w-4 h-4 text-purple-600" />
                          <Label className="font-semibold">Floating Assistant</Label>
                        </div>
                        <Switch
                          checked={formData.vip_floating_assistant}
                          onCheckedChange={(checked) => updateFormData({ vip_floating_assistant: checked })}
                        />
                      </div>
                      {formData.vip_floating_assistant && (
                        <div className="pl-6 border-l-2 border-purple-300">
                          <Label className="text-xs">Greeting</Label>
                          <Input
                            size="sm"
                            value={formData.vip_assistant_greeting}
                            onChange={(e) => updateFormData({ vip_assistant_greeting: e.target.value })}
                            placeholder="How can I assist you?"
                          />
                        </div>
                      )}
                    </div>

                    {/* Luxury Animations */}
                    <div className="flex items-center justify-between p-4 bg-white/50 rounded-lg border border-amber-200">
                      <div className="flex items-center gap-2">
                        <Crown className="w-4 h-4 text-amber-600" />
                        <Label className="font-semibold">Luxury Animations</Label>
                      </div>
                      <Switch
                        checked={formData.vip_animations_enabled}
                        onCheckedChange={(checked) => updateFormData({ vip_animations_enabled: checked })}
                      />
                    </div>

                    {/* Name Color & Shiver */}
                    <div className="space-y-3 p-4 bg-white/50 rounded-lg border border-indigo-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Type className="w-4 h-4 text-indigo-600" />
                        <Label className="font-semibold">Name Effects</Label>
                      </div>
                      <div className="pl-6 border-l-2 border-indigo-300 space-y-3">
                        <div>
                          <Label className="text-xs">Effect Style</Label>
                          <Select 
                            value={formData.luxury_name_style} 
                            onValueChange={(value) => updateFormData({ luxury_name_style: value })}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="none">❌ No Effect</SelectItem>
                              <SelectItem value="filled">✨ Filled Gradient</SelectItem>
                              <SelectItem value="outline">🔲 Outline Only</SelectItem>
                              <SelectItem value="box">📦 Box Background</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label className="text-xs">Name Color</Label>
                          <Select 
                            value={formData.vip_name_color} 
                            onValueChange={(value) => updateFormData({ vip_name_color: value })}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="gold">🏆 Gold Shimmer</SelectItem>
                              <SelectItem value="diamond">💎 Diamond Ice</SelectItem>
                              <SelectItem value="rainbow">🌈 Rainbow Spectrum</SelectItem>
                              <SelectItem value="fire">🔥 Fire Blaze</SelectItem>
                              <SelectItem value="ocean">🌊 Ocean Wave</SelectItem>
                              <SelectItem value="custom">🎨 Custom Gradient</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {formData.vip_name_color === 'custom' && (
                          <div>
                            <Label className="text-xs">Custom Colors (up to 5)</Label>
                            <div className="space-y-2 mt-1">
                              {[0, 1, 2, 3, 4].map((idx) => (
                                <div key={idx} className="flex gap-2">
                                  <Input
                                    type="color"
                                    value={(formData.vip_name_custom_colors || [])[idx] || '#FFD700'}
                                    onChange={(e) => {
                                      const colors = [...(formData.vip_name_custom_colors || ['#FFD700', '#FDB931', '#FFED4E'])];
                                      colors[idx] = e.target.value;
                                      updateFormData({ vip_name_custom_colors: colors });
                                    }}
                                    className="w-16 h-8"
                                  />
                                  <Input
                                    value={(formData.vip_name_custom_colors || [])[idx] || ''}
                                    onChange={(e) => {
                                      const colors = [...(formData.vip_name_custom_colors || ['#FFD700', '#FDB931', '#FFED4E'])];
                                      colors[idx] = e.target.value;
                                      updateFormData({ vip_name_custom_colors: colors });
                                    }}
                                    placeholder={`Color ${idx + 1}`}
                                    className="flex-1 h-8 text-xs"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        <div>
                          <Label className="text-xs">Shiver Intensity</Label>
                          <Select 
                            value={formData.vip_shiver_intensity} 
                            onValueChange={(value) => updateFormData({ vip_shiver_intensity: value })}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="none">None</SelectItem>
                              <SelectItem value="subtle">Subtle</SelectItem>
                              <SelectItem value="medium">Medium</SelectItem>
                              <SelectItem value="intense">Intense</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {/* Background Music */}
                    <div className="space-y-3 p-4 bg-white/50 rounded-lg border border-pink-200">
                      <div className="flex items-center gap-2">
                        <Music className="w-4 h-4 text-pink-600" />
                        <Label className="font-semibold">Background Music</Label>
                      </div>
                      <div className="pl-6 border-l-2 border-pink-300 space-y-3">
                        <div>
                          <Label className="text-xs">Music URL</Label>
                          <Input
                            size="sm"
                            value={formData.vip_background_music}
                            onChange={(e) => updateFormData({ vip_background_music: e.target.value })}
                            placeholder="https://example.com/music.mp3"
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Upload Music File</Label>
                          <input
                            type="file"
                            accept="audio/*"
                            onChange={handleMusicUpload}
                            className="hidden"
                            id="vip-music-upload"
                          />
                          <label htmlFor="vip-music-upload">
                            <Button variant="outline" size="sm" disabled={uploading} asChild className="mt-1 w-full">
                              <span>
                                <Upload className="w-3 h-3 mr-1" />
                                {uploading ? 'Uploading...' : 'Upload Audio'}
                              </span>
                            </Button>
                          </label>
                        </div>
                        <div>
                          <Label className="text-xs">Volume: {formData.vip_music_volume}%</Label>
                          <input
                            type="range"
                            min="0"
                            max="100"
                            value={formData.vip_music_volume}
                            onChange={(e) => updateFormData({ vip_music_volume: parseInt(e.target.value) })}
                            className="w-full mt-1"
                          />
                        </div>
                      </div>
                    </div>
                  </>
                  )}
                </div>

                {/* Verified Password Dialog */}
                <Dialog open={showVerifiedDialog} onOpenChange={setShowVerifiedDialog}>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg flex items-center justify-center">
                          <BadgeCheck className="w-6 h-6 text-white" />
                        </div>
                        Unlock Verified Badge
                      </DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-4 rounded-lg border border-amber-200">
                        <p className="text-sm text-gray-700 mb-2">
                          ✨ Get the golden verified badge on your profile
                        </p>
                        <p className="text-xs text-gray-500">
                          Enter the password to unlock this feature
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Password</Label>
                        <Input
                          type="password"
                          placeholder="Enter password..."
                          value={verifiedPassword}
                          onChange={(e) => {
                            setVerifiedPassword(e.target.value);
                            setVerifiedError('');
                          }}
                          onKeyDown={(e) => e.key === 'Enter' && handleVerifiedPasswordSubmit()}
                        />
                        {verifiedError && (
                          <p className="text-sm text-red-600">{verifiedError}</p>
                        )}
                      </div>

                      <Button 
                        onClick={handleVerifiedPasswordSubmit}
                        className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white"
                      >
                        Unlock Badge
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                {/* Premium Diamond Dialog */}
                <Dialog open={showPremiumDialog} onOpenChange={setShowPremiumDialog}>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <img 
                          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/c36c846e1_image-removebg-preview.png" 
                          alt="Diamond Badge" 
                          className="w-10 h-10 object-contain"
                        />
                        Unlock Diamond Badge
                      </DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="bg-gradient-to-br from-cyan-50 to-indigo-50 p-4 rounded-lg border border-cyan-200">
                        <p className="text-sm text-gray-700 mb-2">
                          💎 Get the exclusive diamond premium badge
                        </p>
                        <p className="text-xs text-gray-500">
                          Enter the super admin password to unlock this ultra premium feature
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Super Admin Password</Label>
                        <Input
                          type="password"
                          placeholder="Enter password..."
                          value={premiumPassword}
                          onChange={(e) => {
                            setPremiumPassword(e.target.value);
                            setPremiumError('');
                          }}
                          onKeyDown={(e) => e.key === 'Enter' && handlePremiumPasswordSubmit()}
                        />
                        {premiumError && (
                          <p className="text-sm text-red-600">{premiumError}</p>
                        )}
                      </div>

                      <Button 
                        onClick={handlePremiumPasswordSubmit}
                        className="w-full bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 hover:from-cyan-600 hover:via-blue-600 hover:to-indigo-600 text-white"
                      >
                        Unlock Diamond Badge
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                {/* Luxury Name Effect Dialog */}
                <Dialog open={showLuxuryNameDialog} onOpenChange={setShowLuxuryNameDialog}>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <div className="w-10 h-10 bg-gradient-to-br from-amber-500 via-yellow-500 to-amber-600 rounded-lg flex items-center justify-center">
                          <Sparkles className="w-6 h-6 text-white" />
                        </div>
                        Unlock Luxury Name Effect
                      </DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-4 rounded-lg border border-amber-200">
                        <p className="text-sm text-gray-700 mb-2">
                          ✨ Get the exclusive animated gold/diamond name effect
                        </p>
                        <p className="text-xs text-gray-500">
                          Enter the admin password to unlock this premium feature
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Admin Password</Label>
                        <Input
                          type="password"
                          placeholder="Enter password..."
                          value={luxuryNamePassword}
                          onChange={(e) => {
                            setLuxuryNamePassword(e.target.value);
                            setLuxuryNameError('');
                          }}
                          onKeyDown={(e) => e.key === 'Enter' && handleLuxuryNamePasswordSubmit()}
                        />
                        {luxuryNameError && (
                          <p className="text-sm text-red-600">{luxuryNameError}</p>
                        )}
                      </div>

                      <Button 
                        onClick={handleLuxuryNamePasswordSubmit}
                        className="w-full bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-600 hover:via-yellow-600 hover:to-amber-700 text-white"
                      >
                        Unlock Luxury Effect
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
                
                <div className="space-y-3 pt-6 border-t">
                  <div>
                    <Label className="text-base font-semibold text-gray-900">Profile Link Username</Label>
                    <p className="text-sm text-gray-500 mb-2">
                      Customize your unique profile link: {window.location.origin}{createPageUrl('PublicProfile')}?u=<span className="font-medium text-violet-600">{formData.username || 'username'}</span>
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <div className="flex-1 relative">
                      <Input
                        className="pl-9"
                        placeholder="username"
                        value={formData.username}
                        onChange={(e) => updateFormData({ username: e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, '') })}
                      />
                      <LinkIcon className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="contact">
            <div className="bg-white rounded-xl p-6 border border-gray-200 space-y-8">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={(e) => updateFormData({ email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Phone</Label>
                  <Input
                    placeholder="+1 234 567 890"
                    value={formData.phone}
                    onChange={(e) => updateFormData({ phone: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Website</Label>
                  <Input
                    placeholder="https://yourwebsite.com"
                    value={formData.website}
                    onChange={(e) => updateFormData({ website: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Location</Label>
                  <Input
                    placeholder="City, Country"
                    value={formData.location}
                    onChange={(e) => updateFormData({ location: e.target.value })}
                  />
                </div>
              </div>
              
              <div className="border-t pt-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium">Social Links</h3>
                  {hasChanges && (
                    <span className="text-sm text-orange-600 font-medium animate-pulse">
                      Unsaved changes - Click Save button
                    </span>
                  )}
                </div>
                <LinkEditor
                  links={formData.links}
                  onLinksChange={(links) => updateFormData({ links })}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="qrcodes">
            <div className="bg-white rounded-xl p-6 border border-gray-200">
              <QRCodeManager profileId={profileId} />
            </div>
          </TabsContent>

          <TabsContent value="design">
            <div className="bg-white rounded-xl p-6 border border-gray-200 space-y-6">
              <div>
                <Label className="mb-2 block">Cover Image</Label>
                <ImageUploader
                  type="cover"
                  currentImage={formData.cover_url}
                  previewStyles={formData}
                  onImageChange={(url) => updateFormData({ cover_url: url })}
                />
              </div>

              <ProfileDesignEditor
                formData={formData}
                setFormData={setFormData}
              />

              {hasChanges && (
                <div className="mt-6 pt-6 border-t">
                  <Button onClick={handleSave} disabled={isSaving} className="w-full bg-violet-600 hover:bg-violet-700">
                    {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                    Save Changes
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}