import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import VIPLoader from '@/components/vip/VIPLoader';
import FloatingAssistant from '@/components/vip/FloatingAssistant';
import VIPAdminPanel from '@/components/vip/VIPAdminPanel';
import { 
  Phone, 
  Mail, 
  Globe, 
  MapPin, 
  Download, 
  ExternalLink,
  Link as LinkIcon,
  Loader2,
  QrCode,
  Share2,
  BadgeCheck
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { socialPlatforms, platformCategories } from '@/components/profile/SocialPlatforms';
import { FileText, Image as ImageIcon, Play, Music, ChevronLeft, ChevronRight } from 'lucide-react';
import QRCodeGenerator from '@/components/profile/QRCodeGenerator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export default function PublicProfile() {
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const username = urlParams.get('u');
  const [showLoader, setShowLoader] = useState(false);
  const [loaderComplete, setLoaderComplete] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [logoTapCount, setLogoTapCount] = useState(0);
  const [isAdmin, setIsAdmin] = useState(false);

  const { data: profiles, isLoading, error } = useQuery({
    queryKey: ['publicProfile', username],
    queryFn: async () => {
      if (!username) return null;
      // Try to filter by username
      try {
         const result = await base44.entities.Profile.filter({ username });
         console.log('Fetched profile for', username, ':', result);
         return result;
      } catch (e) {
         console.error("Filter failed", e);
         // Fallback or rethrow
         throw e;
      }
    },
    enabled: !!username,
    retry: 1,
    staleTime: 0, // Don't cache - always fetch fresh
    cacheTime: 0 // Don't keep in cache
  });

  const profile = profiles?.[0];
  const currentUrl = window.location.href;

  // Check if user is admin
  useEffect(() => {
    base44.auth.me().then(user => {
      setIsAdmin(user?.role === 'admin');
    }).catch(() => setIsAdmin(false));
  }, []);

  // VIP Loader Logic
  useEffect(() => {
    if (profile && profile.vip_mode !== 'off' && profile.vip_loader_enabled && !loaderComplete) {
      setShowLoader(true);
    }
  }, [profile, loaderComplete]);

  // Hidden Admin Access - Logo Tap Detection
  const handleLogoTap = () => {
    if (!isAdmin) return;
    setLogoTapCount(prev => prev + 1);
    setTimeout(() => setLogoTapCount(0), 2000);
  };

  useEffect(() => {
    if (logoTapCount >= 5 && isAdmin) {
      setShowAdminPanel(true);
      setLogoTapCount(0);
    }
  }, [logoTapCount, isAdmin]);

  // Analytics: Increment view count on mount
  React.useEffect(() => {
    if (profile?.id) {
      // Simple increment
      base44.entities.Profile.update(profile.id, { views: (profile.views || 0) + 1 })
        .catch(err => console.error("Failed to track view", err));
    }
  }, [profile?.id]);

  // VIP Settings with safe defaults
  const vipEnabled = profile?.vip_mode && profile.vip_mode !== 'off';
  const animationsEnabled = (profile?.vip_animations_enabled && vipEnabled) || false;
  const nameColor = profile?.vip_name_color || 'gold';
  const customColors = Array.isArray(profile?.vip_name_custom_colors) ? profile.vip_name_custom_colors : ['#FFD700', '#FDB931', '#FFED4E'];
  const shiverIntensity = profile?.vip_shiver_intensity || 'medium';
  const luxuryNameStyle = profile?.luxury_name_style || 'filled';
  const backgroundMusic = profile?.vip_background_music || '';
  const musicVolume = typeof profile?.vip_music_volume === 'number' ? profile.vip_music_volume : 30;

  useEffect(() => {
    if (profile && loaderComplete) {
      base44.analytics.track({
        eventName: 'profile_view',
        properties: { profile_id: profile.id, username: profile.username }
      });
    }
  }, [profile, loaderComplete]);

  // Background Music - Handle YouTube and direct audio
  useEffect(() => {
    if (!backgroundMusic || !loaderComplete || !vipEnabled) return;

    // Check if it's a YouTube URL
    const isYouTube = backgroundMusic.includes('youtube.com') || backgroundMusic.includes('youtu.be');
    
    if (isYouTube) {
      // Extract video ID and create iframe for YouTube
      const videoId = backgroundMusic.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&?/]+)/)?.[1];
      if (!videoId) return;

      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.allow = 'autoplay';
      iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&loop=1&playlist=${videoId}&controls=0&showinfo=0`;
      document.body.appendChild(iframe);

      return () => {
        document.body.removeChild(iframe);
      };
    } else {
      // Direct audio file
      try {
        const audio = new Audio(backgroundMusic);
        audio.volume = musicVolume / 100;
        audio.loop = true;
        
        const playPromise = audio.play();
        if (playPromise !== undefined) {
          playPromise.catch(() => {
            // Auto-play blocked, wait for user interaction
            const playOnInteraction = () => {
              audio.play().catch(() => {});
              document.removeEventListener('click', playOnInteraction);
            };
            document.addEventListener('click', playOnInteraction);
          });
        }

        return () => {
          audio.pause();
          audio.src = '';
        };
      } catch (error) {
        console.error('Background music error:', error);
      }
    }
  }, [backgroundMusic, musicVolume, loaderComplete, vipEnabled]);
  
  // Design settings with defaults
  const themeColor = profile?.theme_color || '#7C3AED';
  const backgroundColor = profile?.background_color || null;
  const headerColor = profile?.header_color || null;
  const headerSize = profile?.header_size || 'standard';
  const coverZoom = profile?.cover_zoom || 1;
  const coverOffsetY = profile?.cover_offset_y === undefined ? 50 : profile.cover_offset_y;
  const coverOffsetX = profile?.cover_offset_x === undefined ? 50 : profile.cover_offset_x;
  const cardBackgroundColor = profile?.card_background_color || null;
  const isCardTransparent = profile?.is_card_transparent || false;
  const backdropBlur = profile?.backdrop_blur !== false;
  const isDark = profile?.background_mode === 'dark';
  const linksStyle = profile?.links_style || 'default';
  const fontFamily = profile?.font_family || 'inter';
  const showSaveContact = profile?.show_save_contact !== false;

  const fontMap = {
    inter: 'font-sans',
    playfair: 'font-serif',
    roboto: 'font-mono', // simplified mapping, ideally would load fonts
    lora: 'font-serif',
    montserrat: 'font-sans'
  };
  
  // Add Google Fonts logic would be needed for real custom fonts, 
  // but for now we'll map to standard tailwind classes or inline styles if possible.
  // Using inline style for fontFamily to support system fonts fallback
  
  const containerStyle = {
    fontFamily: fontFamily === 'playfair' || fontFamily === 'lora' ? 'serif' : 'sans-serif'
  };

  const generateVCard = () => {
    if (!profile) return;
    
    const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${profile.full_name || ''}
TITLE:${profile.title || ''}
ORG:${profile.company || ''}
TEL:${profile.phone || ''}
EMAIL:${profile.email || ''}
URL:${profile.website || ''}
ADR:;;${profile.location || ''}
NOTE:${profile.bio || ''}
END:VCARD`;

    const blob = new Blob([vcard], { type: 'text/vcard' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${profile.full_name || profile.username}.vcf`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Contact saved!');
  };

  const shareProfile = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${profile.full_name || profile.username}'s Profile`,
          text: 'Check out this profile!',
          url: currentUrl,
        });
      } catch (err) {
        navigator.clipboard.writeText(currentUrl);
        toast.success('Link copied!');
      }
    } else {
      navigator.clipboard.writeText(currentUrl);
      toast.success('Link copied!');
    }
  };

  const getFullUrl = (link) => {
    const platform = socialPlatforms[link.platform];
    if (!platform) return link.value;
    
    if (platform.inputType === 'phone' && link.country_code) {
      const cleanCode = link.country_code.replace('+', '');
      return `${platform.urlPrefix}${cleanCode}${link.value}`;
    }
    
    if (platform.inputType === 'email') {
      return `mailto:${link.value}`;
    }
    
    if (platform.inputType === 'url' || !platform.urlPrefix) {
      return link.value.startsWith('http') ? link.value : `https://${link.value}`;
    }
    
    return `${platform.urlPrefix}${link.value}`;
  };

  const getYouTubeEmbedUrl = (url) => {
    const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&?/]+)/);
    return match ? `https://www.youtube.com/embed/${match[1]}` : null;
  };

  const getVimeoEmbedUrl = (url) => {
    const match = url.match(/vimeo\.com\/(\d+)/);
    return match ? `https://player.vimeo.com/video/${match[1]}` : null;
  };

  const getSpotifyEmbedUrl = (url) => {
    const match = url.match(/open\.spotify\.com\/(track|album|playlist)\/([^?]+)/);
    return match ? `https://open.spotify.com/embed/${match[1]}/${match[2]}` : null;
  };

  const ImageCarousel = ({ images }) => {
    const [current, setCurrent] = React.useState(0);
    if (!images || images.length === 0) return null;
    
    return (
      <div className="relative rounded-xl overflow-hidden bg-gray-100">
        <img src={images[current]} alt="" className="w-full aspect-video object-cover" />
        {images.length > 1 && (
          <>
            <button
              onClick={() => setCurrent(c => c === 0 ? images.length - 1 : c - 1)}
              className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center text-white"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => setCurrent(c => c === images.length - 1 ? 0 : c + 1)}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center text-white"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
              {images.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrent(i)}
                  className={`w-2 h-2 rounded-full ${i === current ? 'bg-white' : 'bg-white/50'}`}
                />
              ))}
            </div>
          </>
        )}
      </div>
    );
  };

  const renderMediaLink = (link, index) => {
    const platform = socialPlatforms[link.platform];

    // Skip disabled links
    if (link.enabled === false) return null;
    
    // YouTube Embed
    if (link.platform === 'youtube_video' && link.value) {
      const embedUrl = getYouTubeEmbedUrl(link.value);
      if (embedUrl) {
        return (
          <div key={index} className="mb-4">
            {link.label && link.label !== 'YouTube Video (Embed)' && (
              <h4 className="font-medium text-gray-900 mb-2">{link.label}</h4>
            )}
            <div className="aspect-video rounded-xl overflow-hidden">
              <iframe
                src={embedUrl}
                className="w-full h-full"
                allowFullScreen
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              />
            </div>
          </div>
        );
      }
    }
    
    // Vimeo Embed
    if (link.platform === 'vimeo_video' && link.value) {
      const embedUrl = getVimeoEmbedUrl(link.value);
      if (embedUrl) {
        return (
          <div key={index} className="mb-4">
            {link.label && link.label !== 'Vimeo Video (Embed)' && (
              <h4 className="font-medium text-gray-900 mb-2">{link.label}</h4>
            )}
            <div className="aspect-video rounded-xl overflow-hidden">
              <iframe src={embedUrl} className="w-full h-full" allowFullScreen />
            </div>
          </div>
        );
      }
    }
    
    // Spotify Embed
    if (link.platform === 'spotify_embed' && link.value) {
      const embedUrl = getSpotifyEmbedUrl(link.value);
      if (embedUrl) {
        return (
          <div key={index} className="mb-4">
            {link.label && link.label !== 'Spotify (Embed Audio)' && (
              <h4 className="font-medium text-gray-900 mb-2">{link.label}</h4>
            )}
            <div className="rounded-xl overflow-hidden">
              <iframe
                src={embedUrl}
                className="w-full"
                height="152"
                allowFullScreen
                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
              />
            </div>
          </div>
        );
      }
    }
    
    return null;
  };

  // Group links by category (only visible links)
  const groupedLinks = (profile?.links || [])
    .filter(link => {
      // Check if link is explicitly disabled
      if (link.enabled === false) return false;
      // For media embeds, always include them in groupedLinks for renderMediaLink
      if (['image_gallery', 'pdf_document', 'youtube_video', 'vimeo_video', 'spotify_embed'].includes(link.platform)) {
        return true;
      }
      // For regular links, only show enabled ones
      return link.enabled !== false;
    })
    .reduce((acc, link) => {
      const category = link.category || 'other';
      if (!acc[category]) acc[category] = [];
      acc[category].push(link);
      return acc;
    }, {});

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
        <Loader2 className="w-10 h-10 animate-spin text-violet-600" />
        <p className="text-gray-500 mt-4 font-medium">Loading profile...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4 text-center">
        <h2 className="text-xl font-bold text-gray-900 mb-2">Something went wrong</h2>
        <p className="text-gray-500 mb-4">Unable to load profile. Please try again later.</p>
        <Button onClick={() => window.location.reload()} variant="outline">
          Retry
        </Button>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Profile Not Found</h1>
          <p className="text-gray-600 mb-6">This profile doesn't exist or has been removed.</p>
          <Link to={createPageUrl('Home')}>
            <Button className="bg-violet-600 hover:bg-violet-700 rounded-full">
              Create Your Free Profile
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* VIP Loader */}
      {showLoader && (
        <VIPLoader 
          profile={profile} 
          onComplete={() => {
            setShowLoader(false);
            setLoaderComplete(true);
          }} 
        />
      )}

      {/* Admin Panel */}
      {showAdminPanel && (
        <VIPAdminPanel
          profile={profile}
          onClose={() => setShowAdminPanel(false)}
          onUpdate={() => queryClient.invalidateQueries({ queryKey: ['publicProfile'] })}
        />
      )}

      {/* Floating Assistant */}
      {loaderComplete && profile.vip_floating_assistant && vipEnabled && !showLoader && (
        <FloatingAssistant
          profile={profile}
          onSaveContact={generateVCard}
          onShare={shareProfile}
        />
      )}
    <div 
      className={`min-h-screen ${!backgroundColor ? (isDark ? 'bg-gray-900' : 'bg-gray-100') : ''} transition-colors duration-300`}
      style={{ 
        ...containerStyle,
        backgroundColor: backgroundColor || undefined 
      }}
    >
      <div className="max-w-lg mx-auto">
        {/* Cover Image */}
        <div className="relative">
          <div 
            className={`overflow-hidden relative ${!headerColor ? 'bg-gradient-to-br from-violet-500 to-purple-600' : ''} ${
               headerSize === 'full' ? 'w-full' : 
               headerSize === 'square' ? 'aspect-square' :
               headerSize === 'tall' ? 'h-64 md:h-80' : 
               'h-40 md:h-52'
            }`}
            style={headerColor ? { backgroundColor: headerColor } : undefined}
          >
            {profile.cover_url && (
              <img 
                src={profile.cover_url} 
                alt="Cover" 
                className={`w-full ${headerSize === 'full' ? 'h-auto block' : 'h-full'} ${
                    headerSize !== 'full' ? (profile.cover_fit === 'contain' ? 'object-contain' : 'object-cover') : ''
                }`}
                style={{ 
                  objectPosition: headerSize !== 'full' ? `${coverOffsetX}% ${coverOffsetY}%` : undefined,
                  transform: headerSize !== 'full' ? `scale(${coverZoom})` : undefined,
                  transformOrigin: headerSize !== 'full' ? `${coverOffsetX}% ${coverOffsetY}%` : undefined
                }}
              />
            )}
            {!profile.cover_url && headerSize === 'full' && (
                <div className="h-40 md:h-52 w-full" />
            )}
          </div>
          
          {/* Action buttons */}
          <div className="absolute top-4 right-4 flex gap-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button size="icon" variant="secondary" className="rounded-full bg-white/90 hover:bg-white">
                  <QrCode className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Scan to Connect</DialogTitle>
                </DialogHeader>
                <div className="flex flex-col items-center py-6">
                  <QRCodeGenerator url={currentUrl} size={250} />
                </div>
              </DialogContent>
            </Dialog>
            <Button 
              size="icon" 
              variant="secondary" 
              className="rounded-full bg-white/90 hover:bg-white"
              onClick={shareProfile}
            >
              <Share2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Profile Content */}
        <div 
          className={`rounded-t-3xl -mt-6 relative shadow-lg min-h-[60vh] transition-colors duration-300`}
          style={{
            backgroundColor: isCardTransparent 
              ? 'transparent' 
              : (cardBackgroundColor || (backgroundColor ? (isDark ? 'rgba(0,0,0,0.2)' : 'rgba(255,255,255,0.8)') : (isDark ? '#1f2937' : '#ffffff'))),
            color: isDark ? '#ffffff' : '#111827',
            backdropFilter: backdropBlur && (isCardTransparent || backgroundColor || (!cardBackgroundColor && !isCardTransparent)) ? 'blur(12px)' : 'none',
            boxShadow: isCardTransparent ? 'none' : undefined
          }}
        >
          {/* Avatar */}
          <div className="flex justify-center -mt-16 relative z-10">
            <div 
              className={`w-32 h-32 rounded-full border-4 overflow-hidden shadow-lg transition-colors duration-300`}
              style={{
                borderColor: isCardTransparent 
                  ? (isDark ? '#1f2937' : '#ffffff') 
                  : (cardBackgroundColor || (backgroundColor ? (isDark ? '#1f2937' : '#ffffff') : (isDark ? '#1f2937' : '#ffffff'))),
                backgroundColor: isDark ? '#1f2937' : '#ffffff'
              }}
            >
              {profile.avatar_url ? (
                <img 
                  src={profile.avatar_url} 
                  alt={profile.full_name} 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-violet-400 to-purple-500 text-white text-4xl font-bold">
                  {(profile.full_name || profile.username || '?')[0].toUpperCase()}
                </div>
              )}
            </div>
          </div>

          {/* Info */}
          <div className="text-center px-6 pt-4 pb-6">
            <div className="flex items-center justify-center gap-2">
              <h1 className={`text-2xl font-bold relative ${(profile.luxury_name_effect || vipEnabled) && luxuryNameStyle !== 'none' ? `luxury-text luxury-${luxuryNameStyle}` : isDark ? 'text-white' : 'text-gray-900'}`}>
                {animationsEnabled && (
                  <span className="absolute -inset-4 bg-gradient-to-r from-transparent via-amber-400/10 to-transparent animate-shimmer-once" />
                )}
                {profile.full_name || profile.username}
              </h1>
              {profile.is_premium_verified ? (
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/c36c846e1_image-removebg-preview.png" 
                  alt="Diamond Badge" 
                  className="w-9 h-9 object-contain"
                />
              ) : profile.is_verified ? (
                <BadgeCheck className="w-8 h-8 text-white fill-amber-500" />
              ) : null}
            </div>

            <style>{`
              @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@700;900&display=swap');

              .luxury-text {
                font-family: 'Cinzel', serif;
                font-weight: 900;
                letter-spacing: 0.08em;
                position: relative;
              }

              /* Filled Style - Default */
              .luxury-filled {
                background: ${(() => {
                  try {
                    if (nameColor === 'gold') return 'linear-gradient(135deg, #FFD700 0%, #FDB931 10%, #FFED4E 20%, #d4af37 30%, #FFD700 40%, #f9e79f 50%, #FFD700 60%, #d4af37 70%, #FFED4E 80%, #FDB931 90%, #FFD700 100%)';
                    if (nameColor === 'diamond') return 'linear-gradient(135deg, #00D4FF 0%, #0EA5E9 10%, #38BDF8 20%, #7DD3FC 30%, #BAE6FD 40%, #E0F2FE 50%, #BAE6FD 60%, #7DD3FC 70%, #38BDF8 80%, #0EA5E9 90%, #00D4FF 100%)';
                    if (nameColor === 'rainbow') return 'linear-gradient(135deg, #FF0080 0%, #FF8C00 16%, #FFD700 33%, #00FF00 50%, #00BFFF 66%, #8A2BE2 83%, #FF0080 100%)';
                    if (nameColor === 'fire') return 'linear-gradient(135deg, #FF4500 0%, #FF6347 16%, #FF8C00 33%, #FFA500 50%, #FFD700 66%, #FF6347 83%, #FF4500 100%)';
                    if (nameColor === 'ocean') return 'linear-gradient(135deg, #006994 0%, #00A8CC 16%, #00D4FF 33%, #38BDF8 50%, #00BFFF 66%, #0EA5E9 83%, #006994 100%)';
                    if (nameColor === 'custom' && Array.isArray(customColors) && customColors.length > 0) {
                      const validColors = customColors.filter(c => c && typeof c === 'string');
                      if (validColors.length > 0) {
                        const colors = validColors.map((c, i) => `${c} ${(i / (validColors.length - 1)) * 100}%`).join(', ');
                        return `linear-gradient(135deg, ${colors})`;
                      }
                    }
                    return 'linear-gradient(135deg, #FFD700 0%, #FDB931 50%, #FFD700 100%)';
                  } catch (e) {
                    return 'linear-gradient(135deg, #FFD700 0%, #FDB931 50%, #FFD700 100%)';
                  }
                })()};
                background-size: 300% auto;
                -webkit-background-clip: text;
                background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: luxuryShine 4s linear infinite;
                filter: ${(() => {
                  try {
                    if (nameColor === 'gold') return 'drop-shadow(0 0 20px rgba(255, 215, 0, 0.8)) drop-shadow(0 0 40px rgba(255, 215, 0, 0.4))';
                    if (nameColor === 'diamond') return 'drop-shadow(0 0 20px rgba(14, 165, 233, 0.8)) drop-shadow(0 0 40px rgba(56, 189, 248, 0.4))';
                    if (nameColor === 'rainbow') return 'drop-shadow(0 0 20px rgba(255, 0, 128, 0.6)) drop-shadow(0 0 40px rgba(138, 43, 226, 0.4))';
                    if (nameColor === 'fire') return 'drop-shadow(0 0 20px rgba(255, 69, 0, 0.8)) drop-shadow(0 0 40px rgba(255, 140, 0, 0.5))';
                    if (nameColor === 'ocean') return 'drop-shadow(0 0 20px rgba(0, 105, 148, 0.8)) drop-shadow(0 0 40px rgba(0, 168, 204, 0.4))';
                    return 'drop-shadow(0 0 20px rgba(255, 215, 0, 0.8)) drop-shadow(0 0 40px rgba(255, 215, 0, 0.4))';
                  } catch (e) {
                    return 'drop-shadow(0 0 20px rgba(255, 215, 0, 0.8)) drop-shadow(0 0 40px rgba(255, 215, 0, 0.4))';
                  }
                })()};
              }

              /* Outline Style */
              .luxury-outline {
                color: transparent;
                -webkit-text-stroke: 2px ${(() => {
                  if (nameColor === 'gold') return '#FFD700';
                  if (nameColor === 'diamond') return '#00D4FF';
                  if (nameColor === 'fire') return '#FF4500';
                  if (nameColor === 'ocean') return '#00A8CC';
                  return '#FFD700';
                })()};
                text-shadow: 0 0 20px ${(() => {
                  if (nameColor === 'gold') return 'rgba(255, 215, 0, 0.6)';
                  if (nameColor === 'diamond') return 'rgba(0, 212, 255, 0.6)';
                  if (nameColor === 'fire') return 'rgba(255, 69, 0, 0.6)';
                  if (nameColor === 'ocean') return 'rgba(0, 168, 204, 0.6)';
                  return 'rgba(255, 215, 0, 0.6)';
                })()};
                animation: outlineGlow 3s ease-in-out infinite;
              }

              /* Box Style */
              .luxury-box {
                background: ${(() => {
                  try {
                    if (nameColor === 'gold') return 'linear-gradient(135deg, #FFD700 0%, #FDB931 50%, #FFD700 100%)';
                    if (nameColor === 'diamond') return 'linear-gradient(135deg, #00D4FF 0%, #0EA5E9 50%, #00D4FF 100%)';
                    if (nameColor === 'rainbow') return 'linear-gradient(135deg, #FF0080 0%, #FFD700 33%, #00BFFF 66%, #FF0080 100%)';
                    if (nameColor === 'fire') return 'linear-gradient(135deg, #FF4500 0%, #FFA500 50%, #FF4500 100%)';
                    if (nameColor === 'ocean') return 'linear-gradient(135deg, #006994 0%, #00D4FF 50%, #006994 100%)';
                    return 'linear-gradient(135deg, #FFD700 0%, #FDB931 50%, #FFD700 100%)';
                  } catch (e) {
                    return 'linear-gradient(135deg, #FFD700 0%, #FDB931 50%, #FFD700 100%)';
                  }
                })()};
                background-size: 300% auto;
                -webkit-background-clip: text;
                background-clip: text;
                -webkit-text-fill-color: transparent;
                padding: 12px 24px;
                border-radius: 16px;
                display: inline-block;
                animation: luxuryShine 4s linear infinite;
              }

              .luxury-box::before {
                content: '';
                position: absolute;
                inset: 0;
                background: ${(() => {
                  if (nameColor === 'gold') return 'linear-gradient(135deg, rgba(255, 215, 0, 0.2), rgba(253, 185, 49, 0.2))';
                  if (nameColor === 'diamond') return 'linear-gradient(135deg, rgba(0, 212, 255, 0.2), rgba(14, 165, 233, 0.2))';
                  if (nameColor === 'fire') return 'linear-gradient(135deg, rgba(255, 69, 0, 0.2), rgba(255, 165, 0, 0.2))';
                  if (nameColor === 'ocean') return 'linear-gradient(135deg, rgba(0, 105, 148, 0.2), rgba(0, 212, 255, 0.2))';
                  return 'linear-gradient(135deg, rgba(255, 215, 0, 0.2), rgba(253, 185, 49, 0.2))';
                })()};
                border-radius: 16px;
                border: 2px solid ${(() => {
                  if (nameColor === 'gold') return 'rgba(255, 215, 0, 0.4)';
                  if (nameColor === 'diamond') return 'rgba(0, 212, 255, 0.4)';
                  if (nameColor === 'fire') return 'rgba(255, 69, 0, 0.4)';
                  if (nameColor === 'ocean') return 'rgba(0, 168, 204, 0.4)';
                  return 'rgba(255, 215, 0, 0.4)';
                })()};
                z-index: -1;
                animation: boxPulse 2s ease-in-out infinite;
              }

              @keyframes outlineGlow {
                0%, 100% {
                  -webkit-text-stroke-width: 2px;
                  text-shadow: 0 0 20px ${(() => {
                    if (nameColor === 'gold') return 'rgba(255, 215, 0, 0.6)';
                    if (nameColor === 'diamond') return 'rgba(0, 212, 255, 0.6)';
                    return 'rgba(255, 215, 0, 0.6)';
                  })()};
                }
                50% {
                  -webkit-text-stroke-width: 3px;
                  text-shadow: 0 0 40px ${(() => {
                    if (nameColor === 'gold') return 'rgba(255, 215, 0, 0.9)';
                    if (nameColor === 'diamond') return 'rgba(0, 212, 255, 0.9)';
                    return 'rgba(255, 215, 0, 0.9)';
                  })()};
                }
              }

              @keyframes boxPulse {
                0%, 100% {
                  box-shadow: 0 0 20px ${(() => {
                    if (nameColor === 'gold') return 'rgba(255, 215, 0, 0.4)';
                    if (nameColor === 'diamond') return 'rgba(0, 212, 255, 0.4)';
                    return 'rgba(255, 215, 0, 0.4)';
                  })()};
                }
                50% {
                  box-shadow: 0 0 40px ${(() => {
                    if (nameColor === 'gold') return 'rgba(255, 215, 0, 0.6)';
                    if (nameColor === 'diamond') return 'rgba(0, 212, 255, 0.6)';
                    return 'rgba(255, 215, 0, 0.6)';
                  })()};
                }
              }

              @keyframes luxuryShine {
                0% {
                  background-position: 0% center;
                  filter: drop-shadow(0 0 20px rgba(255, 215, 0, 0.8)) 
                          drop-shadow(0 0 40px rgba(255, 215, 0, 0.4))
                          drop-shadow(0 4px 8px rgba(212, 175, 55, 0.6))
                          brightness(1.2);
                }
                50% {
                  background-position: 100% center;
                  filter: drop-shadow(0 0 30px rgba(255, 215, 0, 1)) 
                          drop-shadow(0 0 60px rgba(255, 215, 0, 0.6))
                          drop-shadow(0 4px 8px rgba(212, 175, 55, 0.8))
                          brightness(1.5);
                }
                100% {
                  background-position: 200% center;
                  filter: drop-shadow(0 0 20px rgba(255, 215, 0, 0.8)) 
                          drop-shadow(0 0 40px rgba(255, 215, 0, 0.4))
                          drop-shadow(0 4px 8px rgba(212, 175, 55, 0.6))
                          brightness(1.2);
                }
              }

              .luxury-filled::after, .luxury-outline::after {
                content: '';
                position: absolute;
                top: -50%;
                left: -10%;
                width: 120%;
                height: 200%;
                background: linear-gradient(90deg, 
                  transparent 0%,
                  rgba(255, 255, 255, ${shiverIntensity === 'none' ? 0 : shiverIntensity === 'subtle' ? 0.2 : shiverIntensity === 'medium' ? 0.4 : 0.7}) 50%,
                  transparent 100%
                );
                animation: ${shiverIntensity === 'none' ? 'none' : shiverIntensity === 'subtle' ? 'shiver 12s ease-in-out infinite' : shiverIntensity === 'medium' ? 'shiver 8s ease-in-out infinite' : 'shiver 4s ease-in-out infinite'};
                pointer-events: none;
              }

              @keyframes shiver {
                0%, 100% {
                  transform: translateX(-100%) skewX(${shiverIntensity === 'intense' ? '-30deg' : '-20deg'});
                  opacity: 0;
                }
                5% {
                  opacity: 1;
                }
                10%, 90% {
                  transform: translateX(100%) skewX(${shiverIntensity === 'intense' ? '-30deg' : '-20deg'});
                  opacity: 0;
                }
              }

              @keyframes shimmer-once {
                0% {
                  transform: translateX(-100%);
                  opacity: 0;
                }
                50% {
                  opacity: 1;
                }
                100% {
                  transform: translateX(100%);
                  opacity: 0;
                }
              }

              .animate-shimmer-once {
                animation: shimmer-once 2s ease-in-out;
              }
            `}</style>
            {profile.title && (
              <p className="font-medium mt-1" style={{ color: themeColor }}>
                {profile.title}
                {profile.company && <span className={isDark ? 'text-gray-400' : 'text-gray-500'}> at {profile.company}</span>}
              </p>
            )}
            {profile.bio && (
              <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'} mt-3 text-sm leading-relaxed`}>
                {profile.bio}
              </p>
            )}

            {/* Contact Info */}
            <div className={`flex flex-wrap justify-center gap-4 mt-4 text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
              {profile.phone && (
                <a 
                  href={`tel:${profile.phone}`}
                  className={`flex items-center gap-1 hover:opacity-80 transition-colors`}
                  style={{ color: isDark ? '#fff' : themeColor }}
                >
                  <Phone className="w-4 h-4" />
                  {profile.phone}
                </a>
              )}
              {profile.email && (
                <a 
                  href={`mailto:${profile.email}`}
                  className={`flex items-center gap-1 hover:opacity-80 transition-colors`}
                  style={{ color: isDark ? '#fff' : themeColor }}
                >
                  <Mail className="w-4 h-4" />
                  {profile.email}
                </a>
              )}
              {profile.website && (
                <a 
                  href={profile.website.startsWith('http') ? profile.website : `https://${profile.website}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center gap-1 hover:opacity-80 transition-colors`}
                  style={{ color: isDark ? '#fff' : themeColor }}
                >
                  <Globe className="w-4 h-4" />
                  Website
                </a>
              )}
              {profile.location && (
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {profile.location}
                </span>
              )}
            </div>

            {/* Save Contact Button */}
            {showSaveContact && (
              <Button 
                onClick={generateVCard}
                className={`mt-6 w-full rounded-full text-white transition-all active:scale-95 shadow-lg ${animationsEnabled ? 'vip-button-hover' : ''}`}
                style={{ backgroundColor: themeColor }}
              >
                <Download className={`w-4 h-4 mr-2 ${animationsEnabled ? 'vip-icon-hover' : ''}`} />
                Save Contact
              </Button>
            )}
          </div>

          {/* Links Section */}
          {profile.links && profile.links.length > 0 && (
            <div className="px-6 pb-8">
              {/* First render video and audio embeds */}
              {profile.links.filter(l => l.enabled !== false && ['youtube_video', 'vimeo_video', 'spotify_embed', 'soundcloud_embed'].includes(l.platform)).length > 0 && (
                <div className="mb-6">
                  {profile.links
                    .filter(link => link.enabled !== false && ['youtube_video', 'vimeo_video', 'spotify_embed', 'soundcloud_embed'].includes(link.platform))
                    .map((link, index) => renderMediaLink(link, index))}
                </div>
              )}

              {/* Then render regular links by category */}
              {Object.entries(groupedLinks).map(([category, links]) => {
                // Filter out ALL media from regular link display
                const regularLinks = links.filter(l => !['image_gallery', 'pdf_document', 'youtube_video', 'vimeo_video', 'spotify_embed', 'soundcloud_embed'].includes(l.platform));
                if (regularLinks.length === 0) return null;
                
                return (
                  <div key={category} className="mb-6">
                    <h3 className={`text-sm font-semibold uppercase tracking-wider mb-3 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                      {platformCategories[category] || 'Other'}
                    </h3>
                    <div className="space-y-3">
                      {regularLinks.map((link, index) => {
                        const platform = socialPlatforms[link.platform];
                        const url = getFullUrl(link);
                        
                        // Link Styles Logic
                        let linkClasses = "flex items-center gap-4 p-4 rounded-xl transition-all duration-200 group border";
                        
                        if (isDark) {
                          linkClasses += " bg-gray-700 hover:bg-gray-600 border-gray-600";
                        } else {
                          linkClasses += " bg-gray-50 hover:bg-gray-100 border-transparent";
                        }

                        if (linksStyle === 'highlighted') {
                          linkClasses += " shadow-sm hover:shadow-md";
                          if (isDark) linkClasses += " border-gray-600";
                          else linkClasses += " border-gray-200";
                        }

                        const iconContainerStyle = {
                           backgroundColor: isDark ? 'rgba(255,255,255,0.1)' : (platform?.color || '#6B7280') + '15' 
                        };

                        return (
                          <a
                            key={index}
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={linkClasses}
                            style={{ 
                                borderColor: linksStyle === 'highlighted' ? themeColor : undefined,
                                borderWidth: linksStyle === 'highlighted' ? '1px' : undefined
                            }}
                          >
                            {linksStyle !== 'left' && (
                              <div className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center" style={iconContainerStyle}>
                                {platform?.icon ? (
                                  <img 
                                    src={platform.icon} 
                                    alt={platform.name}
                                    className="w-6 h-6 object-contain"
                                    onError={(e) => {
                                      e.target.onerror = null;
                                      e.target.src = '';
                                      e.target.style.display = 'none';
                                    }}
                                  />
                                ) : (
                                  <LinkIcon className="w-5 h-5" style={{ color: platform?.color || (isDark ? '#fff' : '#6B7280') }} />
                                )}
                              </div>
                            )}
                            
                            <div className={`flex-1 min-w-0 ${linksStyle === 'left' ? 'text-left' : ''}`}>
                              <div className={`font-medium transition-colors ${isDark ? 'text-white' : 'text-gray-900'}`}
                                   style={{ color: linksStyle === 'highlighted' ? themeColor : undefined }}
                              >
                                {link.label || platform?.name || 'Link'}
                              </div>
                              {platform?.inputType === 'phone' && link.country_code && (
                                <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                                  {link.country_code} {link.value}
                                </div>
                              )}
                              {platform?.inputType === 'email' && (
                                <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{link.value}</div>
                              )}
                            </div>

                            {linksStyle === 'left' && (
                              <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center" style={iconContainerStyle}>
                                 {platform?.icon ? (
                                  <img 
                                    src={platform.icon} 
                                    alt={platform.name}
                                    className="w-4 h-4 object-contain"
                                  />
                                ) : (
                                  <LinkIcon className="w-4 h-4" style={{ color: platform?.color || (isDark ? '#fff' : '#6B7280') }} />
                                )}
                              </div>
                            )}
                            
                            {linksStyle !== 'left' && (
                                <ExternalLink className={`w-5 h-5 transition-colors ${isDark ? 'text-gray-500 group-hover:text-white' : 'text-gray-400'}`} 
                                  style={{ color: isDark ? undefined : themeColor }}
                                />
                            )}
                          </a>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
              
              {/* PDF Documents Section */}
              {profile.links.filter(l => l.enabled !== false && l.platform === 'pdf_document' && (l.pdf?.url || l.pdf)).length > 0 && (
                <div className="mt-8">
                  <h3 className={`text-sm font-semibold uppercase tracking-wider mb-3 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                    Documents
                  </h3>
                  <div className="space-y-3">
                    {profile.links
                      .filter(link => link.enabled !== false && link.platform === 'pdf_document' && (link.pdf?.url || link.pdf))
                      .map((link, index) => {
                        const pdfUrl = typeof link.pdf === 'string' ? link.pdf : link.pdf?.url;
                        const pdfName = typeof link.pdf === 'string' ? link.pdf.split('/').pop() : (link.pdf?.name || 'Document');
                        
                        return (
                          <a
                            key={index}
                            href={pdfUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`flex items-center gap-4 p-4 rounded-xl transition-all duration-200 ${
                              isDark ? 'bg-red-900/20 hover:bg-red-900/30' : 'bg-red-50 hover:bg-red-100'
                            }`}
                          >
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                              isDark ? 'bg-red-900/40' : 'bg-red-100'
                            }`}>
                              <FileText className="w-6 h-6 text-red-600" />
                            </div>
                            <div className="flex-1">
                              <div className={`font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>
                                {link.label || pdfName}
                              </div>
                              <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                                PDF Document
                              </div>
                            </div>
                            <ExternalLink className={`w-5 h-5 ${isDark ? 'text-gray-500' : 'text-gray-400'}`} />
                          </a>
                        );
                      })}
                  </div>
                </div>
              )}
              
              {/* Instagram-Style Image Gallery */}
              {profile.links.filter(l => l.enabled !== false && l.platform === 'image_gallery' && l.images?.length > 0).length > 0 && (
                <div className="mt-8">
                  <h3 className={`text-sm font-semibold uppercase tracking-wider mb-3 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                    Gallery
                  </h3>
                  <div className="grid grid-cols-3 gap-1">
                    {profile.links
                      .filter(link => link.enabled !== false && link.platform === 'image_gallery' && link.images?.length > 0)
                      .flatMap(link => link.images || [])
                      .map((image, index) => (
                        <div
                          key={index}
                          className="aspect-square rounded overflow-hidden bg-gray-100 cursor-pointer hover:opacity-90 transition-opacity"
                          onClick={() => window.open(image, '_blank')}
                        >
                          <img 
                            src={image} 
                            alt="" 
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Footer */}
          <div className={`text-center pb-8 border-t pt-6 px-6 ${isDark ? 'border-gray-700' : 'border-gray-100'}`}>
            <Link 
              to={createPageUrl('Home')}
              className={`inline-flex items-center gap-2 text-sm transition-colors ${isDark ? 'text-gray-500 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`}
            >
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/f80600f2a_WhatsApp_Image_2025-11-25_at_114437_AM-removebg-preview.png" 
                alt="SOS4DIGITAL" 
                className="h-6 w-6 cursor-pointer" 
                onClick={handleLogoTap}
              />
              <span className="font-bold">SOS4DIGITAL</span>
            </Link>
          </div>
        </div>
      </div>

        {/* VIP Animations Styles */}
        {animationsEnabled && (
          <>
            <style>{`
              @keyframes vip-hover-glow {
                0%, 100% { 
                  box-shadow: 0 4px 30px rgba(212, 175, 55, 0.3), 0 0 50px rgba(212, 175, 55, 0.1); 
                }
                50% { 
                  box-shadow: 0 8px 50px rgba(212, 175, 55, 0.6), 0 0 80px rgba(212, 175, 55, 0.3); 
                }
              }

              @keyframes vip-pulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.05); }
              }

              @keyframes vip-shimmer {
                0% { background-position: -200% center; }
                100% { background-position: 200% center; }
              }

              @keyframes vip-float {
                0%, 100% { transform: translateY(0px); }
                50% { transform: translateY(-10px); }
              }

              @keyframes vip-glow-border {
                0%, 100% { border-color: rgba(212, 175, 55, 0.3); }
                50% { border-color: rgba(212, 175, 55, 0.8); }
              }

              .vip-button-hover {
                position: relative;
                transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                overflow: hidden;
              }

              .vip-button-hover::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
                transition: left 0.5s;
              }

              .vip-button-hover:hover::before {
                left: 100%;
              }

              .vip-button-hover:hover {
                transform: translateY(-4px) scale(1.02);
                animation: vip-hover-glow 2s ease-in-out infinite;
              }

              .vip-icon-hover {
                transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                display: inline-block;
              }

              .vip-icon-hover:hover {
                transform: scale(1.2) rotate(5deg);
                filter: drop-shadow(0 0 15px rgba(212, 175, 55, 0.8));
                animation: vip-pulse 1s ease-in-out infinite;
              }

              /* Apply to all links and cards */
              ${isDark ? '.bg-gray-700' : '.bg-gray-50'} {
                transition: all 0.3s ease;
                border: 1px solid transparent;
              }

              ${isDark ? '.bg-gray-700' : '.bg-gray-50'}:hover {
                animation: vip-glow-border 2s ease-in-out infinite;
                transform: translateY(-2px);
                box-shadow: 0 10px 40px rgba(212, 175, 55, 0.2);
              }
            `}</style>
            
            {/* Floating Gold Particles */}
            <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
              {[...Array(15)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-1 h-1 bg-amber-400 rounded-full opacity-50"
                  style={{
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                    animation: `vip-float ${3 + Math.random() * 4}s ease-in-out infinite`,
                    animationDelay: `${Math.random() * 2}s`,
                  }}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </>
  );
}