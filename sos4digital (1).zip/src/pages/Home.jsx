import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { 
  ArrowRight, 
  Sparkles, 
  Users, 
  BarChart3, 
  Share2, 
  Palette,
  Globe,
  Shield,
  Zap,
  QrCode,
  Wifi,
  Menu,
  X,
  User,
  Check,
  Minus,
  Pencil
} from 'lucide-react';

const features = [
  {
    icon: Users,
    title: "Unlimited Profiles",
    description: "Create as many profiles as you need - completely free, forever.",
    color: "from-blue-500 to-blue-600"
  },
  {
    icon: QrCode,
    title: "Dynamic QR Codes",
    description: "Create unlimited editable QR codes that you can update anytime - 100% free.",
    color: "from-indigo-500 to-purple-600"
  },
  {
    icon: Share2,
    title: "Easy Sharing",
    description: "Share your profile with a simple link or QR code.",
    color: "from-violet-500 to-purple-600"
  },
  {
    icon: Palette,
    title: "Customizable",
    description: "Add your photo, cover image, and customize your links.",
    color: "from-pink-500 to-rose-600"
  },
  {
    icon: Globe,
    title: "All Platforms",
    description: "Support for 30+ social media and business platforms.",
    color: "from-green-500 to-emerald-600"
  },
  {
    icon: Zap,
    title: "Instant Setup",
    description: "Create your digital business card in under 2 minutes.",
    color: "from-orange-500 to-amber-600"
  },
  {
    icon: Shield,
    title: "Privacy First",
    description: "You control what information to share with whom.",
    color: "from-cyan-500 to-teal-600"
  }
];

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const authenticated = await base44.auth.isAuthenticated();
        setIsAuthenticated(authenticated);
      } catch (e) {
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };
    checkAuth();
  }, []);

  const handleGetStarted = async () => {
    const myProfilesUrl = createPageUrl('MyProfiles');
    console.log('Get started clicked');
    
    try {
      const authenticated = await base44.auth.isAuthenticated();
      console.log('Auth check result:', authenticated);
      
      if (authenticated) {
        window.location.href = myProfilesUrl;
      } else {
        base44.auth.redirectToLogin(myProfilesUrl);
      }
    } catch (error) {
      console.log('Auth error, redirecting to login:', error);
      base44.auth.redirectToLogin(myProfilesUrl);
    }
  };

  return (
    <div className="min-h-screen bg-white pb-20 md:pb-0">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-b border-gray-100 select-none" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between h-16">
            <Link to={createPageUrl('Home')} className="flex items-center gap-2">
                            <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/f80600f2a_WhatsApp_Image_2025-11-25_at_114437_AM-removebg-preview.png" alt="SOS4DIGITAL" className="h-10 w-10" />
                            <span className="text-xl font-bold text-gray-900">SOS4DIGITAL</span>
                          </Link>
            
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-gray-600 hover:text-gray-900">Features</a>
              <a href="#how-it-works" className="text-gray-600 hover:text-gray-900">How it Works</a>
              <a href="#qr-codes" className="text-gray-600 hover:text-gray-900">QR Codes</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900">Pricing</a>
            </div>
            
            <div className="flex items-center gap-4">
              {!isLoading ? (
                isAuthenticated ? (
                  <Link to={createPageUrl('MyProfiles')}>
                    <Button className="bg-violet-600 hover:bg-violet-700 rounded-full select-none">
                      <User className="w-4 h-4 mr-2" />
                      My Profiles
                    </Button>
                  </Link>
                ) : (
                  <Button 
                    type="button"
                    onClick={handleGetStarted}
                    className="bg-violet-600 hover:bg-violet-700 rounded-full select-none"
                  >
                    Get Started Free
                  </Button>
                )
              ) : (
                <Button disabled className="bg-violet-600 rounded-full opacity-50 select-none">
                  Loading...
                </Button>
              )}
              
              <Button 
                variant="ghost" 
                size="icon" 
                className="md:hidden select-none"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X /> : <Menu />}
              </Button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 py-4 px-6">
            <a href="#features" className="block py-2 text-gray-600">Features</a>
            <a href="#how-it-works" className="block py-2 text-gray-600">How it Works</a>
            <a href="#qr-codes" className="block py-2 text-gray-600">QR Codes</a>
            <a href="#pricing" className="block py-2 text-gray-600">Pricing</a>
            </div>
            )}
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-violet-50/50 to-white pointer-events-none" />
        
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 bg-violet-100 text-violet-700 px-4 py-2 rounded-full text-sm font-medium mb-8"
            >
              <Sparkles className="w-4 h-4" />
              100% Free • Unlimited Profiles
            </motion.div>
            
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 leading-tight tracking-tight">
              Tap Into Advanced
              <span className="block bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
                Networking
              </span>
            </h1>
            
            <p className="mt-8 text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
              Create your free digital business card. Share your contact info, social media, and more with a single link.
            </p>
            
            <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button 
                type="button"
                size="lg" 
                onClick={handleGetStarted}
                className="bg-violet-600 hover:bg-violet-700 text-white px-8 py-6 text-lg rounded-full group cursor-pointer"
              >
                Start For Free Now
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </motion.div>
          
          {/* Phone mockups */}
          <motion.div 
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="mt-20 relative"
          >
            <div className="flex justify-center items-end gap-4 md:gap-8">
              {/* Center phone - main */}
              <motion.div 
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="w-64 md:w-72 lg:w-80 z-10"
              >
                <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-gray-300/50 border border-gray-100 p-3">
                  <div className="flex justify-center mb-2">
                    <div className="w-24 h-6 bg-black rounded-full" />
                  </div>
                  <div className="bg-gradient-to-b from-violet-50 to-white rounded-3xl p-6 text-center">
                    <img 
                      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/92a73df84_WhatsAppImage2026-02-04at41655PM.jpeg" 
                      alt="Khaled Kassab" 
                      className="w-20 h-20 mx-auto rounded-full object-cover mb-4" 
                      style={{ objectPosition: 'center 20%' }}
                    />
                    <h3 className="font-semibold text-gray-900">Khaled Kassab</h3>
                                              <p className="text-sm text-gray-500">Marketing Department</p>
                    <div className="flex justify-center gap-4 mt-6">
                      <div className="w-12 h-12 rounded-full bg-violet-100 flex items-center justify-center">
                        <svg className="w-5 h-5 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                      </div>
                      <div className="w-12 h-12 rounded-full bg-violet-100 flex items-center justify-center">
                        <svg className="w-5 h-5 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                      </div>
                      <div className="w-12 h-12 rounded-full bg-violet-100 flex items-center justify-center">
                        <svg className="w-5 h-5 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
              Features
            </h2>
            <p className="mt-6 text-xl text-gray-600">
              Everything you need to create the perfect digital business card
            </p>
          </motion.div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group"
              >
                <div className="bg-white rounded-3xl p-8 h-full border border-gray-100 hover:border-violet-200 hover:shadow-xl hover:shadow-violet-100/50 transition-all duration-300">
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                    <feature.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* QR Codes Section */}
      <section id="qr-codes" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <div className="inline-flex items-center gap-2 bg-violet-100 text-violet-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Sparkles className="w-4 h-4" />
              100% Free • Unlimited QR Codes
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
              Dynamic QR Codes
            </h2>
            <p className="mt-6 text-xl text-gray-600">
              Create unlimited editable QR codes that you can update anytime - completely free for everyone
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-violet-50 to-purple-50 rounded-2xl p-8 text-center border border-violet-100"
            >
              <div className="w-14 h-14 bg-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <QrCode className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Create Unlimited</h3>
              <p className="text-gray-600">Generate as many QR codes as you need, all completely free</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-8 text-center border border-blue-100"
            >
              <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Pencil className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Edit Anytime</h3>
              <p className="text-gray-600">Change where your QR codes point to without reprinting them</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-8 text-center border border-green-100"
            >
              <div className="w-14 h-14 bg-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Track Scans</h3>
              <p className="text-gray-600">Monitor how many times each QR code has been scanned</p>
            </motion.div>
          </div>

          <div className="text-center mt-12">
            <Button 
              type="button"
              size="lg"
              onClick={handleGetStarted}
              className="bg-violet-600 hover:bg-violet-700 rounded-full px-8 cursor-pointer"
            >
              Start Creating QR Codes Free
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
              How it works
            </h2>
          </motion.div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: 1, title: "Sign Up Free", desc: "Create your account in seconds" },
              { step: 2, title: "Build Your Profile", desc: "Add your info and social links" },
              { step: 3, title: "Share Everywhere", desc: "Send your link to anyone" }
            ].map((item, index) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15 }}
                className="text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-violet-600 flex items-center justify-center mx-auto mb-6 text-white text-2xl font-bold">
                  {item.step}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  {item.title}
                </h3>
                <p className="text-gray-600">
                  {item.desc}
                </p>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center mt-16">
            <Button 
              type="button"
              size="lg"
              onClick={handleGetStarted}
              className="bg-violet-600 hover:bg-violet-700 rounded-full px-8 cursor-pointer"
            >
              Create Your Free Profile
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
          </div>
          </section>

          {/* Comparison Section */}
          <section className="py-24 bg-white">
            <div className="max-w-7xl mx-auto px-6">
              <div className="text-center max-w-3xl mx-auto mb-16">
                <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
                  Why Choose SOS4DIGITAL?
                </h2>
                <p className="mt-6 text-xl text-gray-600">
                  See how we compare to other platforms like GetTap
                </p>
              </div>

              <div className="max-w-4xl mx-auto bg-gray-50 rounded-3xl p-8 border border-gray-200 overflow-hidden">
                <div className="grid grid-cols-3 gap-4 mb-6 text-sm md:text-base font-semibold text-gray-900 border-b border-gray-200 pb-4">
                  <div className="text-gray-500 font-normal">Features</div>
                  <div className="text-center text-violet-600 text-xl">SOS4DIGITAL</div>
                  <div className="text-center text-gray-500">GetTap & Others</div>
                </div>

                <div className="space-y-6">
                  <div className="grid grid-cols-3 gap-4 items-center">
                    <div className="font-medium text-gray-700">Profile Limit</div>
                    <div className="text-center flex flex-col items-center text-violet-700 font-bold bg-violet-100 rounded-lg py-2">
                      <span>Unlimited</span>
                      <span className="text-xs font-normal opacity-75">No restrictions</span>
                    </div>
                    <div className="text-center text-gray-500 flex flex-col items-center">
                      <span>Limited</span>
                      <span className="text-xs opacity-75">Max 5 profiles</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 items-center">
                    <div className="font-medium text-gray-700">Customization</div>
                    <div className="text-center flex justify-center text-violet-600">
                      <Check className="w-6 h-6" />
                    </div>
                    <div className="text-center flex justify-center text-gray-400">
                      <span className="text-sm">Basic</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 items-center">
                    <div className="font-medium text-gray-700">Analytics</div>
                    <div className="text-center flex justify-center text-violet-600">
                      <Check className="w-6 h-6" />
                    </div>
                    <div className="text-center flex justify-center text-gray-400">
                      <Minus className="w-6 h-6" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Pricing Section */}
          <section id="pricing" className="py-24 bg-gray-50">
            <div className="max-w-7xl mx-auto px-6">
              <div className="text-center max-w-3xl mx-auto mb-16">
                <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
                  Flexible Pricing
                </h2>
                <p className="mt-6 text-xl text-gray-600">
                  Tailored solutions for every business need
                </p>
              </div>

              <div className="max-w-md mx-auto">
                <div className="bg-white rounded-3xl p-8 border border-gray-200 shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 bg-violet-600 text-white px-4 py-1 rounded-bl-xl font-medium text-sm">
                    ENTERPRISE
                  </div>

                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Custom Plan</h3>
                  <div className="flex items-baseline gap-1 mb-6">
                    <span className="text-lg text-gray-600 font-medium">Pricing varies based on requirements</span>
                  </div>

                  <ul className="space-y-4 mb-8">
                    <li className="flex items-center gap-3 text-gray-600">
                      <div className="w-6 h-6 rounded-full bg-violet-100 flex items-center justify-center flex-shrink-0">
                        <Users className="w-4 h-4 text-violet-600" />
                      </div>
                      <span>Unlimited Profiles & Teams</span>
                    </li>
                    <li className="flex items-center gap-3 text-gray-600">
                      <div className="w-6 h-6 rounded-full bg-violet-100 flex items-center justify-center flex-shrink-0">
                        <BarChart3 className="w-4 h-4 text-violet-600" />
                      </div>
                      <span>Advanced Corporate Analytics</span>
                    </li>
                    <li className="flex items-center gap-3 text-gray-600">
                      <div className="w-6 h-6 rounded-full bg-violet-100 flex items-center justify-center flex-shrink-0">
                        <Globe className="w-4 h-4 text-violet-600" />
                      </div>
                      <span>White-label Solution</span>
                    </li>
                  </ul>

                  <Button 
                    asChild
                    className="w-full bg-violet-600 hover:bg-violet-700 text-white rounded-full py-6 text-lg"
                  >
                    <a href="mailto:coretap.bz@gmail.com?subject=Inquiry%20about%20Custom%20Pricing">
                      Get a Quote
                    </a>
                  </Button>
                  <p className="text-center text-sm text-gray-500 mt-4">
                    Contact us at <a href="mailto:coretap.bz@gmail.com" className="text-violet-600 font-medium">coretap.bz@gmail.com</a>
                  </p>
                </div>
              </div>
            </div>
          </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
                          <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692530d2b0134c286d203ad2/f80600f2a_WhatsApp_Image_2025-11-25_at_114437_AM-removebg-preview.png" alt="SOS4DIGITAL" className="h-10 w-10" />
                          <span className="text-2xl font-bold">SOS4DIGITAL</span>
                        </div>
                        <p className="text-gray-400 mb-6">
                          The future of digital business cards. 100% free.
                        </p>
                        <p className="text-gray-500 text-sm">
                          © 2026 SOS4DIGITAL. All rights reserved.
                        </p>
        </div>
      </footer>
    </div>
  );
}