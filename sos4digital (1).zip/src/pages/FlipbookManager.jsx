import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { 
  Upload, 
  BookOpen, 
  Eye, 
  Lock, 
  Globe, 
  Trash2, 
  Copy, 
  ExternalLink,
  FileText,
  Plus,
  Loader2,
  ArrowLeft
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from "sonner";

export default function FlipbookManager() {
  const queryClient = useQueryClient();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    access_type: 'public',
    password: '',
    allow_download: true,
    allow_print: true,
    sound_enabled: true
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: flipbooks, isLoading } = useQuery({
    queryKey: ['flipbooks'],
    queryFn: async () => {
      const result = await base44.entities.Flipbook.filter({ created_by: user?.email });
      return result.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    },
    enabled: !!user
  });

  const createFlipbookMutation = useMutation({
    mutationFn: (data) => base44.entities.Flipbook.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['flipbooks'] });
      setShowCreateDialog(false);
      setFormData({
        title: '',
        description: '',
        access_type: 'public',
        password: '',
        allow_download: true,
        allow_print: true,
        sound_enabled: true
      });
      toast.success('Flipbook created successfully!');
    }
  });

  const deleteFlipbookMutation = useMutation({
    mutationFn: (id) => base44.entities.Flipbook.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['flipbooks'] });
      toast.success('Flipbook deleted');
    }
  });

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast.error('Please upload a PDF file');
      return;
    }

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      const shortCode = Math.random().toString(36).substring(2, 10);
      
      await createFlipbookMutation.mutateAsync({
        title: formData.title || file.name.replace('.pdf', ''),
        description: formData.description,
        pdf_url: file_url,
        short_code: shortCode,
        access_type: formData.access_type,
        password: formData.access_type === 'password' ? formData.password : null,
        file_size: file.size,
        allow_download: formData.allow_download,
        allow_print: formData.allow_print,
        sound_enabled: formData.sound_enabled
      });
    } catch (error) {
      toast.error('Failed to upload PDF');
      console.error(error);
    } finally {
      setUploading(false);
    }
  };

  const copyFlipbookUrl = (shortCode) => {
    const url = `${window.location.origin}${createPageUrl('FlipbookViewer')}?id=${shortCode}`;
    navigator.clipboard.writeText(url);
    toast.success('Link copied to clipboard!');
  };

  const getAccessBadge = (accessType) => {
    switch (accessType) {
      case 'public':
        return <Badge className="bg-green-500"><Globe className="w-3 h-3 mr-1" />Public</Badge>;
      case 'private':
        return <Badge className="bg-gray-500"><Eye className="w-3 h-3 mr-1" />Private</Badge>;
      case 'password':
        return <Badge className="bg-orange-500"><Lock className="w-3 h-3 mr-1" />Password</Badge>;
      default:
        return null;
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6 pb-24 md:pb-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('MyProfiles')}>
              <Button variant="outline" size="icon" className="rounded-full">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <BookOpen className="w-8 h-8 text-violet-600" />
                PDF to Link
              </h1>
              <p className="text-gray-600 mt-1">Upload PDFs and generate shareable links</p>
            </div>
          </div>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="bg-violet-600 hover:bg-violet-700">
                <Plus className="w-4 h-4 mr-2" />
                Upload PDF
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Upload PDF</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Title</Label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="My Interactive Flipbook"
                  />
                </div>
                <div>
                  <Label>Description (Optional)</Label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Add a description..."
                  />
                </div>
                <div>
                  <Label>Access Type</Label>
                  <Select value={formData.access_type} onValueChange={(value) => setFormData({ ...formData, access_type: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="public">Public - Anyone with link</SelectItem>
                      <SelectItem value="private">Private - Only you</SelectItem>
                      <SelectItem value="password">Password Protected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {formData.access_type === 'password' && (
                  <div>
                    <Label>Password</Label>
                    <Input
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      placeholder="Enter password"
                    />
                  </div>
                )}
                <div className="grid grid-cols-3 gap-4">
                  <div className="flex items-center justify-between">
                    <Label>Allow Download</Label>
                    <Switch
                      checked={formData.allow_download}
                      onCheckedChange={(checked) => setFormData({ ...formData, allow_download: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Allow Print</Label>
                    <Switch
                      checked={formData.allow_print}
                      onCheckedChange={(checked) => setFormData({ ...formData, allow_print: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Page Flip Sound</Label>
                    <Switch
                      checked={formData.sound_enabled}
                      onCheckedChange={(checked) => setFormData({ ...formData, sound_enabled: checked })}
                    />
                  </div>
                </div>
                <div>
                  <Label>Upload PDF</Label>
                  <div className="mt-2">
                    <input
                      type="file"
                      accept=".pdf"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="pdf-upload"
                      disabled={uploading}
                    />
                    <label htmlFor="pdf-upload">
                      <Button disabled={uploading} asChild>
                        <span className="cursor-pointer">
                          {uploading ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Uploading...
                            </>
                          ) : (
                            <>
                              <Upload className="w-4 h-4 mr-2" />
                              Choose PDF File
                            </>
                          )}
                        </span>
                      </Button>
                    </label>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {flipbooks && flipbooks.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <BookOpen className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No PDFs yet</h3>
              <p className="text-gray-600 mb-6">Upload your first PDF to generate a shareable link</p>
              <Button onClick={() => setShowCreateDialog(true)} className="bg-violet-600 hover:bg-violet-700">
                <Plus className="w-4 h-4 mr-2" />
                Upload Your First PDF
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {flipbooks?.map((flipbook) => (
              <Card key={flipbook.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-2">{flipbook.title}</CardTitle>
                      {getAccessBadge(flipbook.access_type)}
                    </div>
                    <FileText className="w-8 h-8 text-violet-600" />
                  </div>
                </CardHeader>
                <CardContent>
                  {flipbook.description && (
                    <p className="text-sm text-gray-600 mb-4 line-clamp-2">{flipbook.description}</p>
                  )}
                  <div className="space-y-2 text-sm text-gray-600 mb-4">
                    <div className="flex justify-between">
                      <span>Views:</span>
                      <span className="font-medium">{flipbook.views || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Size:</span>
                      <span className="font-medium">{formatFileSize(flipbook.file_size || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Created:</span>
                      <span className="font-medium">{new Date(flipbook.created_date).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="bg-gray-50 rounded p-2 border border-gray-200">
                      <p className="text-xs text-gray-500 mb-1">Shareable Link:</p>
                      <div className="flex items-center gap-2">
                        <code className="text-xs bg-white px-2 py-1 rounded flex-1 truncate border">
                          {`${window.location.origin}${createPageUrl('FlipbookViewer')}?id=${flipbook.short_code}`}
                        </code>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 flex-shrink-0"
                          onClick={() => copyFlipbookUrl(flipbook.short_code)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Link to={`${createPageUrl('FlipbookViewer')}?id=${flipbook.short_code}`} className="flex-1">
                        <Button variant="outline" className="w-full">
                          <Eye className="w-4 h-4 mr-2" />
                          View
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => {
                          window.open(flipbook.pdf_url, '_blank');
                        }}
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => {
                          if (confirm('Are you sure you want to delete this flipbook?')) {
                            deleteFlipbookMutation.mutate(flipbook.id);
                          }
                        }}
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}