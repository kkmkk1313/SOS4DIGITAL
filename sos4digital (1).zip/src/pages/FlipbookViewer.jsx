import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Maximize, 
  Download,
  Loader2,
  Lock,
  FileText
} from 'lucide-react';
import { toast } from "sonner";

export default function FlipbookViewer() {
  const urlParams = new URLSearchParams(window.location.search);
  const shortCode = urlParams.get('id');
  const [passwordPrompt, setPasswordPrompt] = useState(false);
  const [password, setPassword] = useState('');
  const [authenticated, setAuthenticated] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef();

  const { data: flipbook, isLoading } = useQuery({
    queryKey: ['flipbook', shortCode],
    queryFn: async () => {
      const result = await base44.entities.Flipbook.filter({ short_code: shortCode });
      if (result.length === 0) throw new Error('Flipbook not found');
      
      const flipbook = result[0];
      
      // Increment view count
      await base44.entities.Flipbook.update(flipbook.id, { 
        views: (flipbook.views || 0) + 1 
      });
      
      return flipbook;
    },
    enabled: !!shortCode
  });

  useEffect(() => {
    if (!flipbook) return;

    // Check access
    if (flipbook.access_type === 'password' && !authenticated) {
      setPasswordPrompt(true);
      return;
    }
  }, [flipbook, authenticated]);

  const handlePasswordSubmit = () => {
    if (password === flipbook?.password) {
      setAuthenticated(true);
      setPasswordPrompt(false);
    } else {
      toast.error('Incorrect password');
    }
  };



  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handleDownload = () => {
    if (!flipbook?.allow_download) {
      toast.error('Download is not allowed for this document');
      return;
    }
    
    const confirmed = window.confirm('Do you want to download this PDF document?');
    if (confirmed) {
      const link = document.createElement('a');
      link.href = flipbook.pdf_url;
      link.download = flipbook.title + '.pdf';
      link.click();
      toast.success('Download started');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900">
        <Loader2 className="w-12 h-12 animate-spin text-violet-500 mb-4" />
        <p className="text-gray-400">Loading flipbook...</p>
      </div>
    );
  }

  if (!flipbook) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900">
        <h2 className="text-2xl font-bold text-white mb-2">Flipbook Not Found</h2>
        <p className="text-gray-400">This flipbook doesn't exist or has been removed.</p>
      </div>
    );
  }

  return (
    <>
      <Dialog open={passwordPrompt} onOpenChange={setPasswordPrompt}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Password Protected
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-gray-600">This flipbook is password protected. Please enter the password to continue.</p>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              onKeyPress={(e) => e.key === 'Enter' && handlePasswordSubmit()}
            />
            <Button onClick={handlePasswordSubmit} className="w-full">
              Unlock
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <div className="fixed inset-0 bg-gray-900 flex flex-col">
        {/* Header */}
        <div className="bg-gray-800 border-b border-gray-700 p-4 flex-shrink-0">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold text-white">{flipbook.title}</h1>
            <div className="flex items-center gap-2">
              {flipbook.allow_download && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleDownload}
                  className="text-gray-400 hover:text-white"
                >
                  <Download className="w-5 h-5" />
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleFullscreen}
                className="text-gray-400 hover:text-white"
              >
                <Maximize className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* PDF Viewer */}
        <div className="flex-1 bg-gray-900 overflow-hidden" ref={containerRef}>
          {flipbook?.pdf_url ? (
            <iframe
              src={flipbook.pdf_url}
              className="w-full h-full border-0"
              title={flipbook?.title}
              allow="fullscreen"
              loading="eager"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <div className="text-center text-gray-400">
                <FileText className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p>PDF not available</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}