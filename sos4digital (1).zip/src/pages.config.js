/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Admin from './pages/Admin';
import Dashboard from './pages/Dashboard';
import EditProfile from './pages/EditProfile';
import FlipbookManager from './pages/FlipbookManager';
import FlipbookViewer from './pages/FlipbookViewer';
import Home from './pages/Home';
import MyProfiles from './pages/MyProfiles';
import PDFManager from './pages/PDFManager';
import PDFViewer from './pages/PDFViewer';
import PublicProfile from './pages/PublicProfile';
import QRCodes from './pages/QRCodes';
import QRRedirect from './pages/QRRedirect';
import Settings from './pages/Settings';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Admin": Admin,
    "Dashboard": Dashboard,
    "EditProfile": EditProfile,
    "FlipbookManager": FlipbookManager,
    "FlipbookViewer": FlipbookViewer,
    "Home": Home,
    "MyProfiles": MyProfiles,
    "PDFManager": PDFManager,
    "PDFViewer": PDFViewer,
    "PublicProfile": PublicProfile,
    "QRCodes": QRCodes,
    "QRRedirect": QRRedirect,
    "Settings": Settings,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};