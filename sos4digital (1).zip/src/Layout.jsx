import React from 'react';
import MobileBottomTabs from '@/components/MobileBottomTabs';

export default function Layout({ children, currentPageName }) {
  const showBottomTabs = ['Home', 'MyProfiles', 'QRCodes', 'FlipbookManager', 'Settings'].includes(currentPageName);
  
  return (
    <>
      {children}
      {showBottomTabs && <MobileBottomTabs />}
    </>
  );
}