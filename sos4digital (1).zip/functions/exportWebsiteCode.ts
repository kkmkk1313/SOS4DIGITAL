import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import JSZip from 'npm:jszip@3.10.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Admin-only access
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const zip = new JSZip();

    // Create complete folder structure
    const srcFolder = zip.folder("src");
    const pagesFolder = srcFolder.folder("pages");
    const componentsFolder = srcFolder.folder("components");
    const functionsFolder = zip.folder("functions");
    const entitiesFolder = zip.folder("entities");
    const assetsFolder = zip.folder("public/assets");
    const configFolder = zip.folder("config");

    // Helper function to fetch file content from the app
    const fetchFileContent = async (path) => {
      try {
        const response = await fetch(`${Deno.env.get('BASE44_APP_URL') || 'http://localhost:5173'}/${path}`);
        if (response.ok) {
          return await response.text();
        }
      } catch (e) {
        console.log(`Could not fetch ${path}:`, e.message);
      }
      return null;
    };

    // Export Pages - List of all known pages
    const pagesList = [
      'Home.js', 'MyProfiles.js', 'EditProfile.js', 'PublicProfile.js',
      'Admin.jsx', 'QRCodes.js', 'QRRedirect.js', 'Dashboard.js'
    ];

    for (const page of pagesList) {
      const content = await fetchFileContent(`src/pages/${page}`);
      if (content) {
        pagesFolder.file(page, content);
      }
    }

    // Export Components - List of known components
    const componentsList = [
      'profile/ImageUploader.jsx',
      'profile/LinkEditor.jsx',
      'profile/ProfileDesignEditor.jsx',
      'profile/QRCodeGenerator.jsx',
      'profile/QRCodeManager.jsx',
      'profile/SocialPlatforms.js',
      'profile/CountryCodes.js',
      'profile/MediaUploader.jsx',
      'landing/HeroSection.jsx',
      'landing/FeaturesSection.jsx',
      'landing/Footer.jsx',
      'landing/Navbar.jsx',
      'UserNotRegisteredError.jsx'
    ];

    for (const component of componentsList) {
      const content = await fetchFileContent(`src/components/${component}`);
      if (content) {
        const parts = component.split('/');
        if (parts.length > 1) {
          const folder = componentsFolder.folder(parts[0]);
          folder.file(parts[1], content);
        } else {
          componentsFolder.file(component, content);
        }
      }
    }

    // Export UI Components
    const uiComponents = [
      'button.jsx', 'input.jsx', 'label.jsx', 'textarea.jsx', 'switch.jsx',
      'dialog.jsx', 'tabs.jsx', 'select.jsx', 'slider.jsx', 'badge.jsx',
      'card.jsx', 'alert.jsx', 'toast.jsx', 'dropdown-menu.jsx', 'popover.jsx'
    ];

    const uiFolder = componentsFolder.folder('ui');
    for (const uiComp of uiComponents) {
      const content = await fetchFileContent(`src/components/ui/${uiComp}`);
      if (content) {
        uiFolder.file(uiComp, content);
      }
    }

    // Export Functions - List all backend functions
    const functionsList = [
      'exportWebsiteCode.js',
      'importProfile.js'
    ];

    for (const func of functionsList) {
      const content = await fetchFileContent(`functions/${func}`);
      if (content) {
        functionsFolder.file(func, content);
      }
    }

    // Export Entities Schemas
    const entityNames = ['Profile', 'QRCode', 'User'];
    for (const entityName of entityNames) {
      try {
        let schema;
        if (entityName === 'Profile') {
          schema = await base44.entities.Profile.schema();
        } else if (entityName === 'QRCode') {
          schema = await base44.entities.QRCode.schema();
        }
        
        if (schema) {
          entitiesFolder.file(`${entityName}.json`, JSON.stringify(schema, null, 2));
        }
      } catch (e) {
        console.log(`Could not get schema for ${entityName}`);
      }
    }

    // Export Layout
    const layoutContent = await fetchFileContent('src/Layout.js');
    if (layoutContent) {
      srcFolder.file('Layout.js', layoutContent);
    }

    // Export main App.jsx with routing
    const appContent = `import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';

// Pages
import Home from './pages/Home';
import MyProfiles from './pages/MyProfiles';
import EditProfile from './pages/EditProfile';
import PublicProfile from './pages/PublicProfile';
import Admin from './pages/Admin';
import QRCodes from './pages/QRCodes';
import QRRedirect from './pages/QRRedirect';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/my-profiles" element={<MyProfiles />} />
          <Route path="/edit-profile" element={<EditProfile />} />
          <Route path="/profile" element={<PublicProfile />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/qr-codes" element={<QRCodes />} />
          <Route path="/qr" element={<QRRedirect />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
      <Toaster position="top-center" />
    </QueryClientProvider>
  );
}

export default App;`;
    srcFolder.file('App.jsx', appContent);

    // Export main.jsx (entry point)
    const mainContent = `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);`;
    srcFolder.file('main.jsx', mainContent);

    // Export utils
    const utilsContent = `export const createPageUrl = (pageName) => {
  const routes = {
    'Home': '/',
    'MyProfiles': '/my-profiles',
    'EditProfile': '/edit-profile',
    'PublicProfile': '/profile',
    'Admin': '/admin',
    'QRCodes': '/qr-codes',
    'QRRedirect': '/qr'
  };
  return routes[pageName] || '/';
};`;
    srcFolder.file('utils.js', utilsContent);

    // Export Base44 API client mock
    const apiClientContent = `// Base44 SDK Client Configuration
// Replace with your actual Base44 app credentials
export const base44 = {
  auth: {
    me: async () => ({ email: 'user@example.com', role: 'admin' }),
    isAuthenticated: async () => true,
    logout: () => window.location.reload(),
    redirectToLogin: (url) => window.location.href = '/login',
    updateMe: async (data) => ({ success: true })
  },
  entities: {
    Profile: {
      list: async () => [],
      filter: async (query) => [],
      create: async (data) => ({ id: Date.now(), ...data }),
      update: async (id, data) => ({ id, ...data }),
      delete: async (id) => ({ success: true }),
      schema: async () => ({})
    },
    QRCode: {
      list: async () => [],
      filter: async (query) => [],
      create: async (data) => ({ id: Date.now(), ...data }),
      update: async (id, data) => ({ id, ...data }),
      delete: async (id) => ({ success: true }),
      schema: async () => ({})
    },
    User: {
      filter: async (query) => [],
      update: async (id, data) => ({ id, ...data })
    }
  },
  functions: {
    invoke: async (name, params) => ({ data: {} })
  },
  integrations: {
    Core: {
      UploadFile: async ({ file }) => ({ file_url: URL.createObjectURL(file) }),
      InvokeLLM: async (params) => ({ data: {} })
    }
  },
  users: {
    inviteUser: async (email, role) => ({ success: true })
  },
  asServiceRole: {
    entities: {
      Profile: {
        list: async () => []
      },
      QRCode: {
        list: async () => []
      }
    }
  }
};`;
    const apiFolder = srcFolder.folder('api');
    apiFolder.file('base44Client.js', apiClientContent);

    // Export index.html
    const indexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SOS4DIGITAL - Digital Business Cards</title>
  <meta name="description" content="Create your free digital business card">
</head>
<body>
  <div id="root"></div>
  <script type="module" src="/src/main.jsx"></script>
</body>
</html>`;
    zip.file('index.html', indexHtml);

    // Export CSS
    const cssContent = `@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 222.2 84% 4.9%;
    --primary: 262.1 83.3% 57.8%;
    --primary-foreground: 210 40% 98%;
  }
  
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
  }
}`;
    srcFolder.file('index.css', cssContent);

    // Export Tailwind Config
    const tailwindConfig = `/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}`;
    zip.file('tailwind.config.js', tailwindConfig);

    // Export PostCSS Config
    const postcssConfig = `export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}`;
    zip.file('postcss.config.js', postcssConfig);

    // Export Vite Config
    const viteConfig = `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});`;
    zip.file('vite.config.js', viteConfig);

    // Export complete package.json
    const packageInfo = {
      name: "sos4digital-complete",
      version: "1.0.0",
      description: "Complete SOS4DIGITAL website - Digital Business Cards Platform",
      type: "module",
      scripts: {
        dev: "vite",
        build: "vite build",
        preview: "vite preview"
      },
      dependencies: {
        "react": "^18.2.0",
        "react-dom": "^18.2.0",
        "react-router-dom": "^6.26.0",
        "@tanstack/react-query": "^5.84.1",
        "framer-motion": "^11.16.4",
        "lucide-react": "^0.475.0",
        "tailwind-merge": "^3.0.2",
        "clsx": "^2.1.1",
        "class-variance-authority": "^0.7.1",
        "sonner": "^2.0.1",
        "jszip": "^3.10.1",
        "@radix-ui/react-dialog": "^1.1.6",
        "@radix-ui/react-tabs": "^1.1.3",
        "@radix-ui/react-switch": "^1.1.3",
        "@radix-ui/react-select": "^2.1.6",
        "@radix-ui/react-label": "^2.1.2",
        "@radix-ui/react-slider": "^1.2.3",
        "date-fns": "^3.6.0",
        "react-hook-form": "^7.54.2"
      },
      devDependencies: {
        "@vitejs/plugin-react": "^4.2.1",
        "vite": "^5.0.0",
        "tailwindcss": "^3.4.0",
        "autoprefixer": "^10.4.16",
        "postcss": "^8.4.32"
      }
    };
    zip.file('package.json', JSON.stringify(packageInfo, null, 2));

    // Export comprehensive README
    const readme = `# SOS4DIGITAL - Complete Website Export
    
**Export Date:** ${new Date().toISOString()}

## 🚀 Quick Start

\`\`\`bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
\`\`\`

The website will open at http://localhost:5173

## 📁 Project Structure

\`\`\`
sos4digital-complete/
├── src/
│   ├── pages/              # All page components
│   │   ├── Home.js         # Landing page
│   │   ├── MyProfiles.js   # User profiles dashboard
│   │   ├── EditProfile.js  # Profile editor
│   │   ├── PublicProfile.js # Public profile view
│   │   ├── Admin.jsx       # Admin dashboard
│   │   ├── QRCodes.js      # QR codes manager
│   │   └── QRRedirect.js   # QR redirect handler
│   ├── components/         # Reusable components
│   │   ├── profile/        # Profile-related components
│   │   ├── landing/        # Landing page sections
│   │   └── ui/             # UI primitives (buttons, inputs, etc)
│   ├── api/
│   │   └── base44Client.js # API client (needs configuration)
│   ├── App.jsx            # Main app with routing
│   ├── main.jsx           # Entry point
│   ├── utils.js           # Utility functions
│   └── index.css          # Global styles
├── functions/             # Backend serverless functions
├── entities/              # Database entity schemas
├── public/
│   └── assets/           # Static assets
├── index.html            # HTML entry point
├── package.json          # Dependencies
├── vite.config.js        # Vite configuration
├── tailwind.config.js    # Tailwind CSS config
└── postcss.config.js     # PostCSS config
\`\`\`

## 🔧 Configuration Required

### 1. Base44 SDK Setup
Edit \`src/api/base44Client.js\` and configure with your Base44 credentials:
- App ID
- API keys
- Backend URL

### 2. Backend Functions
Deploy functions to Deno Deploy or your serverless platform:
- \`functions/importProfile.js\`
- \`functions/exportWebsiteCode.js\`

### 3. Entity Schemas
Import entity schemas from \`entities/\` folder to your database.

## 🌟 Features

- ✅ Unlimited digital business card profiles
- ✅ Dynamic QR codes with scan tracking
- ✅ Customizable themes and designs
- ✅ Social media integration
- ✅ Admin dashboard
- ✅ Profile import with AI
- ✅ Complete responsive design

## 🛠️ Tech Stack

- **Frontend:** React 18, Vite, TailwindCSS
- **Routing:** React Router v6
- **State Management:** TanStack Query
- **Animations:** Framer Motion
- **UI Components:** Radix UI
- **Icons:** Lucide React
- **Backend:** Deno Deploy (serverless functions)
- **Database:** Base44 Platform

## 📝 Notes

- All pages are fully linked and functional
- Routes are configured in \`src/App.jsx\`
- Base44 SDK client needs proper configuration
- Images are stored externally (URLs in assets/images-list.json)
- Backend functions require deployment to work

## 🚀 Deployment

### Frontend
\`\`\`bash
npm run build
# Deploy 'dist' folder to Vercel, Netlify, or any static host
\`\`\`

### Backend Functions
Deploy each function in \`functions/\` to Deno Deploy or AWS Lambda.

## 📞 Support

Built with ❤️ on Base44 Platform
Website: https://sos4digital.com
Email: coretap.bz@gmail.com

---

**IMPORTANT:** This is a complete, working export. All pages are interconnected and ready to run locally. Just install dependencies and start the dev server!
`;
    zip.file('README.md', readme);

    // Add .gitignore
    const gitignore = `node_modules
dist
.env
.env.local
*.log`;
    zip.file('.gitignore', gitignore);

    // Add .env.example
    const envExample = `# Base44 Configuration
VITE_BASE44_APP_ID=your_app_id
VITE_BASE44_API_KEY=your_api_key
VITE_BASE44_APP_URL=https://your-app.base44.com

# Backend Functions URL
VITE_FUNCTIONS_URL=https://your-functions.deno.dev`;
    zip.file('.env.example', envExample);

    // Get all profiles and their images
    try {
      const allProfiles = await base44.asServiceRole.entities.Profile.list('-created_date', 1000);
      const imagesList = [];
      
      for (const profile of allProfiles) {
        if (profile.avatar_url) {
          imagesList.push({
            type: 'avatar',
            profile_id: profile.id,
            username: profile.username,
            url: profile.avatar_url
          });
        }
        if (profile.cover_url) {
          imagesList.push({
            type: 'cover',
            profile_id: profile.id,
            username: profile.username,
            url: profile.cover_url
          });
        }
      }

      assetsFolder.file('images-list.json', JSON.stringify(imagesList, null, 2));
      assetsFolder.file('images-note.txt', 'Images are stored in Supabase Storage. URLs are listed in images-list.json. To download them, fetch each URL and save locally.');
    } catch (e) {
      console.log('Could not fetch profile images:', e.message);
    }

    // Generate the zip file
    const zipBlob = await zip.generateAsync({ 
      type: 'uint8array',
      compression: 'DEFLATE',
      compressionOptions: { level: 9 }
    });

    // Return as downloadable file
    return new Response(zipBlob, {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename=sos4digital-export-${new Date().toISOString().split('T')[0]}.zip`,
        'Content-Length': zipBlob.length.toString()
      }
    });

  } catch (error) {
    console.error('Export error:', error);
    return Response.json({ 
      error: error.message,
      stack: error.stack 
    }, { status: 500 });
  }
});