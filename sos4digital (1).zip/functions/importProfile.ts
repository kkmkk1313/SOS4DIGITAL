import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

export default async function handler(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const { url, file_url } = await req.json();

    if (!url && !file_url) {
      return new Response(JSON.stringify({ error: 'Please provide a URL or upload a file.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    let contextData = "";

    // If URL is provided, try to fetch its content to help the LLM
    if (url) {
        try {
            console.log("Fetching URL:", url);
            const controller = new AbortController();
            const id = setTimeout(() => controller.abort(), 8000); // 8s timeout
            const res = await fetch(url, { 
                headers: { 
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
                },
                signal: controller.signal
            });
            clearTimeout(id);
            
            if (res.ok) {
                const text = await res.text();
                // Extract title
                const titleMatch = text.match(/<title[^>]*>([^<]+)<\/title>/i);
                const pageTitle = titleMatch ? titleMatch[1].trim() : "";
                
                // Extract meta tags (description, og:title, og:description, etc)
                const metaTags = [];
                const metaRegex = /<meta\s+(?:name|property)=["']([^"']+)["']\s+content=["']([^"']+)["']\s*\/?>/gi;
                let match;
                while ((match = metaRegex.exec(text)) !== null) {
                    if (['description', 'og:title', 'og:description', 'og:site_name', 'keywords'].includes(match[1])) {
                        metaTags.push(`${match[1]}: ${match[2]}`);
                    }
                }

                // Clean body text (naive)
                let bodyText = text.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gmi, " ");
                bodyText = bodyText.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gmi, " ");
                bodyText = bodyText.replace(/<[^>]+>/g, " ");
                bodyText = bodyText.replace(/\s+/g, " ").trim().substring(0, 10000); // Limit context

                contextData = `
                PAGE METADATA:
                Title: ${pageTitle}
                Meta: ${metaTags.join('\n')}
                
                PAGE CONTENT PREVIEW:
                ${bodyText}
                `;
            } else {
                console.log("Fetch failed with status:", res.status);
            }
        } catch (e) {
            console.log("Fetch failed:", e.message);
        }
    }

    let prompt = `You are a data extraction assistant specialized in extracting contact information from business cards, profiles, and professional documents.

    INPUT URL: ${url || 'N/A'}
    ${file_url ? 'IMAGE FILE: Provided (business card or profile screenshot)' : ''}
    
    ${contextData ? `FETCHED CONTENT:\n${contextData}` : ''}

    TASK:
    Carefully analyze the provided image or content and extract ALL available information. Look for text, logos, QR codes, and any visible details.
    
    EXTRACT THESE FIELDS:
    - full_name: The person's complete name (look carefully at all text on the card)
    - title: Job title, position, or role (e.g., "Marketing Manager", "CEO", "Engineer")
    - company: Company or organization name (look for logos, company names)
    - bio: Any tagline, description, or about text
    - email: Email address (look for patterns like name@company.com)
    - phone: Phone number (including country code if visible, e.g., +966, +971, +1)
    - location: Address, city, country, or region
    - website: Website URL or domain
    - links: Social media handles and URLs (Instagram, LinkedIn, WhatsApp, etc.)

    FOR BUSINESS CARDS:
    - Scan ALL text carefully - names, titles, emails, phone numbers are usually clearly printed
    - Look for multiple phone numbers (mobile, office, fax)
    - Check for email addresses (usually format: name@company.com)
    - Look for social media icons and handles (@username)
    - Extract company address if visible
    - Check for website URLs (www.company.com or company.com)
    
    FOR PHONE NUMBERS:
    - Include country codes if visible (e.g., +966 for Saudi Arabia, +971 for UAE)
    - Format should be the full number as shown on the card
    
    FOR LINKS (social media):
    Platform options: instagram, linkedin, twitter, facebook, youtube, tiktok, whatsapp, snapchat, pinterest, github, behance, dribbble, soundcloud, spotify, telegram, email, website
    - Extract handles even if just @username is shown
    - Convert @username to full URL (e.g., @john → https://instagram.com/john)
    - If full URL is visible, use that
    
    IMPORTANT:
    - Extract EVERYTHING you see - don't skip any information
    - Be thorough and check all corners of the image
    - For business cards, most information is usually printed clearly
    - If you see multiple contact methods, include all of them
    - Don't invent information, but also don't miss what's clearly visible
    `;

    // Prepare LLM call
    const llmParams = {
      prompt: prompt,
      response_json_schema: {
        type: "object",
        properties: {
          full_name: { type: "string" },
          title: { type: "string" },
          company: { type: "string" },
          bio: { type: "string" },
          email: { type: "string" },
          phone: { type: "string" },
          location: { type: "string" },
          website: { type: "string" },
          links: { 
            type: "array",
            items: {
              type: "object",
              properties: {
                platform: { type: "string" },
                value: { type: "string" },
                label: { type: "string" }
              }
            }
          }
        },
        required: ["full_name"]
      }
    };

    if (file_url) {
      llmParams.file_urls = [file_url];
    } else if (url) {
        // If we failed to fetch context or just want to be sure, allow internet
        llmParams.add_context_from_internet = true; 
    }

    const result = await base44.integrations.Core.InvokeLLM(llmParams);
    
    return new Response(JSON.stringify({ data: result }), {
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}