import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const { username } = await req.json();
        
        const profiles = await base44.asServiceRole.entities.Profile.filter({ username });
        
        if (!profiles || profiles.length === 0) {
            return Response.json({ error: 'Profile not found' }, { status: 404 });
        }
        
        const profile = profiles[0];
        
        return Response.json({ 
            profile: profile,
            links: profile.links || [],
            linksCount: profile.links?.length || 0
        });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});